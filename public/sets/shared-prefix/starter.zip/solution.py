def prefix_length(a,b):
    """Return the number of consecutive matching token IDs from position zero.
    """
    raise NotImplementedError("Complete prefix_length in solution.py")


def choose(entries, model, tokens):
    """Saved entries are [model_version, token_ids, kv_values], with one opaque KV
    value per token. Return the longest reusable KV prefix from a matching model.
    Partial entry reuse is valid. Earlier entry wins a length tie. Return [] on a
    miss; edits to the returned list must not change an entry.
    """
    raise NotImplementedError("Complete choose in solution.py")


def run(events):
    """Events: ['save',model,tokens,values] adds an immutable snapshot;
    ['open',id,model,tokens] initializes this request to choose()'s reusable values
    only. ['append',id,value] adds a locally computed KV value; ['cancel',id] drops
    a request. These return null. ['read',id] returns its current values or null if
    absent. Reads are snapshots. Return one result per event; appends target open
    requests.
    """
    raise NotImplementedError("Complete run in solution.py")
