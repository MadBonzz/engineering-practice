# Shared-prefix caching

Several requests start with the same system prompt. Reuse compatible KV states while keeping each continuation and saved prefix independent.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Select a reusable snapshot

prefix_length(a, b) — Return the number of consecutive matching token IDs from position zero.

choose(entries, model, tokens) — Saved entries are [model_version, token_ids, kv_values], with one opaque KV value per token. Return the longest reusable KV prefix from a matching model. Partial entry reuse is valid. Earlier entry wins a length tie. Return [] on a miss; edits to the returned list must not change an entry.

## Part 2 · Branch and cancel requests

run(events) — Events: ['save',model,tokens,values] adds an immutable snapshot; ['open',id,model,tokens] initializes this request to choose()'s reusable values only. ['append',id,value] adds a locally computed KV value; ['cancel',id] drops a request. These return null. ['read',id] returns its current values or null if absent. Reads are snapshots. Return one result per event; appends target open requests.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
