def canonical(order, verdict):
    """order is 'AB' or 'BA'; verdict is 'left', 'right', 'tie', or 'invalid'. Return
    'A', 'B', 'tie', or None for invalid. A and B identify models regardless of
    screen position.
    """
    raise NotImplementedError("Complete canonical in solution.py")


def audit(row):
    """Row fields: ab and ba are two judge verdicts with swapped order, human is
    canonical A/B/tie. Return [valid_pair, stable, agreed]. All three are booleans.
    Stable requires two valid, equal canonical votes; agreed also requires a match
    to the human label. Missing/invalid pairs contribute False to all flags.
    """
    raise NotImplementedError("Complete audit in solution.py")


def summarize(rows):
    """Return a dict with overall, by_task and by_length. Each summary has total,
    valid, stable, agreement and flip_rate. Agreement is agreed/stable; flip_rate is
    (valid-stable)/valid; use null for a zero denominator. For length slices use
    'equal', 'A-longer' or 'B-longer' comparing len_a and len_b. Include only
    observed groups.
    """
    raise NotImplementedError("Complete summarize in solution.py")
