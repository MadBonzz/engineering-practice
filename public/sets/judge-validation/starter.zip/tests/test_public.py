import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_canonical_example_1(self):
        args = ['AB', 'left']
        observed = trial('canonical', args)
        expected = {'return': 'A'}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_canonical_example_2(self):
        args = ['BA', 'right']
        observed = trial('canonical', args)
        expected = {'return': 'A'}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_audit_example_1(self):
        args = [{'ab': 'left',
  'ba': 'right',
  'human': 'A',
  'len_a': 0,
  'len_b': 0,
  'task': 'code'}]
        observed = trial('audit', args)
        expected = {'return': [True, True, True]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_audit_example_2(self):
        args = [{'ab': 'right',
  'ba': 'right',
  'human': 'B',
  'len_a': 1,
  'len_b': 1,
  'task': 'math'}]
        observed = trial('audit', args)
        expected = {'return': [True, False, False]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_summarize_example_1(self):
        args = [[{'ab': 'left',
   'ba': 'right',
   'human': 'A',
   'len_a': 0,
   'len_b': 0,
   'task': 'code'}]]
        observed = trial('summarize', args)
        expected = {'return': {'by_length': {'equal': {'agreement': 1.0,
                                    'flip_rate': 0.0,
                                    'stable': 1,
                                    'total': 1,
                                    'valid': 1}},
            'by_task': {'code': {'agreement': 1.0,
                                 'flip_rate': 0.0,
                                 'stable': 1,
                                 'total': 1,
                                 'valid': 1}},
            'overall': {'agreement': 1.0,
                        'flip_rate': 0.0,
                        'stable': 1,
                        'total': 1,
                        'valid': 1}}}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_summarize_example_2(self):
        args = [[{'ab': 'right',
   'ba': 'right',
   'human': 'B',
   'len_a': 1,
   'len_b': 1,
   'task': 'math'},
  {'ab': 'tie',
   'ba': 'tie',
   'human': 'tie',
   'len_a': 2,
   'len_b': 2,
   'task': 'code'}]]
        observed = trial('summarize', args)
        expected = {'return': {'by_length': {'equal': {'agreement': 1.0,
                                    'flip_rate': 0.5,
                                    'stable': 1,
                                    'total': 2,
                                    'valid': 2}},
            'by_task': {'code': {'agreement': 1.0,
                                 'flip_rate': 0.0,
                                 'stable': 1,
                                 'total': 1,
                                 'valid': 1},
                        'math': {'agreement': None,
                                 'flip_rate': 1.0,
                                 'stable': 0,
                                 'total': 1,
                                 'valid': 1}},
            'overall': {'agreement': 1.0,
                        'flip_rate': 0.5,
                        'stable': 1,
                        'total': 2,
                        'valid': 2}}}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

