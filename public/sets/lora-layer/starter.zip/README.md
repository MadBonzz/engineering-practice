# LoRA linear layer

Extend a frozen projection with a trainable adapter, update it on one labeled example, and export a merged projection for serving.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Run the adapter

forward(weight, a, b, x, alpha) — Return W x + (alpha/r) B A x. W is [out,in], A [r,in], B [out,r], r>0. All arrays are ordinary lists; no bias. Return a vector without editing the inputs.

## Part 2 · Train only the adapter

update(weight, a, b, x, target, alpha, lr) — One SGD step for loss 0.5*sum((prediction-target)^2). Keep W frozen. Return [new_A,new_B] using gradients from the same pre-update parameters. Do not mutate inputs.

## Part 3 · Merge for deployment

merge(weight, a, b, alpha) — Export a standalone weight matrix whose ordinary linear() output agrees with the adapter for any input. Return a new [out,in] matrix; preserve the frozen weights.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
