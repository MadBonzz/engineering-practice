def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def linear(weight, x):
    return [dot(row, x) for row in weight]


def forward(weight, a, b, x, alpha):
    """Return W x + (alpha/r) B A x. W is [out,in], A [r,in], B [out,r], r>0. All
    arrays are ordinary lists; no bias. Return a vector without editing the inputs.
    """
    raise NotImplementedError("Complete forward in solution.py")


def update(weight, a, b, x, target, alpha, lr):
    """One SGD step for loss 0.5*sum((prediction-target)^2). Keep W frozen. Return
    [new_A,new_B] using gradients from the same pre-update parameters. Do not mutate
    inputs.
    """
    raise NotImplementedError("Complete update in solution.py")


def merge(weight, a, b, alpha):
    """Export a standalone weight matrix whose ordinary linear() output agrees with the
    adapter for any input. Return a new [out,in] matrix; preserve the frozen
    weights.
    """
    raise NotImplementedError("Complete merge in solution.py")
