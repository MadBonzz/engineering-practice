# Quantized linear inference

A model exporter and a CPU inference worker must agree on a compact weight format. Calibrate output channels independently, run the layer, and serialize exactly what it stores.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Quantize and run the layer

quantize(row) — Quantize one nonempty output channel using signed symmetric int8 values [-127,127]. Scale is max(abs(weight))/127, or 1.0 for an all-zero row. Round weight/scale using Python round (ties to even). Return [scale, integer_codes].

project(rows, x, bias) — rows is a list of [scale, codes] channels. Compute output_i = bias_i + scale_i * dot(codes_i,x). Keep codes in their integer representation in storage. Return one number per channel.

## Part 2 · Export the deployment format

export(weights) — Serialize each row as a little-endian float32 scale followed immediately by its signed int8 codes, with no header, padding, or bias. Return lowercase hex so the wire image can be compared exactly. A reader knows the dimensions. Empty weights yield an empty string.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
