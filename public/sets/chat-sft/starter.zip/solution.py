ROLE = {"system": 1, "user": 2, "assistant": 3}
END = 4
PAD = 0
IGNORE = -100


def encode_turn(role, tokens):
    """Frame tokenized content as [role_id, *tokens, END]. Return [ids, labels] of
    equal length. Ignore every role marker. Only assistant content and its END are
    prediction targets. Constants are supplied.
    """
    raise NotImplementedError("Complete encode_turn in solution.py")


def encode_chat(turns, limit):
    """Concatenate encoded [role, tokens] turns and keep the first limit tokens (limit
    >= 0). Return [ids, labels] without padding or shifting; truncation must not
    invent an end marker.
    """
    raise NotImplementedError("Complete encode_chat in solution.py")


def collate(chats, limit):
    """Right-pad encoded conversations to the longest retained length, returning a dict
    with input_ids, labels, attention_mask. Masks use 1 for real tokens and 0 for
    padding. Padding has IGNORE labels. Empty batch has three empty lists. Preserve
    row order.
    """
    raise NotImplementedError("Complete collate in solution.py")
