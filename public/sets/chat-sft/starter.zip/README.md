# Chat supervised fine-tuning

A fine-tuning job is learning to echo user prompts. Build the data path from tokenized chat turns to a labeled training batch, and inspect exactly which tokens receive loss.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Label a single turn

encode_turn(role, tokens) — Frame tokenized content as [role_id, *tokens, END]. Return [ids, labels] of equal length. Ignore every role marker. Only assistant content and its END are prediction targets. Constants are supplied.

## Part 2 · Frame a conversation

encode_chat(turns, limit) — Concatenate encoded [role, tokens] turns and keep the first limit tokens (limit >= 0). Return [ids, labels] without padding or shifting; truncation must not invent an end marker.

## Part 3 · Collate a training batch

collate(chats, limit) — Right-pad encoded conversations to the longest retained length, returning a dict with input_ids, labels, attention_mask. Masks use 1 for real tokens and 0 for padding. Padding has IGNORE labels. Empty batch has three empty lists. Preserve row order.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
