# Durable tool execution and replay

A mock-interview evaluator can crash after the remote tool finishes but before the turn is saved. Restore interrupted turns, preserve the first answer, and make retries safe across sessions.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Resume a single tool call

effect_key(session, turn) — Return an unambiguous stable tool idempotency key for string session and turn IDs, even if either contains ':'. Format: decimal character length of session, ':', session, then turn (no second separator).

resume(log, external, session, turn, answer, stop) — One retryable evaluation turn. log is a mutable write-ahead journal of [key, 'intent'/'done', value]. external is a mutable idempotent tool store: key -> recorded result. Existing done returns its result. Otherwise persist intent with original answer once (first answer wins), then use the key at the tool boundary. The deterministic tool result is 'score:' plus that original answer. Persist done once. stop='intent' returns None after ensuring intent; stop='tool' returns None after the effect but before done; stop='finish' completes. Existing done always wins. Preserve unrelated records; never repeat or replace existing effects.

## Part 2 · Recover interleaved turns

replay(attempts) — Start with an empty durable journal and external tool. Each attempt is [session,turn,answer,stop]; only those two stores survive between attempts. Return {replies, journal, effects} in execution order. Keyed effect storage stands in for an external tool that supports idempotency keys.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
