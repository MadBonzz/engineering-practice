# Live continuous batching

Your serving worker receives requests at different times. Wire the supplied model to a scheduler that admits new work while longer generations are still running.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Execute one model batch

step(rows) — Rows are [request_id, state, remaining]. Make one model_batch call for the whole nonempty batch. Return [id, token, new_state, remaining_after] in the input order. Empty input returns [].

## Part 2 · Admit and retire requests

tick(active, waiting, capacity) — Active and waiting rows have the same shape as step(). Fill vacant slots FIFO behind existing active rows, then advance all admitted rows once. Return [surviving_rows, still_waiting_rows, emitted_pairs]. Surviving rows contain the updated state and remaining count. Pairs are [id, token] in batch order. Finished slots become available next tick.

## Part 3 · Serve the arrival stream

dispatch(requests, capacity) — Requests are [arrival_tick, id, prompt_tokens, positive_budget], in arrival order. Starting at tick zero, append arrivals before admission. Prefill each once using new_state. Return the list of emitted-pair lists per tick including idle ticks, ending at final emission. Empty input returns []. Capacity is positive.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
