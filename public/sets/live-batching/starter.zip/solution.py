def new_state(prompt):
    """Prefill the supplied recurrent token model."""
    state = 0
    for token in prompt:
        state = (state*3 + token + 1) % 11
    return state


def model_batch(states):
    """One real batched greedy step of a tiny deterministic model. Returns (token, new_state) pairs."""
    result = []
    for state in states:
        token = max(range(5), key=lambda t: ((state + 2)*(t + 1) + t*t) % 13)
        result.append((token, (state*3 + token + 1) % 11))
    return result


def step(rows):
    """Rows are [request_id, state, remaining]. Make one model_batch call for the whole
    nonempty batch. Return [id, token, new_state, remaining_after] in the input
    order. Empty input returns [].
    """
    raise NotImplementedError("Complete step in solution.py")


def tick(active, waiting, capacity):
    """Active and waiting rows have the same shape as step(). Fill vacant slots FIFO
    behind existing active rows, then advance all admitted rows once. Return
    [surviving_rows, still_waiting_rows, emitted_pairs]. Surviving rows contain the
    updated state and remaining count. Pairs are [id, token] in batch order.
    Finished slots become available next tick.
    """
    raise NotImplementedError("Complete tick in solution.py")


def dispatch(requests, capacity):
    """Requests are [arrival_tick, id, prompt_tokens, positive_budget], in arrival
    order. Starting at tick zero, append arrivals before admission. Prefill each
    once using new_state. Return the list of emitted-pair lists per tick including
    idle ticks, ending at final emission. Empty input returns []. Capacity is
    positive.
    """
    raise NotImplementedError("Complete dispatch in solution.py")
