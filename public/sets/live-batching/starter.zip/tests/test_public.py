import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_step_example_1(self):
        args = [[['0', 0, 1]]]
        observed = trial('step', args)
        expected = {'return': [['0', 2, 3, 0]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_step_example_2(self):
        args = [[['0', 1, 2], ['1', 4, 3]]]
        observed = trial('step', args)
        expected = {'return': [['0', 3, 7, 1], ['1', 2, 4, 2]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_tick_example_1(self):
        args = [[['0', 0, 1]], [['z', 7, 1]], 1]
        observed = trial('tick', args)
        expected = {'return': [[], [['z', 7, 1]], [['0', 2]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_tick_example_2(self):
        args = [[['0', 1, 2]], [['1', 4, 3], ['z', 7, 1]], 2]
        observed = trial('tick', args)
        expected = {'return': [[['0', 7, 1], ['1', 4, 2]],
            [['z', 7, 1]],
            [['0', 3], ['1', 2]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part3(unittest.TestCase):
    def test_dispatch_example_1(self):
        args = [[[0, 'a', [0, 2], 1], [0, 'b', [1], 2], [1, 'c', [], 2], [4, 'd', [4], 1]],
 1]
        observed = trial('dispatch', args)
        expected = {'return': [[['a', 0]],
            [['b', 3]],
            [['b', 0]],
            [['c', 2]],
            [['c', 1]],
            [['d', 2]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_dispatch_example_2(self):
        args = [[[1, 'a', [1, 2], 2], [1, 'b', [1], 2], [2, 'c', [], 2], [5, 'd', [4], 1]],
 2]
        observed = trial('dispatch', args)
        expected = {'return': [[],
            [['a', 0], ['b', 3]],
            [['a', 0], ['b', 0]],
            [['c', 2]],
            [['c', 1]],
            [['d', 2]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

