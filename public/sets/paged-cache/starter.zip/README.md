# Paged KV-cache allocator

Requests grow one token at a time in a fixed physical memory pool. Implement reservation, logical addressing, and reuse when requests finish out of order.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Reserve capacity atomically

reserve(table, blocks, length, extra, block_size) — Reserve room for extra tokens of this request. table is its ordered list of physical block IDs, blocks the sorted free IDs, length its used token count. Return [new_table, new_free, ok]. Keep old blocks; allocate lowest free IDs first, only as needed. Failure leaves both lists unchanged. Return copies or equivalent values.

## Part 2 · Translate a token address

locate(table, offset, block_size) — Return [physical_block, slot] for an allocated zero-based logical token offset. Caller supplies a valid offset.

## Part 3 · Replay allocation traffic

replay(block_count, block_size, events) — Initially all numbered blocks are free. 'append', id, n reserves atomically and returns the physical addresses of n new tokens; return null on capacity failure. 'release', id frees the entire request and returns null (unknown is a no-op). 'free' returns sorted free IDs. Return one output per event. A released ID can start again at length zero.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
