def reserve(table, blocks, length, extra, block_size):
    """Reserve room for extra tokens of this request. table is its ordered list of
    physical block IDs, blocks the sorted free IDs, length its used token count.
    Return [new_table, new_free, ok]. Keep old blocks; allocate lowest free IDs
    first, only as needed. Failure leaves both lists unchanged. Return copies or
    equivalent values.
    """
    raise NotImplementedError("Complete reserve in solution.py")


def locate(table, offset, block_size):
    """Return [physical_block, slot] for an allocated zero-based logical token offset.
    Caller supplies a valid offset.
    """
    raise NotImplementedError("Complete locate in solution.py")


def replay(block_count, block_size, events):
    """Initially all numbered blocks are free. 'append', id, n reserves atomically and
    returns the physical addresses of n new tokens; return null on capacity failure.
    'release', id frees the entire request and returns null (unknown is a no-op).
    'free' returns sorted free IDs. Return one output per event. A released ID can
    start again at length zero.
    """
    raise NotImplementedError("Complete replay in solution.py")
