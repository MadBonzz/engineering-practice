# Speculative decoding

A small draft model proposes tokens in blocks. Complete the target verifier using supplied next-token distributions and deterministic random draws.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Verify greedy proposals

greedy(draft, target) — Verify one speculative block. target is the target model's greedy token at each draft position plus one bonus position. Return accepted draft tokens followed by exactly one target token: the first correction on mismatch, otherwise the bonus. Empty draft is valid.

## Part 2 · Verify a sampled block

verify(token, p, q, u, residual_u) — p is the target distribution, q the draft distribution; q[token]>0. Accept the proposal iff u < min(1,p[token]/q[token]). Return [True,token] on acceptance. On rejection return [False, replacement] drawn with draw() from the normalized positive part of p-q using residual_u.

sample_block(proposals, targets, drafts, uniforms, bonus_u) — Each proposal i has distributions targets[i], drafts[i] and uniforms[i]=[u,residual_u]. Return the emitted tokens up to and including the first rejection, or all accepted proposals plus one draw from targets[-1] using bonus_u. targets contains exactly one extra bonus row.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
