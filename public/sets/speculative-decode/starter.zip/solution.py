def draw(probabilities, u):
    """Return the first index whose cumulative probability exceeds u in [0,1). Inputs are normalized; final index is a roundoff fallback."""
    total = 0
    for i,p in enumerate(probabilities):
        total += p
        if u < total:
            return i
    return len(probabilities)-1


def greedy(draft, target):
    """Verify one speculative block. target is the target model's greedy token at each
    draft position plus one bonus position. Return accepted draft tokens followed by
    exactly one target token: the first correction on mismatch, otherwise the bonus.
    Empty draft is valid.
    """
    raise NotImplementedError("Complete greedy in solution.py")


def verify(token, p, q, u, residual_u):
    """p is the target distribution, q the draft distribution; q[token]>0. Accept the
    proposal iff u < min(1,p[token]/q[token]). Return [True,token] on acceptance. On
    rejection return [False, replacement] drawn with draw() from the normalized
    positive part of p-q using residual_u.
    """
    raise NotImplementedError("Complete verify in solution.py")


def sample_block(proposals, targets, drafts, uniforms, bonus_u):
    """Each proposal i has distributions targets[i], drafts[i] and
    uniforms[i]=[u,residual_u]. Return the emitted tokens up to and including the
    first rejection, or all accepted proposals plus one draw from targets[-1] using
    bonus_u. targets contains exactly one extra bonus row.
    """
    raise NotImplementedError("Complete sample_block in solution.py")
