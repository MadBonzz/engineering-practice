import random


def delta(rows):
    """Each row is [document_id, score_A, score_B]. Return mean(B-A) over rows or None
    if empty. Each row is a paired measurement.
    """
    raise NotImplementedError("Complete delta in solution.py")


def replicate(rows, units, mode):
    """units is a with-replacement list of row indices (mode='row') or document IDs
    (mode='document'). In document mode each occurrence contributes all its original
    rows. Compute the row-weighted paired delta across the selected records,
    including repeated units. Empty selection returns None.
    """
    raise NotImplementedError("Complete replicate in solution.py")


def interval(rows, mode, repeats, seed):
    """Return [observed_delta, lower, upper]. Sample as many units as originally
    present, with replacement, for each of repeats>=1 replicates. Use one
    random.Random(seed), randrange(len(units)) for each draw, in order. Row units
    are indices; document units occur in first-appearance order. Use linear
    interpolation at (N-1)*p of the sorted replicate deltas for p=.025 and .975.
    Empty dataset returns three nulls.
    """
    raise NotImplementedError("Complete interval in solution.py")
