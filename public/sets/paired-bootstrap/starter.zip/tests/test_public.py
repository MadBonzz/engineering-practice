import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_delta_example_1(self):
        args = [[]]
        observed = trial('delta', args)
        expected = {'return': None}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_delta_example_2(self):
        args = [[['z', 1, 0], ['a', 0, 1], ['z', 1, 0], ['b', 0, 1], ['z', 1, 1]]]
        observed = trial('delta', args)
        expected = {'return': 0.0}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_replicate_example_1(self):
        args = [[['z', 1, 0], ['a', 0, 1], ['z', 0, 0], ['b', 0, 0], ['z', 1, 1]],
 ['z', 'a', 'a'],
 'document']
        observed = trial('replicate', args)
        expected = {'return': 0.2}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_replicate_example_2(self):
        args = [[['z', 1, 0], ['a', 0, 1], ['z', 1, 0], ['b', 0, 1], ['z', 1, 1]],
 [1, 1, 0],
 'row']
        observed = trial('replicate', args)
        expected = {'return': 0.3333333333333333}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_interval_example_1(self):
        args = [[['z', 1, 0], ['a', 0, 1], ['z', 0, 0], ['b', 0, 0], ['z', 1, 1]],
 'document',
 17,
 0]
        observed = trial('interval', args)
        expected = {'return': [0.0, -0.2857142857142857, 0.8666666666666665]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_interval_example_2(self):
        args = [[['z', 1, 0], ['a', 0, 1], ['z', 1, 0], ['b', 0, 1], ['z', 1, 1]],
 'row',
 18,
 1]
        observed = trial('interval', args)
        expected = {'return': [0.0, -0.63, 0.8299999999999997]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

