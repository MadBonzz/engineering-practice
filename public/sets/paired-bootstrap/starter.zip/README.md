# Paired statistical comparison

Two releases answered the same questions. Estimate the improvement and its uncertainty when multiple questions share one source document.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Estimate paired improvements

delta(rows) — Each row is [document_id, score_A, score_B]. Return mean(B-A) over rows or None if empty. Each row is a paired measurement.

replicate(rows, units, mode) — units is a with-replacement list of row indices (mode='row') or document IDs (mode='document'). In document mode each occurrence contributes all its original rows. Compute the row-weighted paired delta across the selected records, including repeated units. Empty selection returns None.

## Part 2 · Construct the interval

interval(rows, mode, repeats, seed) — Return [observed_delta, lower, upper]. Sample as many units as originally present, with replacement, for each of repeats>=1 replicates. Use one random.Random(seed), randrange(len(units)) for each draw, in order. Row units are indices; document units occur in first-appearance order. Use linear interpolation at (N-1)*p of the sorted replicate deltas for p=.025 and .975. Empty dataset returns three nulls.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
