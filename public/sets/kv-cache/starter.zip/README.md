# Per-layer KV cache

A decoder handles prompt prefill and incremental generation in separate calls. Complete the cache path for a supplied two-dimensional attention model.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Append one attention state

advance(hidden, layer, position, keys, values) — Project this token once with project(), append K and V in place, attend over the extended history, and return the input hidden vector plus the attention output elementwise.

## Part 2 · Decode across layers

decode(token, cache) — Each layer has a mutable [keys, values] pair. Embed integer t as [sin(t), cos(t)]. Pass through layers in ascending zero-based order, using each layer's existing token count as position. Return logits [x, y, x-y] from the final hidden state. Mutate the supplied cache without recomputing earlier projections.

## Part 3 · Continue across chunk boundaries

serve(chunks, layers) — Start an empty multilayer cache. Consume token chunks consecutively, even across empty chunks. Return one list of per-token logit vectors per chunk. Chunk boundaries must not reset positions. Each new token may call project exactly once per layer.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.

Use compare_prefix.py for an independent full-prefix baseline. Locally run python compare_prefix.py to check every token and compare CPU execution time after implementing the cache.
