import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_advance_example_1(self):
        args = [[1.0, -0.6], 0, 0, [], []]
        observed = trial('advance', args)
        expected = {'return': [1.4, -2.2], 'state': [[[-0.6, 1.0]], [[0.4, -1.6]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_advance_example_2(self):
        args = [[1.1, -0.6], 1, 1, [[0.2, 1.0]], [[0.4, 0.1]]]
        observed = trial('advance', args)
        expected = {'return': [1.5248251583157515, -0.9468528496835243],
 'state': [[[0.2, 1.0], [-0.5955579505601168, -0.12373652461837366]],
           [[0.4, 0.1], [0.5000000000000001, -1.7000000000000002]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_decode_example_1(self):
        args = [1, [[[], []]]]
        observed = trial('decode', args)
        expected = {'return': [2.2232442754839328, 0.23913362692838303, 1.9841106485555497],
 'state': [[[[[0.5403023058681398, 0.8414709848078965]],
             [[1.3817732906760363, -0.30116867893975674]]]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_decode_example_2(self):
        args = [2, [[[[0.1, -0.2]], [[0.6, 0.3]]], [[[0.1, -0.2]], [[0.6, 0.3]]]]]
        observed = trial('decode', args)
        expected = {'return': [2.138024241622331, -1.2677610881179324, 3.4057853297402634],
 'state': [[[[[0.1, -0.2], [-0.7168010572865429, 0.6972777382599379]],
             [[0.6, 0.3], [0.4931505902785393, -1.325444263372824]]],
            [[[0.1, -0.2], [-0.8110018306978963, 0.19146609468049194]],
             [[0.6, 0.3], [0.7848977635975377, -2.1586619427208853]]]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part3(unittest.TestCase):
    def test_serve_example_1(self):
        args = [[[0, 2], [], [3], []], 1]
        observed = trial('serve', args)
        expected = {'return': [[[1.0, 2.0, -1.0],
             [1.7956310933049142, 0.06234772583234094, 1.7332833674725734]],
            [],
            [[0.5597237196207316, -0.9431602118233935, 1.5028839314441251]],
            []]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_serve_example_2(self):
        args = [[[1, 2], [], [4], [1]], 2]
        observed = trial('serve', args)
        expected = {'return': [[[4.685622177896248, -1.7449770216271667, 6.4305991995234155],
             [4.374405375960812, -3.088653482816977, 7.463058858777789]],
            [],
            [[-1.6805409338309092,
              -2.2348432724893996,
              0.5543023386584904]],
            [[3.661845000013459, -2.245638742374497, 5.9074837423879565]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

