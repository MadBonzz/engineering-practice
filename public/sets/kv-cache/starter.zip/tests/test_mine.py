import unittest
from solution import *


class MyTests(unittest.TestCase):
    """Add your own test methods here."""
