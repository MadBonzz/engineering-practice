"""Run locally: python compare_prefix.py"""
from math import cos, sin, isclose
from time import perf_counter
from solution import attend, project, serve


def full_prefix(tokens, layers):
    """Uncached model forward. Rebuild every earlier token at every layer."""
    hidden = [[sin(t), cos(t)] for t in tokens]
    for layer in range(layers):
        triples = [project(row, layer, i) for i, row in enumerate(hidden)]
        keys = [k for _, k, _ in triples]
        values = [v for _, _, v in triples]
        next_hidden = []
        for i, ((query, _, _), row) in enumerate(zip(triples, hidden)):
            context = attend(query, keys[:i+1], values[:i+1])
            next_hidden.append([a+b for a, b in zip(row, context)])
        hidden = next_hidden
    x, y = hidden[-1]
    return [x, y, x-y]


if __name__ == "__main__":
    tokens = [2, 5, 1, 7] * 8
    start = perf_counter()
    baseline = [full_prefix(tokens[:i+1], 2) for i in range(len(tokens))]
    full_time = perf_counter()-start
    start = perf_counter()
    result = serve([tokens[:8], tokens[8:]], 2)
    cache_time = perf_counter()-start
    observed = result[0]+result[1]
    assert len(observed)==len(baseline)
    for i, (a, b) in enumerate(zip(observed, baseline)):
        assert len(a)==len(b) and all(isclose(x, y, abs_tol=1e-8, rel_tol=1e-7) for x, y in zip(a, b)), i
    print(f"{len(tokens)} logits checked; full-prefix {full_time:.4f}s, cached {cache_time:.4f}s")
