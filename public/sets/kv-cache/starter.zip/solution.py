import math


def project(hidden, layer, position):
    """Fixed two-component projections. Position is the absolute token offset."""
    x, y = hidden
    angle = position * 0.37
    c, s = math.cos(angle), math.sin(angle)
    def rotate(a, b):
        return [a*c-b*s, a*s+b*c]
    return rotate(x, y+layer), rotate(y, x-layer), [x+y, y-x]


def attend(query, keys, values):
    scores = [sum(a*b for a, b in zip(query, key)) / math.sqrt(2) for key in keys]
    weights = [math.exp(s-max(scores)) for s in scores]
    return [sum(w*v[d] for w, v in zip(weights, values))/sum(weights) for d in range(2)]


def advance(hidden, layer, position, keys, values):
    """Project this token once with project(), append K and V in place, attend over the
    extended history, and return the input hidden vector plus the attention output
    elementwise.
    """
    raise NotImplementedError("Complete advance in solution.py")


def decode(token, cache):
    """Each layer has a mutable [keys, values] pair. Embed integer t as [sin(t),
    cos(t)]. Pass through layers in ascending zero-based order, using each layer's
    existing token count as position. Return logits [x, y, x-y] from the final
    hidden state. Mutate the supplied cache without recomputing earlier projections.
    """
    raise NotImplementedError("Complete decode in solution.py")


def serve(chunks, layers):
    """Start an empty multilayer cache. Consume token chunks consecutively, even across
    empty chunks. Return one list of per-token logit vectors per chunk. Chunk
    boundaries must not reset positions. Each new token may call project exactly
    once per layer.
    """
    raise NotImplementedError("Complete serve in solution.py")
