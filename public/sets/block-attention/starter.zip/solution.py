import math


def scores(query, keys):
    """Return scaled dot products q.k/sqrt(query width) in key order. Empty keys return
    [].
    """
    raise NotImplementedError("Complete scores in solution.py")


def absorb(state, logits, values):
    """State is [max_logit, scaled_mass, weighted_vector]; empty uses None, 0, zeros.
    Fold in a block and return a new state. Both mass and vector are expressed
    relative to the maximum logit seen over all blocks (weights exp(logit-max)).
    Empty blocks are identity. Never exponentiate an unshifted large logit.
    """
    raise NotImplementedError("Complete absorb in solution.py")


def attention(query, blocks, value_width):
    """Blocks are [keys,values] pairs, possibly empty. Produce the normalized attention
    output using a streaming pass with working storage proportional to one block
    plus the output width. Return a zero vector when all blocks are empty.
    """
    raise NotImplementedError("Complete attention in solution.py")
