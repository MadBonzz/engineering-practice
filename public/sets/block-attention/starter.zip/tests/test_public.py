import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_scores_example_1(self):
        args = [[1, -2.0], [[1000.0, 1.0]]]
        observed = trial('scores', args)
        expected = {'return': [705.6925676241743]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_scores_example_2(self):
        args = [[2, -2.0], [[1000.0, 1.0], [-1000.0, 1.0]]]
        observed = trial('scores', args)
        expected = {'return': [1412.7993488107218, -1415.627775935468]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_absorb_example_1(self):
        args = [[None, 0, [0, 0]], [], []]
        observed = trial('absorb', args)
        expected = {'return': [None, 0, [0, 0]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_absorb_example_2(self):
        args = [[999, 2, [3, 6]], [1001.0, 999.0], [[1, 3], [-2, 5]]]
        observed = trial('absorb', args)
        expected = {'return': [1001.0,
            1.4060058497098382,
            [1.1353352832366128, 4.48868811560274]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_attention_example_1(self):
        args = [[1, -2.0], [], 2]
        observed = trial('attention', args)
        expected = {'return': [0, 0]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_attention_example_2(self):
        args = [[2, -2.0],
 [[[], []],
  [[[1000.0, 1.0]], [[1, 3]]],
  [[[-1000.0, 1.0], [1001.0, -2.0]], [[-2, 5], [2, 8]]]],
 2]
        observed = trial('attention', args)
        expected = {'return': [1.9965186727029347, 7.982593363514673]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

