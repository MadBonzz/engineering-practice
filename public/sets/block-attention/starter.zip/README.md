# Blockwise attention

An inference worker streams key/value blocks that cannot fit in a single score matrix. Compute one attention output while keeping the softmax stable as new maxima arrive.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Accumulate stable block statistics

scores(query, keys) — Return scaled dot products q.k/sqrt(query width) in key order. Empty keys return [].

absorb(state, logits, values) — State is [max_logit, scaled_mass, weighted_vector]; empty uses None, 0, zeros. Fold in a block and return a new state. Both mass and vector are expressed relative to the maximum logit seen over all blocks (weights exp(logit-max)). Empty blocks are identity. Never exponentiate an unshifted large logit.

## Part 2 · Stream an attention result

attention(query, blocks, value_width) — Blocks are [keys,values] pairs, possibly empty. Produce the normalized attention output using a streaming pass with working storage proportional to one block plus the output width. Return a zero vector when all blocks are empty.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.
