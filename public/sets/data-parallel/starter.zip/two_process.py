"""Run locally: python two_process.py"""
from concurrent.futures import ProcessPoolExecutor
from solution import local, reduce_ranks

if __name__ == "__main__":
    weights = [0.25, -0.5]
    shards = [[([1, 2], 3)], [([0, 1], 2), ([2, 0], -1)]]
    with ProcessPoolExecutor(2) as pool:
        reports = list(pool.map(local, [weights] * 2, shards))
    actual = reduce_ranks(reports)
    expected = local(weights, shards[0] + shards[1])[1]
    assert all(abs(a-b) < 1e-9 for a,b in zip(actual, expected))
    print("Two-rank reduction agrees with a single full batch.")
