import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_local_example_1(self):
        args = [[0.2, -1], []]
        observed = trial('local', args)
        expected = {'return': [0, [0.0, 0.0]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_local_example_2(self):
        args = [[0.30000000000000004, -1], [[[1, 2], 1], [[2, -3], 1], [[0, 1], 1]]]
        observed = trial('local', args)
        expected = {'return': [3, [0.8333333333333334, -5.066666666666667]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_reduce_ranks_example_1(self):
        args = [[[0, [1, 2]], [1, [4, -1]], [0, [0, 0]]]]
        observed = trial('reduce_ranks', args)
        expected = {'return': [4.0, -1.0]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_reduce_ranks_example_2(self):
        args = [[[1, [1, 2]], [2, [4, -1]], [0, [0, 0]]]]
        observed = trial('reduce_ranks', args)
        expected = {'return': [3.0, 0.0]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part3(unittest.TestCase):
    def test_train_example_1(self):
        args = [[0.2, -1],
 [[[[[1, 2], 1], [[2, -3], 0], [[0, 1], 1]], [[[3, 0], 1]]],
  [[], [[[3, 0], 1]]],
  [[], []],
  [[[[3, 0], 1]], [[[1, 2], 1], [[2, -3], 0], [[0, 1], 1]]]],
 0.02]
        observed = trial('train', args)
        expected = {'return': [[0.186, -0.911],
            [0.21252, -0.911],
            [0.21252, -0.911],
            [0.19942359999999998, -0.8279796]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_train_example_2(self):
        args = [[0.30000000000000004, -1],
 [[[[[1, 2], 1], [[2, -3], 1], [[0, 1], 1]], [[[3, 0], 1]]],
  [[], [[[3, 0], 1]]],
  [[], []],
  [[[[3, 0], 1]], [[[1, 2], 1], [[2, -3], 1], [[0, 1], 1]]]],
 0.04]
        observed = trial('train', args)
        expected = {'return': [[0.278, -0.848],
            [0.29792, -0.848],
            [0.29792, -0.848],
            [0.2822912, -0.7173632]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

