# Distributed data-parallel SGD

A training job splits batches unevenly between workers. Implement rank-local gradients, their reduction, and synchronized updates. The browser simulates ranks; a two-process driver is included for local runs.

Use solution.py for your implementation. workload.py is the read-only scenario driver. Inputs use ordinary Python lists, numbers, strings and dictionaries. Preserve input arguments unless a function contract explicitly calls for an in-place update. Numeric answers use relative tolerance 1e-7 and absolute tolerance 1e-8.

## Part 1 · Compute a rank report

local(weights, examples) — Compute [sample_count, mean_gradient] for loss 0.5*(w.x-y)^2. Each example is [feature_vector, y]. An empty rank contributes count zero and a zero vector the width of weights.

## Part 2 · Reduce uneven shards

reduce_ranks(reports) — Each rank supplies [local_count, local_mean_gradient]. Return the global per-example mean gradient, preserving vector width. At least one report is supplied; if all counts are zero return zeros.

## Part 3 · Synchronize training steps

train(weights, steps, lr) — Each step contains one examples list per rank (at least one rank), including possible empty shards. All ranks start a step with identical current weights. Apply one global SGD update. Return a weight snapshot after each step, including empty steps, without editing initial weights.

## Running the workspace

Choose a part from the test menu, or run the full public suite. Locally use python -m unittest discover -s tests. Add your own checks to tests/test_mine.py. Submit a snapshot to evaluate additional workloads.

For a real two-process CPU check, download the starter and run python two_process.py after completing the reduction.
