def prediction(weights, x):
    return sum(w*v for w,v in zip(weights,x))


def local(weights, examples):
    """Compute [sample_count, mean_gradient] for loss 0.5*(w.x-y)^2. Each example is
    [feature_vector, y]. An empty rank contributes count zero and a zero vector the
    width of weights.
    """
    raise NotImplementedError("Complete local in solution.py")


def reduce_ranks(reports):
    """Each rank supplies [local_count, local_mean_gradient]. Return the global per-
    example mean gradient, preserving vector width. At least one report is supplied;
    if all counts are zero return zeros.
    """
    raise NotImplementedError("Complete reduce_ranks in solution.py")


def train(weights, steps, lr):
    """Each step contains one examples list per rank (at least one rank), including
    possible empty shards. All ranks start a step with identical current weights.
    Apply one global SGD update. Return a weight snapshot after each step, including
    empty steps, without editing initial weights.
    """
    raise NotImplementedError("Complete train in solution.py")
