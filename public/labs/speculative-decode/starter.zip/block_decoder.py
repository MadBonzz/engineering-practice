"""Decide when to stop, correct, or emit the bonus."""

from sampling import draw
from verification import verify


def sample_block(proposals, targets, drafts, uniforms, bonus_u):
    """Each proposal i has distributions targets[i], drafts[i] and
    uniforms[i]=[u,residual_u]. Return the emitted tokens up to and
    including the first rejection, or all accepted proposals plus one
    draw from targets[-1] using bonus_u. targets contains exactly one
    extra bonus row.
    """
    raise NotImplementedError("block_decoder.sample_block")
