# Speculative decoding

A draft model proposes a block of tokens and a target model verifies it. Finish the verifier used by both greedy and sampled generation. Clients must receive a correction at the first rejection, or one bonus token when the entire draft is accepted.

## Your task

mode selects 'greedy' or 'sample'. Greedy requests contain draft and target token IDs. Sampled requests contain proposals, targets, drafts, uniforms and bonus_u. Probability rows are in vocabulary order; uniforms[i] contains the acceptance draw and the correction draw.

Return {tokens: [...]} in emission order. A rejected position contributes the target correction and ends the block.

## Constraints

The target provides one extra position for a bonus. Probability rows sum to one, draws are in [0,1), and every proposed token has positive draft probability. Inputs are supplied snapshots of model predictions.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- sampling.py (provided) — Supplied categorical draw over an ordered distribution.

- verification.py (edit) — Check greedy agreement and verify an individual sampled proposal.

- block_decoder.py (edit) — Decide when to stop, correct, or emit the bonus.

## Example 1

Input

```json
{
  "mode": "greedy",
  "draft": [
    4,
    8,
    1
  ],
  "target": [
    4,
    3,
    9,
    2
  ]
}
```

Expected output

```json
{
  "tokens": [
    4,
    3
  ]
}
```

The first draft token matches. At the second position the target wants 3, so the verifier emits 3 and discards the rest.

## Example 2

Input

```json
{
  "mode": "sample",
  "proposals": [
    0
  ],
  "targets": [
    [
      0.2,
      0.8
    ],
    [
      0.5,
      0.5
    ]
  ],
  "drafts": [
    [
      0.8,
      0.2
    ]
  ],
  "uniforms": [
    [
      0.9,
      0.1
    ]
  ],
  "bonus_u": 0.4
}
```

Expected output

```json
{
  "tokens": [
    1
  ]
}
```

Token 0 is accepted with probability 0.25. The draw 0.9 rejects it. All positive residual mass lies on token 1, and rejection ends the block.

## Part 1 · Verify greedy proposals

verification.py · greedy(draft, target) — Verify one speculative block. target is the target model's greedy token at each draft position plus one bonus position. Return accepted draft tokens followed by exactly one target token: the first correction on mismatch, otherwise the bonus. Empty draft is valid.

## Part 2 · Verify a sampled block

verification.py · verify(token, p, q, u, residual_u) — p is the target distribution, q the draft distribution; q[token]>0. Accept the proposal iff u < min(1,p[token]/q[token]). Return [True,token] on acceptance. On rejection return [False, replacement] drawn with draw() from the normalized positive part of p-q using residual_u.

block_decoder.py · sample_block(proposals, targets, drafts, uniforms, bonus_u) — Each proposal i has distributions targets[i], drafts[i] and uniforms[i]=[u,residual_u]. Return the emitted tokens up to and including the first rejection, or all accepted proposals plus one draw from targets[-1] using bonus_u. targets contains exactly one extra bonus row.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
