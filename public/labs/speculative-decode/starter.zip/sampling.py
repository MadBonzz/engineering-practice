"""Supplied categorical draw over an ordered distribution."""



def draw(probabilities, u):
    """Return the first index whose cumulative probability exceeds u in [0,1). Inputs are normalized; final index is a roundoff fallback."""
    total = 0
    for i,p in enumerate(probabilities):
        total += p
        if u < total:
            return i
    return len(probabilities)-1
