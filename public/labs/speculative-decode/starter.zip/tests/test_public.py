import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_greedy_example_1(self):
        args = [[1, 2, 0], [1, 2, 0, 0]]
        observed = trial('greedy', args)
        expected = {'return': [1, 2, 0, 0]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_greedy_example_2(self):
        args = [[1, 2, 1], [1, 1, 3, 0]]
        observed = trial('greedy', args)
        expected = {'return': [1, 1]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_verify_example_1(self):
        args = [0, [0.1, 0.55, 0.35], [0.6, 0.2, 0.2], 0.05, 0.0]
        observed = trial('verify', args)
        expected = {'return': [True, 0]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_verify_example_2(self):
        args = [0, [0.1, 0.55, 0.35], [0.6, 0.2, 0.2], 0.2, 0.1]
        observed = trial('verify', args)
        expected = {'return': [False, 1]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_sample_block_example_1(self):
        args = [[], [[0.2, 0.3, 0.5]], [], [], 0.0]
        observed = trial('sample_block', args)
        expected = {'return': [0]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_sample_block_example_2(self):
        args = [[0, 1],
 [[0.1, 0.55, 0.35], [0.1, 0.55, 0.35], [0.2, 0.3, 0.5]],
 [[0.6, 0.2, 0.2], [0.6, 0.2, 0.2]],
 [[0.2, 0.1], [0.2, 0.1]],
 0.125]
        observed = trial('sample_block', args)
        expected = {'return': [1]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

