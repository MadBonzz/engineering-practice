import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'draft': [4, 8, 1], 'mode': 'greedy', 'target': [4, 3, 9, 2]}
        expected = {'tokens': [4, 3]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'bonus_u': 0.4,
 'drafts': [[0.8, 0.2]],
 'mode': 'sample',
 'proposals': [0],
 'targets': [[0.2, 0.8], [0.5, 0.5]],
 'uniforms': [[0.9, 0.1]]}
        expected = {'tokens': [1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
