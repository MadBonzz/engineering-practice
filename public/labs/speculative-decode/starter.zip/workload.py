import copy
import math
from sampling import draw
from verification import greedy, verify
from block_decoder import sample_block
from gateway import handle

# The transport uses JSON-shaped inputs and outputs. Each trial starts fresh.
MUTABLE = {}
PUBLIC_API = {'greedy': greedy, 'verify': verify, 'sample_block': sample_block, 'handle': handle}

def trial(name, args):
    if name not in PUBLIC_API:
        raise ValueError("Unknown operation")
    original = copy.deepcopy(args)
    answer = PUBLIC_API[name](*args)
    changed = MUTABLE.get(name, [])
    if any(args[i] != original[i] for i in range(len(args)) if i not in changed):
        raise AssertionError("An input documented as read-only changed.")
    result = {"return": answer}
    if changed:
        result["state"] = [args[i] for i in changed]
    return result

def equivalent(actual, expected):
    if isinstance(expected, bool):
        return actual is expected
    if isinstance(expected, (int, float)):
        return type(actual) in (int, float) and math.isclose(actual, expected, rel_tol=1e-7, abs_tol=1e-8)
    if isinstance(expected, list):
        return isinstance(actual, (list, tuple)) and len(actual)==len(expected) and all(equivalent(a,e) for a,e in zip(actual,expected))
    if isinstance(expected, dict):
        return isinstance(actual, dict) and actual.keys()==expected.keys() and all(equivalent(actual[k],v) for k,v in expected.items())
    return actual == expected
