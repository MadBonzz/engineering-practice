"""Public service entry point. Each call receives one decoded JSON request."""
from verification import greedy
from block_decoder import sample_block

def handle(request):
    if request["mode"] == "greedy":
        tokens = greedy(request["draft"], request["target"])
    else:
        tokens = sample_block(request["proposals"], request["targets"], request["drafts"], request["uniforms"], request["bonus_u"])
    return {"tokens": tokens}
