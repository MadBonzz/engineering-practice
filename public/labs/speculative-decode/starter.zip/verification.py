"""Check greedy agreement and verify an individual sampled proposal."""

from sampling import draw


def greedy(draft, target):
    """Verify one speculative block. target is the target model's greedy token
    at each draft position plus one bonus position. Return accepted draft
    tokens followed by exactly one target token: the first correction on
    mismatch, otherwise the bonus. Empty draft is valid.
    """
    raise NotImplementedError("verification.greedy")


def verify(token, p, q, u, residual_u):
    """p is the target distribution, q the draft distribution; q[token]>0.
    Accept the proposal iff u < min(1,p[token]/q[token]). Return
    [True,token] on acceptance. On rejection return [False, replacement]
    drawn with draw() from the normalized positive part of p-q using
    residual_u.
    """
    raise NotImplementedError("verification.verify")
