"""Compare consecutive prefix tokens."""



def prefix_length(a, b):
    """Return the number of consecutive matching token IDs from position zero.
    """
    raise NotImplementedError("token_prefix.prefix_length")
