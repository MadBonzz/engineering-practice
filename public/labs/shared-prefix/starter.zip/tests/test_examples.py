import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [['save', 'v1', [7, 8], [10, 20]],
            ['open', 'a', 'v1', [7, 9]],
            ['open', 'b', 'v1', [7]],
            ['append', 'a', 30],
            ['read', 'a'],
            ['read', 'b']]}
        expected = {'reads': [{'id': 'a', 'values': [10, 30]}, {'id': 'b', 'values': [10]}]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['open', 'x', 'v2', [3]],
            ['read', 'x'],
            ['cancel', 'x'],
            ['read', 'x']]}
        expected = {'reads': [{'id': 'x', 'values': []}, {'id': 'x', 'values': None}]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
