import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_prefix_length_example_1(self):
        args = [[0, 2, 3, 5], [0, 2, 7, 5]]
        observed = trial('prefix_length', args)
        expected = {'return': 2}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_prefix_length_example_2(self):
        args = [[1, 2, 3, 5], [1, 2, 3, 5, 4]]
        observed = trial('prefix_length', args)
        expected = {'return': 4}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_choose_example_1(self):
        args = [[['v2', [0, 2, 7, 5], [0, 0, 0, 0]],
  ['v1', [0, 2, 3, 5], [1, 2, 3, 4]],
  ['v1', [0, 2, 3, 5], [1, 2, 3, 4]]],
 'v3',
 [0, 2, 7, 5]]
        observed = trial('choose', args)
        expected = {'return': []}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_choose_example_2(self):
        args = [[['v2', [1, 2, 3, 5, 4], [0, 0, 0, 0, 0]],
  ['v1', [1, 2, 3, 5], [1, 2, 3, 4]],
  ['v1', [1, 2, 3, 5], [1, 2, 3, 4]]],
 'v1',
 [1, 2, 3, 5, 4]]
        observed = trial('choose', args)
        expected = {'return': [1, 2, 3, 4]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_run_example_1(self):
        args = [[['save', 'v2', [0, 2, 7, 5], [0, 0, 0, 0]],
  ['save', 'v1', [0, 2, 3, 5], [1, 2, 3, 4]],
  ['save', 'v1', [0, 2, 3, 5], [1, 2, 3, 4]],
  ['open', 'a', 'v1', [0, 2, 7, 5]],
  ['open', 'b', 'v1', [0, 2, 7, 5]],
  ['read', 'a'],
  ['append', 'a', 9],
  ['read', 'b'],
  ['cancel', 'a'],
  ['read', 'a'],
  ['read', 'b'],
  ['open', 'c', 'v3', [0, 2, 7, 5]],
  ['read', 'c']]]
        observed = trial('run', args)
        expected = {'return': [None,
            None,
            None,
            None,
            None,
            [1, 2],
            None,
            [1, 2],
            None,
            None,
            [1, 2],
            None,
            []]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_run_example_2(self):
        args = [[['save', 'v2', [1, 2, 3, 5, 4], [0, 0, 0, 0, 0]],
  ['save', 'v1', [1, 2, 3, 5], [1, 2, 3, 4]],
  ['save', 'v1', [1, 2, 3, 5], [1, 2, 3, 4]],
  ['open', 'a', 'v1', [1, 2, 3, 5, 4]],
  ['open', 'b', 'v1', [1, 2, 3, 5, 4]],
  ['read', 'a'],
  ['append', 'a', 9],
  ['read', 'b'],
  ['cancel', 'a'],
  ['read', 'a'],
  ['read', 'b'],
  ['open', 'c', 'v3', [1, 2, 3, 5, 4]],
  ['read', 'c']]]
        observed = trial('run', args)
        expected = {'return': [None,
            None,
            None,
            None,
            None,
            [1, 2, 3, 4],
            None,
            [1, 2, 3, 4],
            None,
            None,
            [1, 2, 3, 4],
            None,
            []]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

