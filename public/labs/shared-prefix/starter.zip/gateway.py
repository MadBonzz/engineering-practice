"""Public service entry point. Each call receives one decoded JSON request."""
from sessions import run

def handle(request):
    events = request["events"]
    replies = run(events)
    return {"reads": [{"id": event[1], "values": reply} for event, reply in zip(events, replies) if event[0] == "read"]}
