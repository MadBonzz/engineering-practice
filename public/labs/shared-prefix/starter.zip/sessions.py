"""Manage open requests, local appends, reads and cancellation."""

from snapshot_index import choose


def run(events):
    """Events: ['save',model,tokens,values] adds an immutable snapshot;
    ['open',id,model,tokens] initializes this request to choose()'s
    reusable values only. ['append',id,value] adds a locally computed KV
    value; ['cancel',id] drops a request. These return null. ['read',id]
    returns its current values or null if absent. Reads are snapshots.
    Return one result per event; appends target open requests.
    """
    raise NotImplementedError("sessions.run")
