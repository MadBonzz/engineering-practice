# Shared-prefix caching

Two chat sessions start from the same cached prompt and then diverge. Build the snapshot lookup and session lifecycle so that a continuation can reuse matching model state without changing what another session observes.

## Your task

events is an ordered stream. save takes [model, tokens, KV_values], open takes [id, model, tokens], append takes [id, value], and read or cancel takes [id]. Each event starts with the operation name.

Return a reads array containing one {id, values} record per read, in read order. Unknown or cancelled requests produce null. An open request with zero reusable tokens produces [].

## Constraints

A snapshot belongs to one model version. Use the longest matching token prefix, including partial matches. On a length tie use the earliest saved entry. Append targets an open session.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- token_prefix.py (edit) — Compare consecutive prefix tokens.

- snapshot_index.py (edit) — Select compatible saved KV values for a request.

- sessions.py (edit) — Manage open requests, local appends, reads and cancellation.

## Example 1

Input

```json
{
  "events": [
    [
      "save",
      "v1",
      [
        7,
        8
      ],
      [
        10,
        20
      ]
    ],
    [
      "open",
      "a",
      "v1",
      [
        7,
        9
      ]
    ],
    [
      "open",
      "b",
      "v1",
      [
        7
      ]
    ],
    [
      "append",
      "a",
      30
    ],
    [
      "read",
      "a"
    ],
    [
      "read",
      "b"
    ]
  ]
}
```

Expected output

```json
{
  "reads": [
    {
      "id": "a",
      "values": [
        10,
        30
      ]
    },
    {
      "id": "b",
      "values": [
        10
      ]
    }
  ]
}
```

Both requests reuse the state for token 7. Only a receives the new state 30.

## Example 2

Input

```json
{
  "events": [
    [
      "open",
      "x",
      "v2",
      [
        3
      ]
    ],
    [
      "read",
      "x"
    ],
    [
      "cancel",
      "x"
    ],
    [
      "read",
      "x"
    ]
  ]
}
```

Expected output

```json
{
  "reads": [
    {
      "id": "x",
      "values": []
    },
    {
      "id": "x",
      "values": null
    }
  ]
}
```

The first read observes an open request with no cached state. The second read observes a cancelled request.

## Part 1 · Select a reusable snapshot

token_prefix.py · prefix_length(a, b) — Return the number of consecutive matching token IDs from position zero.

snapshot_index.py · choose(entries, model, tokens) — Saved entries are [model_version, token_ids, kv_values], with one opaque KV value per token. Return the longest reusable KV prefix from a matching model. Partial entry reuse is valid. Earlier entry wins a length tie. Return [] on a miss; edits to the returned list must not change an entry.

## Part 2 · Branch and cancel requests

sessions.py · run(events) — Events: ['save',model,tokens,values] adds an immutable snapshot; ['open',id,model,tokens] initializes this request to choose()'s reusable values only. ['append',id,value] adds a locally computed KV value; ['cancel',id] drops a request. These return null. ['read',id] returns its current values or null if absent. Reads are snapshots. Return one result per event; appends target open requests.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
