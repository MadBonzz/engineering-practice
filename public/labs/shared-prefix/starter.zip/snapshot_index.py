"""Select compatible saved KV values for a request."""

from token_prefix import prefix_length


def choose(entries, model, tokens):
    """Saved entries are [model_version, token_ids, kv_values], with one opaque
    KV value per token. Return the longest reusable KV prefix from a
    matching model. Partial entry reuse is valid. Earlier entry wins a
    length tie. Return [] on a miss; edits to the returned list must not
    change an entry.
    """
    raise NotImplementedError("snapshot_index.choose")
