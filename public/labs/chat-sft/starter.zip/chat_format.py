"""Define the protocol constants and frame a single speaker turn."""

ROLE = {"system": 1, "user": 2, "assistant": 3}
END = 4
PAD = 0
IGNORE = -100


def encode_turn(role, tokens):
    """Frame tokenized content as [role_id, *tokens, END]. Return [ids, labels]
    of equal length. Ignore every role marker. Only assistant content and
    its END are prediction targets. Constants are supplied.
    """
    raise NotImplementedError("chat_format.encode_turn")
