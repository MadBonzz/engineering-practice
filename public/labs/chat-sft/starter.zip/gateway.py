"""Public service entry point. Each call receives one decoded JSON request."""
from batch_collator import collate

def handle(request):
    return collate(request["chats"], request["limit"])
