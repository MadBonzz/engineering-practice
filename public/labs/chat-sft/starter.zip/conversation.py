"""Flatten turns and enforce the length budget."""

from chat_format import encode_turn


def encode_chat(turns, limit):
    """Concatenate encoded [role, tokens] turns and keep the first limit tokens
    (limit >= 0). Return [ids, labels] without padding or shifting;
    truncation must not invent an end marker.
    """
    raise NotImplementedError("conversation.encode_chat")
