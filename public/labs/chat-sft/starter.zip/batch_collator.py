"""Align input IDs, labels and attention masks across a batch."""

from chat_format import IGNORE, PAD
from conversation import encode_chat


def collate(chats, limit):
    """Right-pad encoded conversations to the longest retained length, returning
    a dict with input_ids, labels, attention_mask. Masks use 1 for real
    tokens and 0 for padding. Padding has IGNORE labels. Empty batch has
    three empty lists. Preserve row order.
    """
    raise NotImplementedError("batch_collator.collate")
