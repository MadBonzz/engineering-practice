# Chat supervised fine-tuning

Your chat training pipeline currently scores every token, including the user's question. Repair the path from tokenized turns through truncation and batch padding. A user token can be visible to attention while contributing nothing to the training loss.

## Your task

chats is a batch. Each conversation is a list of [role, content_token_ids] turns. limit is the maximum retained tokens per conversation, including framing tokens.

Return three equally shaped grids: input_ids, labels, and attention_mask. labels hold the target ID or -100. attention_mask distinguishes real input positions (1) from padding (0). The trainer handles the next-token shift.

## Constraints

Role IDs are system=1, user=2 and assistant=3. END=4 and PAD=0. Keep assistant content and assistant END as targets. Truncate from the right and pad to the longest retained row in this batch.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- chat_format.py (edit) — Define the protocol constants and frame a single speaker turn.

- conversation.py (edit) — Flatten turns and enforce the length budget.

- batch_collator.py (edit) — Align input IDs, labels and attention masks across a batch.

## Example 1

Input

```json
{
  "chats": [
    [
      [
        "user",
        [
          9
        ]
      ],
      [
        "assistant",
        [
          8
        ]
      ]
    ],
    []
  ],
  "limit": 6
}
```

Expected output

```json
{
  "input_ids": [
    [
      2,
      9,
      4,
      3,
      8,
      4
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0
    ]
  ],
  "labels": [
    [
      -100,
      -100,
      -100,
      -100,
      8,
      4
    ],
    [
      -100,
      -100,
      -100,
      -100,
      -100,
      -100
    ]
  ],
  "attention_mask": [
    [
      1,
      1,
      1,
      1,
      1,
      1
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0
    ]
  ]
}
```

Only 8 and the assistant's end marker receive loss. All six real tokens are visible to attention. The empty second chat pads to the same width.

## Example 2

Input

```json
{
  "chats": [
    [
      [
        "assistant",
        [
          7,
          8
        ]
      ]
    ]
  ],
  "limit": 2
}
```

Expected output

```json
{
  "input_ids": [
    [
      3,
      7
    ]
  ],
  "labels": [
    [
      -100,
      7
    ]
  ],
  "attention_mask": [
    [
      1,
      1
    ]
  ]
}
```

The cut falls inside an answer. No end marker is inserted after token 7.

## Part 1 · Label a single turn

chat_format.py · encode_turn(role, tokens) — Frame tokenized content as [role_id, *tokens, END]. Return [ids, labels] of equal length. Ignore every role marker. Only assistant content and its END are prediction targets. Constants are supplied.

## Part 2 · Frame a conversation

conversation.py · encode_chat(turns, limit) — Concatenate encoded [role, tokens] turns and keep the first limit tokens (limit >= 0). Return [ids, labels] without padding or shifting; truncation must not invent an end marker.

## Part 3 · Collate a training batch

batch_collator.py · collate(chats, limit) — Right-pad encoded conversations to the longest retained length, returning a dict with input_ids, labels, attention_mask. Masks use 1 for real tokens and 0 for padding. Padding has IGNORE labels. Empty batch has three empty lists. Preserve row order.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
