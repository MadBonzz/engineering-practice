import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_encode_turn_example_1(self):
        args = ['assistant', []]
        observed = trial('encode_turn', args)
        expected = {'return': [[3, 4], [-100, 4]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_encode_turn_example_2(self):
        args = ['user', [11]]
        observed = trial('encode_turn', args)
        expected = {'return': [[2, 11, 4], [-100, -100, -100]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_encode_chat_example_1(self):
        args = [[['user', [9, 8]],
  ['assistant', [11, 12]],
  ['user', []],
  ['assistant', [9]]],
 6]
        observed = trial('encode_chat', args)
        expected = {'return': [[2, 9, 8, 4, 3, 11], [-100, -100, -100, -100, -100, 11]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_encode_chat_example_2(self):
        args = [[['user', [9, 8]],
  ['assistant', [12, 12]],
  ['user', []],
  ['assistant', [9]]],
 12]
        observed = trial('encode_chat', args)
        expected = {'return': [[2, 9, 8, 4, 3, 12, 12, 4, 2, 4, 3, 9],
            [-100, -100, -100, -100, -100, 12, 12, 4, -100, -100, -100, 9]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part3(unittest.TestCase):
    def test_collate_example_1(self):
        args = [[[['user', [9, 8]],
   ['assistant', [11, 12]],
   ['user', []],
   ['assistant', [9]]],
  [['assistant', []], ['user', [12]]],
  []],
 6]
        observed = trial('collate', args)
        expected = {'return': {'attention_mask': [[1, 1, 1, 1, 1, 1],
                               [1, 1, 1, 1, 1, 0],
                               [0, 0, 0, 0, 0, 0]],
            'input_ids': [[2, 9, 8, 4, 3, 11],
                          [3, 4, 2, 12, 4, 0],
                          [0, 0, 0, 0, 0, 0]],
            'labels': [[-100, -100, -100, -100, -100, 11],
                       [-100, 4, -100, -100, -100, -100],
                       [-100, -100, -100, -100, -100, -100]]}}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_collate_example_2(self):
        args = [[[['user', [9, 8]],
   ['assistant', [12, 12]],
   ['user', []],
   ['assistant', [9]]],
  [['assistant', []], ['user', [12]]],
  []],
 12]
        observed = trial('collate', args)
        expected = {'return': {'attention_mask': [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                               [1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0],
                               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
            'input_ids': [[2, 9, 8, 4, 3, 12, 12, 4, 2, 4, 3, 9],
                          [3, 4, 2, 12, 4, 0, 0, 0, 0, 0, 0, 0],
                          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
            'labels': [[-100,
                        -100,
                        -100,
                        -100,
                        -100,
                        12,
                        12,
                        4,
                        -100,
                        -100,
                        -100,
                        9],
                       [-100,
                        4,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100],
                       [-100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100,
                        -100]]}}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

