import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'chats': [[['user', [9]], ['assistant', [8]]], []], 'limit': 6}
        expected = {'attention_mask': [[1, 1, 1, 1, 1, 1], [0, 0, 0, 0, 0, 0]],
 'input_ids': [[2, 9, 4, 3, 8, 4], [0, 0, 0, 0, 0, 0]],
 'labels': [[-100, -100, -100, -100, 8, 4],
            [-100, -100, -100, -100, -100, -100]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'chats': [[['assistant', [7, 8]]]], 'limit': 2}
        expected = {'attention_mask': [[1, 1]], 'input_ids': [[3, 7]], 'labels': [[-100, 7]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
