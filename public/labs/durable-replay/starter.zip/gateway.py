"""Public service entry point. Each call receives one decoded JSON request."""
from turn_worker import replay, continue_from


def handle(request):
    if "checkpoint" in request:
        return continue_from(request["checkpoint"], request["attempts"])
    return replay(request["attempts"])
