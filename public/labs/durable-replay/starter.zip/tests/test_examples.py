import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'attempts': [['s', 't', 'yes', 'tool'], ['s', 't', 'no', 'finish']]}
        expected = {'effects': {'1:st': 'score:yes'},
 'journal': [['1:st', 'intent', 'yes'], ['1:st', 'done', 'score:yes']],
 'replies': [None, 'score:yes']}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'attempts': [['s', 't', 'different', 'finish']],
 'checkpoint': {'effects': {'1:st': 'old-scorer:7'},
                'journal': [['1:st', 'intent', 'yes']]}}
        expected = {'effects': {'1:st': 'old-scorer:7'},
 'journal': [['1:st', 'intent', 'yes'], ['1:st', 'done', 'old-scorer:7']],
 'replies': ['old-scorer:7']}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
