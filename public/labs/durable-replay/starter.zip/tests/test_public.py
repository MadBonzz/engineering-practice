import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_effect_key_example_1(self):
        args = ['a:', '0']
        observed = trial('effect_key', args)
        expected = {'return': '2:a:0'}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_effect_key_example_2(self):
        args = ['a', '1']
        observed = trial('effect_key', args)
        expected = {'return': '1:a1'}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_resume_example_1(self):
        args = [[], {}, 'a:', '0', 'new', 'finish']
        observed = trial('resume', args)
        expected = {'return': 'score:new',
 'state': [[['2:a:0', 'intent', 'new'], ['2:a:0', 'done', 'score:new']],
           {'2:a:0': 'score:new'}]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_resume_example_2(self):
        args = [[['1:a1', 'intent', 'original']], {}, 'a', '1', 'new', 'intent']
        observed = trial('resume', args)
        expected = {'return': None, 'state': [[['1:a1', 'intent', 'original']], {}]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_replay_example_1(self):
        args = [[['a:', '0', 'one', 'intent'],
  ['a:x', '0', 'other', 'finish'],
  ['a:', '0', 'two', 'tool'],
  ['a:', '0', 'three', 'finish'],
  ['a:', '0', 'four', 'tool']]]
        observed = trial('replay', args)
        expected = {'return': {'effects': {'2:a:0': 'score:one', '3:a:x0': 'score:other'},
            'journal': [['2:a:0', 'intent', 'one'],
                        ['3:a:x0', 'intent', 'other'],
                        ['3:a:x0', 'done', 'score:other'],
                        ['2:a:0', 'done', 'score:one']],
            'replies': [None,
                        'score:other',
                        None,
                        'score:one',
                        'score:one']}}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_replay_example_2(self):
        args = [[['a', '1', 'one', 'intent'],
  ['ax', '1', 'other', 'finish'],
  ['a', '1', 'two', 'tool'],
  ['a', '1', 'three', 'finish'],
  ['a', '1', 'four', 'tool']]]
        observed = trial('replay', args)
        expected = {'return': {'effects': {'1:a1': 'score:one', '2:ax1': 'score:other'},
            'journal': [['1:a1', 'intent', 'one'],
                        ['2:ax1', 'intent', 'other'],
                        ['2:ax1', 'done', 'score:other'],
                        ['1:a1', 'done', 'score:one']],
            'replies': [None,
                        'score:other',
                        None,
                        'score:one',
                        'score:one']}}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

