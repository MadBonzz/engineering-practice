import copy
import unittest
from gateway import handle


class RecoveryAfterRestart(unittest.TestCase):
    def test_resume_keeps_recorded_remote_response_and_preserves_snapshot(self):
        checkpoint = {"journal": [["1:st", "intent", "old"]], "effects": {"1:st": "recorded-before-crash"}}
        original = copy.deepcopy(checkpoint)
        result = handle({"checkpoint": checkpoint, "attempts": [["s", "t", "new", "finish"]]})
        self.assertEqual(result["replies"], ["recorded-before-crash"])
        self.assertEqual(checkpoint, original)
        self.assertEqual(result["journal"][-1], ["1:st", "done", "recorded-before-crash"])
