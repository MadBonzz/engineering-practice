# Durable tool execution and replay

The interview app has scored a candidate's answer, but the process crashes before recording completion. The client retries, possibly with different text. Recover the original turn across the journal and an external tool that supports idempotency keys.

## Your task

attempts is a chronological list of [session_id, turn_id, answer, stop]. stop is 'intent', 'tool', or 'finish', indicating where the worker stops. IDs and answers are strings. To restart from an earlier run, supply checkpoint with the previous journal and effects. Without a checkpoint, both stores start empty.

Return replies (one result or null per attempt), journal (durable intent and done records), and effects (the external tool's recorded results by key). On restart, return replies for the new attempts and the full updated stores. Leave the input checkpoint untouched.

## Constraints

Persist the first answer before calling the tool. A finished turn returns its stored result even if the retry requests an earlier stop. Only the journal and external store survive a restart. The key encoding is specified in the identifier component. Use the supplied TurnJournal and ScoreClient adapters. An existing remote result is authoritative, including results produced by an older scorer.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- effect_ids.py (edit) — Encode session and turn identity without collisions.

- recovery.py (edit) — Resume work at the first unfinished durable boundary.

- turn_worker.py (edit) — Replay client attempts against shared durable storage.

- journal.py (provided) — Read a turn's durable history and append a single event.

- score_client.py (provided) — Call the remote scorer with an idempotency key.

- restart_demo.py (provided) — Run a crash and a retry in two separate Python processes.

## Example 1

Input

```json
{
  "attempts": [
    [
      "s",
      "t",
      "yes",
      "tool"
    ],
    [
      "s",
      "t",
      "no",
      "finish"
    ]
  ]
}
```

Expected output

```json
{
  "replies": [
    null,
    "score:yes"
  ],
  "journal": [
    [
      "1:st",
      "intent",
      "yes"
    ],
    [
      "1:st",
      "done",
      "score:yes"
    ]
  ],
  "effects": {
    "1:st": "score:yes"
  }
}
```

The first attempt crashes after the tool stores its result. On retry the original intent still says yes. The worker records that result as done and returns it.

## Example 2

Input

```json
{
  "checkpoint": {
    "journal": [
      [
        "1:st",
        "intent",
        "yes"
      ]
    ],
    "effects": {
      "1:st": "old-scorer:7"
    }
  },
  "attempts": [
    [
      "s",
      "t",
      "different",
      "finish"
    ]
  ]
}
```

Expected output

```json
{
  "replies": [
    "old-scorer:7"
  ],
  "journal": [
    [
      "1:st",
      "intent",
      "yes"
    ],
    [
      "1:st",
      "done",
      "old-scorer:7"
    ]
  ],
  "effects": {
    "1:st": "old-scorer:7"
  }
}
```

A previous process stopped after the remote write. The new process reuses its stored reply, records completion, and returns that reply even though the client supplied different text.

## Part 1 · Resume a single tool call

effect_ids.py · effect_key(session, turn) — Return an unambiguous stable tool idempotency key for string session and turn IDs, even if either contains ':'. Format: decimal character length of session, ':', session, then turn (no second separator).

recovery.py · resume(log, external, session, turn, answer, stop) — One retryable evaluation turn. log is a mutable write-ahead journal of [key, 'intent'/'done', value]. external is a mutable idempotent tool store: key -> recorded result. Existing done returns its result. Otherwise persist intent with original answer once (first answer wins), then use the key at the tool boundary. The deterministic tool result is 'score:' plus that original answer. Persist done once. stop='intent' returns None after ensuring intent; stop='tool' returns None after the effect but before done; stop='finish' completes. Existing done always wins. Preserve unrelated records; never repeat or replace existing effects.

## Part 2 · Recover interleaved turns

turn_worker.py · replay(attempts) — Start with an empty durable journal and external tool. Each attempt is [session,turn,answer,stop]; only those two stores survive between attempts. Return {replies, journal, effects} in execution order. Keyed effect storage stands in for an external tool that supports idempotency keys.

turn_worker.py · continue_from(checkpoint, attempts) — Resume from copies of the supplied journal and effect store. Preserve recorded remote replies verbatim. Return only this invocation's replies and the full resulting stores. Run python restart_demo.py to exercise a restart in a second process.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
