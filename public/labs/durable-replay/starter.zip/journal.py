"""Adapter over the append-only records that survive a worker restart."""


class TurnJournal:
    def __init__(self, rows):
        self.rows = rows

    def read(self, key):
        """Return {event_type: value} for the given turn, including empty strings."""
        return {event: value for stored, event, value in self.rows if stored == key}

    def append(self, key, event, value):
        """Append one durable record. The caller decides whether a write is due."""
        self.rows.append([key, event, value])
