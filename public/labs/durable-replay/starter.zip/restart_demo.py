"""Run locally: python restart_demo.py. Each invocation starts a fresh Python process."""
import json
from pathlib import Path
import subprocess
import sys


def launch(request):
    runner = Path(__file__).with_name("run_lab.py")
    output = subprocess.check_output(
        [sys.executable, str(runner)], input=json.dumps(request), text=True
    )
    return json.loads(output)


if __name__ == "__main__":
    first = launch({"attempts": [["chat", "7", "first", "tool"]]})
    assert first["replies"] == [None]
    checkpoint = {name: first[name] for name in ("journal", "effects")}
    restarted = launch({"checkpoint": checkpoint, "attempts": [["chat", "7", "retry", "finish"]]})
    assert restarted["replies"] == ["score:first"]
    assert len(restarted["journal"]) == 2 and len(restarted["effects"]) == 1
    print(json.dumps(restarted, indent=2))
