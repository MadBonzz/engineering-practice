"""Replay client attempts against shared durable storage."""

from recovery import resume


def replay(attempts):
    """Start with an empty durable journal and external tool. Each attempt is
    [session,turn,answer,stop]; only those two stores survive between
    attempts. Return {replies, journal, effects} in execution order.
    Keyed effect storage stands in for an external tool that supports
    idempotency keys.
    """
    raise NotImplementedError("turn_worker.replay")


def continue_from(checkpoint, attempts):
    """Restore copies of journal and effects, replay attempts, and report the new state."""
    raise NotImplementedError("turn_worker.continue_from")
