"""Resume work at the first unfinished durable boundary."""

from effect_ids import effect_key
from journal import TurnJournal
from score_client import ScoreClient


def resume(log, external, session, turn, answer, stop):
    """One retryable evaluation turn. log is a mutable write-ahead journal of
    [key, 'intent'/'done', value]. external is a mutable idempotent tool
    store: key -> recorded result. Existing done returns its result.
    Otherwise persist intent with original answer once (first answer
    wins), then use the key at the tool boundary. The deterministic tool
    result is 'score:' plus that original answer. Persist done once.
    stop='intent' returns None after ensuring intent; stop='tool' returns
    None after the effect but before done; stop='finish' completes.
    Existing done always wins. Preserve unrelated records; never repeat
    or replace existing effects.
    """
    raise NotImplementedError("recovery.resume")
