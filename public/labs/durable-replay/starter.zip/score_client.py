"""Supplied remote scoring service. Its records outlive the caller."""


class ScoreClient:
    def __init__(self, effects):
        self.effects = effects

    def evaluate(self, key, answer):
        """An existing key returns the first recorded reply verbatim."""
        if key not in self.effects:
            self.effects[key] = "score:" + answer
        return self.effects[key]
