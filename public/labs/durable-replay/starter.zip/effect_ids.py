"""Encode session and turn identity without collisions."""



def effect_key(session, turn):
    """Return an unambiguous stable tool idempotency key for string session and
    turn IDs, even if either contains ':'. Format: decimal character
    length of session, ':', session, then turn (no second separator).
    """
    raise NotImplementedError("effect_ids.effect_key")
