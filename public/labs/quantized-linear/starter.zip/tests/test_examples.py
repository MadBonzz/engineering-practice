import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'bias': [1], 'weights': [[127, -127]], 'x': [2, 1]}
        expected = {'output': [128], 'packed_hex': '0000803f7f81', 'storage_bytes': 6}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'bias': [2], 'weights': [[0]], 'x': [5]}
        expected = {'output': [2], 'packed_hex': '0000803f00', 'storage_bytes': 5}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
