import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_quantize_example_1(self):
        args = [[0.0, 0.0, 0.0, 0.0]]
        observed = trial('quantize', args)
        expected = {'return': [1.0, [0, 0, 0, 0]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_quantize_example_2(self):
        args = [[0.0, -2, 0.8333333333333333, 3.0]]
        observed = trial('quantize', args)
        expected = {'return': [0.023622047244094488, [0, -85, 35, 127]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_project_example_1(self):
        args = [[[0.125, [1, -4, 0]], [0.5, [127, 1, -7]]], [0.0, 0.3, 2.0], [0.1, -0.5]]
        observed = trial('project', args)
        expected = {'return': [-0.04999999999999999, -7.35]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_project_example_2(self):
        args = [[[0.125, [1, -4, 0]], [0.5, [127, 1, -7]]], [0.2, 0.3, 2.0], [0.1, -0.5]]
        observed = trial('project', args)
        expected = {'return': [-0.024999999999999994, 5.350000000000001]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_export_example_1(self):
        args = [[[0.0, 0.0, 0.0, 0.0], [0.01, 0.03, -0.2, 0.0]]]
        observed = trial('export', args)
        expected = {'return': '0000803f00000000a069ce3a06138100'}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_export_example_2(self):
        args = [[[0.0, -2, 0.8333333333333333, 3.0], [0.01, 0.03, -0.2, 0.0]]]
        observed = trial('export', args)
        expected = {'return': '0683c13c00ab237fa069ce3a06138100'}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

