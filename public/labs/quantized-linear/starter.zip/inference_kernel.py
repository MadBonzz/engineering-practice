"""Evaluate coded rows with independent scales and bias."""



def project(rows, x, bias):
    """rows is a list of [scale, codes] channels. Compute output_i = bias_i +
    scale_i * dot(codes_i,x). Keep codes in their integer representation
    in storage. Return one number per channel.
    """
    raise NotImplementedError("inference_kernel.project")
