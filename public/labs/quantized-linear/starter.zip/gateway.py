"""Public service entry point. Each call receives one decoded JSON request."""
from calibration import quantize
from inference_kernel import project
from weight_format import export

def handle(request):
    weights = request["weights"]
    packed = export(weights)
    rows = [quantize(row) for row in weights]
    return {"output": project(rows, request["x"], request["bias"]), "packed_hex": packed, "storage_bytes": len(bytes.fromhex(packed))}
