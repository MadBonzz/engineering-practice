"""Choose a scale and encode one output channel."""



def quantize(row):
    """Quantize one nonempty output channel using signed symmetric int8 values
    [-127,127]. Scale is max(abs(weight))/127, or 1.0 for an all-zero
    row. Round weight/scale using Python round (ties to even). Return
    [scale, integer_codes].
    """
    raise NotImplementedError("calibration.quantize")
