"""Write the binary deployment format."""

from struct import pack, unpack
from calibration import quantize


def export(weights):
    """Serialize each row as a little-endian float32 scale followed immediately
    by its signed int8 codes, with no header, padding, or bias. Return
    lowercase hex so the wire image can be compared exactly. A reader
    knows the dimensions. Empty weights yield an empty string.
    """
    raise NotImplementedError("weight_format.export")
