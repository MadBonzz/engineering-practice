# Quantized linear inference

A model exporter writes a compact projection and an inference worker evaluates it. Implement both sides of the format. A per-channel scale must mean the same thing to the byte serializer and to the runtime kernel.

## Your task

weights is a matrix with one row per output channel. x is one input vector and bias has one element per channel.

Return output (the scores), packed_hex (the lowercase serialized weight bytes) and storage_bytes (weights and scales only).

## Constraints

Use symmetric signed int8 codes from -127 to 127 and round ties to even. A zero channel has scale 1. Store each scale as little-endian float32 followed by one signed byte per weight. Compute inference with the unrounded calibration scale.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- calibration.py (edit) — Choose a scale and encode one output channel.

- inference_kernel.py (edit) — Evaluate coded rows with independent scales and bias.

- weight_format.py (edit) — Write the binary deployment format.

## Example 1

Input

```json
{
  "weights": [
    [
      127,
      -127
    ]
  ],
  "x": [
    2,
    1
  ],
  "bias": [
    1
  ]
}
```

Expected output

```json
{
  "output": [
    128
  ],
  "packed_hex": "0000803f7f81",
  "storage_bytes": 6
}
```

The scale is 1. Its four bytes are followed by 7f and 81 for +127 and -127. The score is 254 − 127 + 1.

## Example 2

Input

```json
{
  "weights": [
    [
      0
    ]
  ],
  "x": [
    5
  ],
  "bias": [
    2
  ]
}
```

Expected output

```json
{
  "output": [
    2
  ],
  "packed_hex": "0000803f00",
  "storage_bytes": 5
}
```

The zero channel stores a unit scale and a zero code, leaving only the bias.

## Part 1 · Quantize and run the layer

calibration.py · quantize(row) — Quantize one nonempty output channel using signed symmetric int8 values [-127,127]. Scale is max(abs(weight))/127, or 1.0 for an all-zero row. Round weight/scale using Python round (ties to even). Return [scale, integer_codes].

inference_kernel.py · project(rows, x, bias) — rows is a list of [scale, codes] channels. Compute output_i = bias_i + scale_i * dot(codes_i,x). Keep codes in their integer representation in storage. Return one number per channel.

## Part 2 · Export the deployment format

weight_format.py · export(weights) — Serialize each row as a little-endian float32 scale followed immediately by its signed int8 codes, with no header, padding, or bias. Return lowercase hex so the wire image can be compared exactly. A reader knows the dimensions. Empty weights yield an empty string.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
