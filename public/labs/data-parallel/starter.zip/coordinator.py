"""Broadcast a common weight version and apply synchronized steps."""

from rank_worker import local
from collective import reduce_ranks


def train(weights, steps, lr):
    """Each step contains one examples list per rank (at least one rank),
    including possible empty shards. All ranks start a step with
    identical current weights. Apply one global SGD update. Return a
    weight snapshot after each step, including empty steps, without
    editing initial weights.
    """
    raise NotImplementedError("coordinator.train")
