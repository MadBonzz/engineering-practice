"""Predict and compute one rank's sample count and local gradient."""



def prediction(weights, x):
    return sum(w*v for w,v in zip(weights,x))


def local(weights, examples):
    """Compute [sample_count, mean_gradient] for loss 0.5*(w.x-y)^2. Each
    example is [feature_vector, y]. An empty rank contributes count zero
    and a zero vector the width of weights.
    """
    raise NotImplementedError("rank_worker.local")
