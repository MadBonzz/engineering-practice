# Distributed data-parallel SGD

A data-parallel trainer gives the last, smaller shard to a second worker. Its update diverges from a single-process run even though every worker started at the same weights. Repair the rank computation and reducer, then drive several synchronized training steps.

## Your task

weights is the starting vector and lr the learning rate. steps contains global batches. Each step is a list of rank shards, and each shard contains [features, target] examples.

Return history with one post-update weight vector per global step and final with the last vector (or the initial weights when steps is empty).

## Constraints

A step has at least one rank. Rank shards may be empty or unequal. Use half squared error per example, average over all examples globally, and update once per step. The supplied two-process driver runs locally.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- rank_worker.py (edit) — Predict and compute one rank's sample count and local gradient.

- collective.py (edit) — Combine all rank reports into the global mean gradient.

- coordinator.py (edit) — Broadcast a common weight version and apply synchronized steps.

## Example 1

Input

```json
{
  "weights": [
    0
  ],
  "lr": 1,
  "steps": [
    [
      [
        [
          [
            1
          ],
          2
        ]
      ],
      [
        [
          [
            1
          ],
          0
        ],
        [
          [
            1
          ],
          0
        ],
        [
          [
            1
          ],
          0
        ]
      ]
    ]
  ]
}
```

Expected output

```json
{
  "history": [
    [
      0.5
    ]
  ],
  "final": [
    0.5
  ]
}
```

Rank 0 sees one gradient of −2. Rank 1 sees three zero gradients. Across four examples the mean is −0.5, so SGD changes the weight from 0 to 0.5.

## Example 2

Input

```json
{
  "weights": [
    3
  ],
  "lr": 1,
  "steps": [
    [
      [],
      []
    ]
  ]
}
```

Expected output

```json
{
  "history": [
    [
      3
    ]
  ],
  "final": [
    3
  ]
}
```

Both workers report zero examples. A synchronized step still produces a snapshot.

## Part 1 · Compute a rank report

rank_worker.py · local(weights, examples) — Compute [sample_count, mean_gradient] for loss 0.5*(w.x-y)^2. Each example is [feature_vector, y]. An empty rank contributes count zero and a zero vector the width of weights.

## Part 2 · Reduce uneven shards

collective.py · reduce_ranks(reports) — Each rank supplies [local_count, local_mean_gradient]. Return the global per-example mean gradient, preserving vector width. At least one report is supplied; if all counts are zero return zeros.

## Part 3 · Synchronize training steps

coordinator.py · train(weights, steps, lr) — Each step contains one examples list per rank (at least one rank), including possible empty shards. All ranks start a step with identical current weights. Apply one global SGD update. Return a weight snapshot after each step, including empty steps, without editing initial weights.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
