"""Combine all rank reports into the global mean gradient."""



def reduce_ranks(reports):
    """Each rank supplies [local_count, local_mean_gradient]. Return the global
    per-example mean gradient, preserving vector width. At least one
    report is supplied; if all counts are zero return zeros.
    """
    raise NotImplementedError("collective.reduce_ranks")
