"""Public service entry point. Each call receives one decoded JSON request."""
from coordinator import train

def handle(request):
    weights = request["weights"]
    history = train(weights, request["steps"], request["lr"])
    return {"history": history, "final": history[-1] if history else weights}
