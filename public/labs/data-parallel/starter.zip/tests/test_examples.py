import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'lr': 1,
 'steps': [[[[[1], 2]], [[[1], 0], [[1], 0], [[1], 0]]]],
 'weights': [0]}
        expected = {'final': [0.5], 'history': [[0.5]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'lr': 1, 'steps': [[[], []]], 'weights': [3]}
        expected = {'final': [3], 'history': [[3]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
