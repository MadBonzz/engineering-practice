"""Translate display positions into answer identities."""



def canonical(order, verdict):
    """order is 'AB' or 'BA'; verdict is 'left', 'right', 'tie', or 'invalid'.
    Return 'A', 'B', 'tie', or None for invalid. A and B identify models
    regardless of screen position.
    """
    raise NotImplementedError("judge_votes.canonical")
