# LLM-judge validation

Your evaluation team suspects its pairwise judge favors the answer displayed on the left. Each item is judged in both display orders. Normalize the labels, then report where the judge changes its mind and where a stable judgement agrees with the human reviewer.

## Your task

rows contains ab and ba verdicts ('left', 'right', 'tie', or 'invalid'), a human label ('A', 'B', or 'tie'), task, len_a and len_b. A missing vote counts as invalid.

Return overall statistics and two breakdowns, by_task and by_length. Each includes total, valid, stable, agreement (agreed/stable) and flip_rate ((valid−stable)/valid).

## Constraints

A stable pair requires two valid votes for the same answer after reordering. Keep ties. Use null for rates with zero denominator. Include only observed groups.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- judge_votes.py (edit) — Translate display positions into answer identities.

- pair_audit.py (edit) — Audit both presentations against one human label.

- slice_report.py (edit) — Aggregate denominators and rates by task and answer length.

## Example 1

Input

```json
{
  "rows": [
    {
      "ab": "left",
      "ba": "left",
      "human": "A",
      "task": "code",
      "len_a": 5,
      "len_b": 5
    }
  ]
}
```

Expected output

```json
{
  "overall": {
    "total": 1,
    "valid": 1,
    "stable": 0,
    "agreement": null,
    "flip_rate": 1
  },
  "by_task": {
    "code": {
      "total": 1,
      "valid": 1,
      "stable": 0,
      "agreement": null,
      "flip_rate": 1
    }
  },
  "by_length": {
    "equal": {
      "total": 1,
      "valid": 1,
      "stable": 0,
      "agreement": null,
      "flip_rate": 1
    }
  }
}
```

Choosing the left answer twice selects A in the first ordering and B in the second. The pair flips. Since it is the only pair, there are no stable votes on which to measure agreement.

## Example 2

Input

```json
{
  "rows": []
}
```

Expected output

```json
{
  "overall": {
    "total": 0,
    "valid": 0,
    "stable": 0,
    "agreement": null,
    "flip_rate": null
  },
  "by_task": {},
  "by_length": {}
}
```

No rows means no observed task or length slices.

## Part 1 · Audit swapped verdicts

judge_votes.py · canonical(order, verdict) — order is 'AB' or 'BA'; verdict is 'left', 'right', 'tie', or 'invalid'. Return 'A', 'B', 'tie', or None for invalid. A and B identify models regardless of screen position.

pair_audit.py · audit(row) — Row fields: ab and ba are two judge verdicts with swapped order, human is canonical A/B/tie. Return [valid_pair, stable, agreed]. All three are booleans. Stable requires two valid, equal canonical votes; agreed also requires a match to the human label. Missing/invalid pairs contribute False to all flags.

## Part 2 · Report agreement by slice

slice_report.py · summarize(rows) — Return a dict with overall, by_task and by_length. Each summary has total, valid, stable, agreement and flip_rate. Agreement is agreed/stable; flip_rate is (valid-stable)/valid; use null for a zero denominator. For length slices use 'equal', 'A-longer' or 'B-longer' comparing len_a and len_b. Include only observed groups.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
