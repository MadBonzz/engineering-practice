import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'rows': [{'ab': 'left',
           'ba': 'left',
           'human': 'A',
           'len_a': 5,
           'len_b': 5,
           'task': 'code'}]}
        expected = {'by_length': {'equal': {'agreement': None,
                         'flip_rate': 1,
                         'stable': 0,
                         'total': 1,
                         'valid': 1}},
 'by_task': {'code': {'agreement': None,
                      'flip_rate': 1,
                      'stable': 0,
                      'total': 1,
                      'valid': 1}},
 'overall': {'agreement': None,
             'flip_rate': 1,
             'stable': 0,
             'total': 1,
             'valid': 1}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'rows': []}
        expected = {'by_length': {},
 'by_task': {},
 'overall': {'agreement': None,
             'flip_rate': None,
             'stable': 0,
             'total': 0,
             'valid': 0}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
