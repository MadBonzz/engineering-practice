"""Audit both presentations against one human label."""

from judge_votes import canonical


def audit(row):
    """Row fields: ab and ba are two judge verdicts with swapped order, human is
    canonical A/B/tie. Return [valid_pair, stable, agreed]. All three are
    booleans. Stable requires two valid, equal canonical votes; agreed
    also requires a match to the human label. Missing/invalid pairs
    contribute False to all flags.
    """
    raise NotImplementedError("pair_audit.audit")
