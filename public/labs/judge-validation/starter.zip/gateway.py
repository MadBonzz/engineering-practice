"""Public service entry point. Each call receives one decoded JSON request."""
from slice_report import summarize

def handle(request):
    return summarize(request["rows"])
