"""Aggregate denominators and rates by task and answer length."""

from pair_audit import audit


def summarize(rows):
    """Return a dict with overall, by_task and by_length. Each summary has
    total, valid, stable, agreement and flip_rate. Agreement is
    agreed/stable; flip_rate is (valid-stable)/valid; use null for a zero
    denominator. For length slices use 'equal', 'A-longer' or 'B-longer'
    comparing len_a and len_b. Include only observed groups.
    """
    raise NotImplementedError("slice_report.summarize")
