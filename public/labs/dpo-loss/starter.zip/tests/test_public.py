import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_completion_example_1(self):
        args = [[-2, -1, -5], [0, 1, 0]]
        observed = trial('completion', args)
        expected = {'return': -1}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_completion_example_2(self):
        args = [[-2, -3, -5], [0, 1, 1]]
        observed = trial('completion', args)
        expected = {'return': -8}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_margin_example_1(self):
        args = [{'chosen': {'mask': [0, 1, 1],
             'policy': [-8, -1, -2],
             'reference': [-1, -2, -3]},
  'rejected': {'mask': [0, 1, 0],
               'policy': [-7, -1, -3],
               'reference': [-2, -1, -5]}}]
        observed = trial('margin', args)
        expected = {'return': 2}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_margin_example_2(self):
        args = [{'chosen': {'mask': [0, 1, 1],
             'policy': [-8, -3, -2],
             'reference': [-1, -2, -3]},
  'rejected': {'mask': [0, 1, 0],
               'policy': [-7, -1, -3],
               'reference': [-2, -3, -5]}}]
        observed = trial('margin', args)
        expected = {'return': -2}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_batch_example_1(self):
        args = [[{'chosen': {'mask': [0, 1, 1],
              'policy': [-8, -1, -2],
              'reference': [-1, -2, -3]},
   'rejected': {'mask': [0, 1, 0],
                'policy': [-7, -1, -3],
                'reference': [-2, -1, -5]}},
  {'chosen': {'mask': [1], 'policy': [-1], 'reference': [-1]},
   'rejected': {'mask': [1], 'policy': [-1], 'reference': [-1]}},
  {'chosen': {'mask': [0, 1, 1],
              'policy': [-8, -1, -2],
              'reference': [-1, -2, -3]},
   'rejected': {'mask': [0, 1, 0],
                'policy': [-7, -1, -3],
                'reference': [-2, -1, -5]}}],
 0.1]
        observed = trial('batch', args)
        expected = {'return': [0.6298083064410429,
            [-0.015005533422917404,
             -0.016666666666666666,
             -0.015005533422917404]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_batch_example_2(self):
        args = [[{'chosen': {'mask': [0, 1, 1],
              'policy': [-8, -3, -2],
              'reference': [-1, -2, -3]},
   'rejected': {'mask': [0, 1, 0],
                'policy': [-7, -1, -3],
                'reference': [-2, -3, -5]}},
  {'chosen': {'mask': [1], 'policy': [-1], 'reference': [-1]},
   'rejected': {'mask': [1], 'policy': [-1], 'reference': [-1]}},
  {'chosen': {'mask': [0, 1, 1],
              'policy': [-8, -1, -2],
              'reference': [-1, -2, -3]},
   'rejected': {'mask': [0, 1, 0],
                'policy': [-7, -1, -3],
                'reference': [-2, -1, -5]}}],
 1.1]
        observed = trial('batch', args)
        expected = {'return': [1.034437940032446,
            [-0.3300914873227821,
             -0.18333333333333335,
             -0.03657517934388455]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

