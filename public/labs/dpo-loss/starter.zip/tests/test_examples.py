import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'beta': 2,
 'pairs': [{'chosen': {'mask': [0, 1],
                       'policy': [-8, -1],
                       'reference': [-9, -1]},
            'rejected': {'mask': [0, 1],
                         'policy': [-5, -2],
                         'reference': [-6, -2]}}]}
        expected = {'gradients': [-1.0], 'loss': 0.6931471805599453}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'beta': 1, 'pairs': []}
        expected = {'gradients': [], 'loss': None}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
