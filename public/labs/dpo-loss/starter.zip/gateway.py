"""Public service entry point. Each call receives one decoded JSON request."""
from objective import batch

def handle(request):
    loss, gradients = batch(request["pairs"], request["beta"])
    return {"loss": loss, "gradients": gradients}
