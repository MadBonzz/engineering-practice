# DPO preference loss

A post-training job receives precomputed policy and reference log probabilities for pairs of answers. Build the objective that a trainer can call on a whole batch, including batches with very confident preferences.

## Your task

pairs contains chosen and rejected records. Each has aligned policy and reference token log-probabilities and a binary mask selecting completion tokens. beta is a positive scaling factor.

Return loss, the mean DPO loss, and gradients, one derivative of that mean with respect to each unscaled preference margin, in input order.

## Constraints

Sum completion log probabilities, ignore prompt and padding positions, and use the frozen reference's preference as the baseline. Use a numerically stable loss. For zero pairs return null loss and an empty gradient list.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- sequence_scores.py (edit) — Mask and aggregate per-token log probabilities.

- preferences.py (edit) — Measure a policy preference relative to the reference.

- objective.py (edit) — Reduce a numerically stable loss and derivatives over a batch.

## Example 1

Input

```json
{
  "beta": 2,
  "pairs": [
    {
      "chosen": {
        "policy": [
          -8,
          -1
        ],
        "reference": [
          -9,
          -1
        ],
        "mask": [
          0,
          1
        ]
      },
      "rejected": {
        "policy": [
          -5,
          -2
        ],
        "reference": [
          -6,
          -2
        ],
        "mask": [
          0,
          1
        ]
      }
    }
  ]
}
```

Expected output

```json
{
  "loss": 0.6931471805599453,
  "gradients": [
    -1.0
  ]
}
```

After masking the first token, both models have the same preference. The margin is zero, the loss is log(2), and the derivative is −beta/2.

## Example 2

Input

```json
{
  "beta": 1,
  "pairs": []
}
```

Expected output

```json
{
  "loss": null,
  "gradients": []
}
```

An empty worker batch has no mean loss to report.

## Part 1 · Implement the preference objective

sequence_scores.py · completion(logps, mask) — logps contains per-token log probabilities already aligned to the predicted token. Sum only entries whose binary completion mask is 1. Prompt/padding positions have 0. Empty completion scores zero.

preferences.py · margin(pair) — pair has chosen and rejected records. Each record has policy, reference and mask arrays of equal length. Return (policy_chosen - policy_rejected) - (reference_chosen - reference_rejected) using completion sums.

objective.py · batch(pairs, beta) — For beta>0 return [mean_loss, gradients] where each example loss is -log(sigmoid(beta*margin)). gradients[i] is derivative of the mean loss with respect to that example's unscaled margin. Handle extreme margins without overflow. Empty batch returns [None, []].

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
