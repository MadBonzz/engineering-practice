"""Reduce a numerically stable loss and derivatives over a batch."""

import math
from preferences import margin


def batch(pairs, beta):
    """For beta>0 return [mean_loss, gradients] where each example loss is
    -log(sigmoid(beta*margin)). gradients[i] is derivative of the mean
    loss with respect to that example's unscaled margin. Handle extreme
    margins without overflow. Empty batch returns [None, []].
    """
    raise NotImplementedError("objective.batch")
