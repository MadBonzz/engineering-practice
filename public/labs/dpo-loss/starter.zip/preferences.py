"""Measure a policy preference relative to the reference."""

from sequence_scores import completion


def margin(pair):
    """pair has chosen and rejected records. Each record has policy, reference
    and mask arrays of equal length. Return (policy_chosen -
    policy_rejected) - (reference_chosen - reference_rejected) using
    completion sums.
    """
    raise NotImplementedError("preferences.margin")
