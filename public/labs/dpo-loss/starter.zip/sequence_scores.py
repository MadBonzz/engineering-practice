"""Mask and aggregate per-token log probabilities."""



def completion(logps, mask):
    """logps contains per-token log probabilities already aligned to the
    predicted token. Sum only entries whose binary completion mask is 1.
    Prompt/padding positions have 0. Empty completion scores zero.
    """
    raise NotImplementedError("sequence_scores.completion")
