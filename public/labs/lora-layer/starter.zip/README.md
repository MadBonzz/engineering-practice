# LoRA linear layer

A training service adapts a frozen projection for one customer. Its serving tier can load only an ordinary weight matrix. Implement the adapter, the update, and the export so that one training step produces a deployable projection.

## Your task

weight, a and b are matrices of shapes [out,in], [rank,in] and [out,rank]. x is an input vector, target is an output vector, alpha scales the adapter and lr is the learning rate.

Return before and after (the output vectors before and after one SGD step), plus merged (the post-step standalone weight matrix). The base weight and incoming adapter arrays must stay unchanged.

## Constraints

Rank is positive. Use loss 0.5 × sum of squared output errors. Both adapter gradients use the same pre-update parameters. Scale the adapter by alpha/rank. The projection has no bias.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- linear_ops.py (provided) — Provided vector and matrix primitives for the frozen model.

- adapter.py (edit) — Compute an adapted projection with frozen weights.

- optimizer_step.py (edit) — Apply a simultaneous SGD update to the two adapter matrices.

- merge_weights.py (edit) — Materialize a standalone matrix compatible with the serving model.

## Example 1

Input

```json
{
  "weight": [
    [
      1
    ]
  ],
  "a": [
    [
      1
    ]
  ],
  "b": [
    [
      0
    ]
  ],
  "x": [
    2
  ],
  "target": [
    4
  ],
  "alpha": 1,
  "lr": 0.25
}
```

Expected output

```json
{
  "before": [
    2
  ],
  "after": [
    4
  ],
  "merged": [
    [
      2
    ]
  ]
}
```

The adapter starts at zero output. The first step changes B from 0 to 1 while A stays at 1. The merged weight is 2 and maps input 2 to 4.

## Example 2

Input

```json
{
  "weight": [
    [
      2
    ]
  ],
  "a": [
    [
      2
    ]
  ],
  "b": [
    [
      1
    ]
  ],
  "x": [
    1
  ],
  "target": [
    0
  ],
  "alpha": 1,
  "lr": 0
}
```

Expected output

```json
{
  "before": [
    4
  ],
  "after": [
    4
  ],
  "merged": [
    [
      4
    ]
  ]
}
```

With a zero learning rate the adapter contributes the same value before and after export.

## Part 1 · Run the adapter

adapter.py · forward(weight, a, b, x, alpha) — Return W x + (alpha/r) B A x. W is [out,in], A [r,in], B [out,r], r>0. All arrays are ordinary lists; no bias. Return a vector without editing the inputs.

## Part 2 · Train only the adapter

optimizer_step.py · update(weight, a, b, x, target, alpha, lr) — One SGD step for loss 0.5*sum((prediction-target)^2). Keep W frozen. Return [new_A,new_B] using gradients from the same pre-update parameters. Do not mutate inputs.

## Part 3 · Merge for deployment

merge_weights.py · merge(weight, a, b, alpha) — Export a standalone weight matrix whose ordinary linear() output agrees with the adapter for any input. Return a new [out,in] matrix; preserve the frozen weights.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
