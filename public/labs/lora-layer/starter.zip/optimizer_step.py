"""Apply a simultaneous SGD update to the two adapter matrices."""

from linear_ops import linear
from adapter import forward


def update(weight, a, b, x, target, alpha, lr):
    """One SGD step for loss 0.5*sum((prediction-target)^2). Keep W frozen.
    Return [new_A,new_B] using gradients from the same pre-update
    parameters. Do not mutate inputs.
    """
    raise NotImplementedError("optimizer_step.update")
