"""Materialize a standalone matrix compatible with the serving model."""



def merge(weight, a, b, alpha):
    """Export a standalone weight matrix whose ordinary linear() output agrees
    with the adapter for any input. Return a new [out,in] matrix;
    preserve the frozen weights.
    """
    raise NotImplementedError("merge_weights.merge")
