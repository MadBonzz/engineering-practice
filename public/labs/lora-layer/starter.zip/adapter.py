"""Compute an adapted projection with frozen weights."""

from linear_ops import linear


def forward(weight, a, b, x, alpha):
    """Return W x + (alpha/r) B A x. W is [out,in], A [r,in], B [out,r], r>0.
    All arrays are ordinary lists; no bias. Return a vector without
    editing the inputs.
    """
    raise NotImplementedError("adapter.forward")
