"""Public service entry point. Each call receives one decoded JSON request."""
from adapter import forward
from optimizer_step import update
from merge_weights import merge
from linear_ops import linear

def handle(request):
    w, a, b = request["weight"], request["a"], request["b"]
    x, alpha = request["x"], request["alpha"]
    before = forward(w, a, b, x, alpha)
    a, b = update(w, a, b, x, request["target"], alpha, request["lr"])
    merged = merge(w, a, b, alpha)
    return {"before": before, "after": linear(merged, x), "merged": merged}
