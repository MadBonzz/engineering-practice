import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'a': [[1]],
 'alpha': 1,
 'b': [[0]],
 'lr': 0.25,
 'target': [4],
 'weight': [[1]],
 'x': [2]}
        expected = {'after': [4], 'before': [2], 'merged': [[2]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'a': [[2]],
 'alpha': 1,
 'b': [[1]],
 'lr': 0,
 'target': [0],
 'weight': [[2]],
 'x': [1]}
        expected = {'after': [4], 'before': [4], 'merged': [[4]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
