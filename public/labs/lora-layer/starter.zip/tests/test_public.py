import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_forward_example_1(self):
        args = [[[0.0, -0.3]], [[0.2, 0.4]], [[0.0]], [0.0, -1.0], 0.5]
        observed = trial('forward', args)
        expected = {'return': [0.3]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_forward_example_2(self):
        args = [[[0.3, 0.0, -0.3], [0.6, 0.3, 0.0]],
 [[0.2, 0.4, 0.6000000000000001], [0.4, 0.6000000000000001, 0.8]],
 [[0.4, 0.0], [0.8, 0.4]],
 [0.2, -1.2, 2.2],
 1.5]
        observed = trial('forward', args)
        expected = {'return': [-0.33599999999999997, 0.6240000000000003]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_update_example_1(self):
        args = [[[0.0, -0.3]], [[0.2, 0.4]], [[0.0]], [0.0, -1.0], [0.5], 0.5, 0.1]
        observed = trial('update', args)
        expected = {'return': [[[0.2, 0.4]], [[-0.004000000000000001]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_update_example_2(self):
        args = [[[0.3, 0.0, -0.3], [0.6, 0.3, 0.0]],
 [[0.2, 0.4, 0.6000000000000001], [0.4, 0.6000000000000001, 0.8]],
 [[0.4, 0.0], [0.8, 0.4]],
 [0.2, -1.2, 2.2],
 [0.5, 0.5],
 1.5,
 0.1]
        observed = trial('update', args)
        expected = {'return': [[[0.20352800000000001, 0.37883200000000006, 0.638808],
             [0.399256, 0.6044640000000001, 0.7918160000000001]],
            [[0.455176, 0.07022400000000001], [0.791816, 0.389584]]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part3(unittest.TestCase):
    def test_merge_example_1(self):
        args = [[[0.0, -0.3]], [[0.2, 0.4]], [[0.0]], 0.5]
        observed = trial('merge', args)
        expected = {'return': [[0.0, -0.3]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_merge_example_2(self):
        args = [[[0.3, 0.0, -0.3], [0.6, 0.3, 0.0]],
 [[0.2, 0.4, 0.6000000000000001], [0.4, 0.6000000000000001, 0.8]],
 [[0.4, 0.0], [0.8, 0.4]],
 1.5]
        observed = trial('merge', args)
        expected = {'return': [[0.36, 0.12000000000000002, -0.11999999999999994],
            [0.8400000000000001, 0.72, 0.6000000000000001]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

