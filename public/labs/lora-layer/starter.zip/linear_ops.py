"""Provided vector and matrix primitives for the frozen model."""



def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def linear(weight, x):
    return [dot(row, x) for row in weight]
