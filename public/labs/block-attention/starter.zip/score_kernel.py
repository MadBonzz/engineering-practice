"""Score the current block's keys against one query."""

import math


def scores(query, keys):
    """Return scaled dot products q.k/sqrt(query width) in key order. Empty keys
    return [].
    """
    raise NotImplementedError("score_kernel.scores")
