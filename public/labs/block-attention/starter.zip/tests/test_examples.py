import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'blocks': [[[[2]], [[4]]], [[[8]], [[10]]]],
 'query': [0],
 'value_width': 1}
        expected = {'context': [7]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'blocks': [[[], []]], 'query': [1], 'value_width': 2}
        expected = {'context': [0, 0]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
