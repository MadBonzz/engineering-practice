"""Public service entry point. Each call receives one decoded JSON request."""
from attention_worker import attention

def handle(request):
    context = attention(request["query"], request["blocks"], request["value_width"])
    return {"context": context}
