"""Consume blocks and finalize the output."""

from score_kernel import scores
from online_state import absorb


def attention(query, blocks, value_width):
    """Blocks are [keys,values] pairs, possibly empty. Produce the normalized
    attention output using a streaming pass with working storage
    proportional to one block plus the output width. Return a zero vector
    when all blocks are empty.
    """
    raise NotImplementedError("attention_worker.attention")
