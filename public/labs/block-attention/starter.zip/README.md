# Blockwise attention

A worker can read only one block of keys and values at a time. Complete its attention reducer so a change in block boundaries has no effect on the answer and a large score does not overflow the softmax.

## Your task

query is a nonempty vector. blocks is a list of [keys, values] pairs. Each value vector has value_width components. Each key has the same width as the query.

Return {context: [...]} containing the softmax-weighted sum over every key/value pair in all blocks. When there are no keys, return a zero vector of value_width.

## Constraints

Keep working storage proportional to one block plus the output width. Scale dot products by the square root of the query width. Empty blocks can occur anywhere.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- score_kernel.py (edit) — Score the current block's keys against one query.

- online_state.py (edit) — Maintain the running maximum, mass and weighted values.

- attention_worker.py (edit) — Consume blocks and finalize the output.

## Example 1

Input

```json
{
  "query": [
    0
  ],
  "value_width": 1,
  "blocks": [
    [
      [
        [
          2
        ]
      ],
      [
        [
          4
        ]
      ]
    ],
    [
      [
        [
          8
        ]
      ],
      [
        [
          10
        ]
      ]
    ]
  ]
}
```

Expected output

```json
{
  "context": [
    7
  ]
}
```

Both dot products are zero, so both values receive weight 1/2 even though they arrive in separate blocks.

## Example 2

Input

```json
{
  "query": [
    1
  ],
  "value_width": 2,
  "blocks": [
    [
      [],
      []
    ]
  ]
}
```

Expected output

```json
{
  "context": [
    0,
    0
  ]
}
```

An empty block contributes no mass. The output still has the configured value width.

## Part 1 · Accumulate stable block statistics

score_kernel.py · scores(query, keys) — Return scaled dot products q.k/sqrt(query width) in key order. Empty keys return [].

online_state.py · absorb(state, logits, values) — State is [max_logit, scaled_mass, weighted_vector]; empty uses None, 0, zeros. Fold in a block and return a new state. Both mass and vector are expressed relative to the maximum logit seen over all blocks (weights exp(logit-max)). Empty blocks are identity. Never exponentiate an unshifted large logit.

## Part 2 · Stream an attention result

attention_worker.py · attention(query, blocks, value_width) — Blocks are [keys,values] pairs, possibly empty. Produce the normalized attention output using a streaming pass with working storage proportional to one block plus the output width. Return a zero vector when all blocks are empty.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
