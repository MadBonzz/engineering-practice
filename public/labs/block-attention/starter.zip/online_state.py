"""Maintain the running maximum, mass and weighted values."""

import math


def absorb(state, logits, values):
    """State is [max_logit, scaled_mass, weighted_vector]; empty uses None, 0,
    zeros. Fold in a block and return a new state. Both mass and vector
    are expressed relative to the maximum logit seen over all blocks
    (weights exp(logit-max)). Empty blocks are identity. Never
    exponentiate an unshifted large logit.
    """
    raise NotImplementedError("online_state.absorb")
