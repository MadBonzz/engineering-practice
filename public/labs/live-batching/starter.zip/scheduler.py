"""Decide who runs next and who stays queued."""

from batch_executor import step


def tick(active, waiting, capacity):
    """Active and waiting rows have the same shape as step(). Fill vacant slots
    FIFO behind existing active rows, then advance all admitted rows
    once. Return [surviving_rows, still_waiting_rows, emitted_pairs].
    Surviving rows contain the updated state and remaining count. Pairs
    are [id, token] in batch order. Finished slots become available next
    tick.
    """
    raise NotImplementedError("scheduler.tick")
