"""Pair model outputs with the requests that produced them."""

from token_model import model_batch


def step(rows):
    """Rows are [request_id, state, remaining]. Make one model_batch call for
    the whole nonempty batch. Return [id, token, new_state,
    remaining_after] in the input order. Empty input returns [].
    """
    raise NotImplementedError("batch_executor.step")
