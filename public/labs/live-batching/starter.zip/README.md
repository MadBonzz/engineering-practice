# Live continuous batching

Two clients share one decoding worker. A short request should be able to leave while a longer request continues, and a waiting request should take the free slot on the next tick. Complete the serving loop and return enough information to audit when each client finished.

## Your task

capacity is the maximum active requests. requests are [arrival_tick, request_id, prompt_token_ids, output_budget], ordered by arrival. The supplied token model defines the greedy output for each state.

timeline contains the [id, token] emissions at each tick, beginning at tick 0. finished_at maps each ID to the zero-based tick of its last emission.

## Constraints

Request IDs are unique. Capacity and budgets are positive. Ties use input order; active requests keep their order. Admit before decoding and release completed slots after decoding.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- token_model.py (provided) — Prefill prompts and generate one deterministic batch.

- batch_executor.py (edit) — Pair model outputs with the requests that produced them.

- scheduler.py (edit) — Decide who runs next and who stays queued.

- serving_loop.py (edit) — Own the arrival clock and advance it through the last emission.

## Example 1

Input

```json
{
  "capacity": 1,
  "requests": [
    [
      1,
      "a",
      [],
      1
    ],
    [
      1,
      "b",
      [],
      1
    ]
  ]
}
```

Expected output

```json
{
  "timeline": [
    [],
    [
      [
        "a",
        2
      ]
    ],
    [
      [
        "b",
        2
      ]
    ]
  ],
  "finished_at": {
    "a": 1,
    "b": 2
  }
}
```

Tick 0 is idle. Both clients arrive at tick 1. With one slot, a runs first and b starts at tick 2. Both empty prompts start in the same model state.

## Example 2

Input

```json
{
  "capacity": 2,
  "requests": []
}
```

Expected output

```json
{
  "timeline": [],
  "finished_at": {}
}
```

There is no arrival or emission, so no tick is recorded.

## Part 1 · Execute one model batch

batch_executor.py · step(rows) — Rows are [request_id, state, remaining]. Make one model_batch call for the whole nonempty batch. Return [id, token, new_state, remaining_after] in the input order. Empty input returns [].

## Part 2 · Admit and retire requests

scheduler.py · tick(active, waiting, capacity) — Active and waiting rows have the same shape as step(). Fill vacant slots FIFO behind existing active rows, then advance all admitted rows once. Return [surviving_rows, still_waiting_rows, emitted_pairs]. Surviving rows contain the updated state and remaining count. Pairs are [id, token] in batch order. Finished slots become available next tick.

## Part 3 · Serve the arrival stream

serving_loop.py · dispatch(requests, capacity) — Requests are [arrival_tick, id, prompt_tokens, positive_budget], in arrival order. Starting at tick zero, append arrivals before admission. Prefill each once using new_state. Return the list of emitted-pair lists per tick including idle ticks, ending at final emission. Empty input returns []. Capacity is positive.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
