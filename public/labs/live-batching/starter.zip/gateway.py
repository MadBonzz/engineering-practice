"""Public service entry point. Each call receives one decoded JSON request."""
from serving_loop import dispatch

def handle(request):
    timeline = dispatch(request["requests"], request["capacity"])
    finished = {}
    for tick, emissions in enumerate(timeline):
        for request_id, _ in emissions:
            finished[request_id] = tick
    return {"timeline": timeline, "finished_at": finished}
