import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'capacity': 1, 'requests': [[1, 'a', [], 1], [1, 'b', [], 1]]}
        expected = {'finished_at': {'a': 1, 'b': 2}, 'timeline': [[], [['a', 2]], [['b', 2]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'capacity': 2, 'requests': []}
        expected = {'finished_at': {}, 'timeline': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
