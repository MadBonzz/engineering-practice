"""Prefill prompts and generate one deterministic batch."""



def new_state(prompt):
    """Prefill the supplied recurrent token model."""
    state = 0
    for token in prompt:
        state = (state*3 + token + 1) % 11
    return state


def model_batch(states):
    """One real batched greedy step of a tiny deterministic model. Returns (token, new_state) pairs."""
    result = []
    for state in states:
        token = max(range(5), key=lambda t: ((state + 2)*(t + 1) + t*t) % 13)
        result.append((token, (state*3 + token + 1) % 11))
    return result
