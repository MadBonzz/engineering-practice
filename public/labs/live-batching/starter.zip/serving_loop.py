"""Own the arrival clock and advance it through the last emission."""

from token_model import new_state
from scheduler import tick


def dispatch(requests, capacity):
    """Requests are [arrival_tick, id, prompt_tokens, positive_budget], in
    arrival order. Starting at tick zero, append arrivals before
    admission. Prefill each once using new_state. Return the list of
    emitted-pair lists per tick including idle ticks, ending at final
    emission. Empty input returns []. Capacity is positive.
    """
    raise NotImplementedError("serving_loop.dispatch")
