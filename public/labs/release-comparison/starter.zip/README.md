# Release comparison

An evaluation dashboard must decide whether to promote a candidate model. Two workers label each prompt independently and can correct or withdraw a label. Build the ledger and rollout report so the dashboard always reflects the latest comparable outcomes.

## Your task

events is a stream of [prompt_id, model, revision, correct] updates in delivery order. model is 'baseline' or 'candidate'; correct is true, false, or null for a withdrawal. min_pairs is the minimum number of comparable prompts.

Return paired, wins, losses, ties, and decision. A candidate-only correct answer is a win. Promote when the paired sample meets min_pairs and wins exceed losses; otherwise hold.

## Constraints

Revision order is per (prompt, model). Repeated deliveries at the same revision agree. A missing or withdrawn label excludes that prompt until both labels are available. A false label is a valid observation.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- events.py (provided) — Supplied event decoder used at the service boundary.

- ledger.py (edit) — Apply updates and expose the current outcomes.

- report.py (edit) — Produce the decision consumed by the dashboard.

## Example 1

Input

```json
{
  "events": [
    [
      "p1",
      "baseline",
      1,
      false
    ],
    [
      "p1",
      "candidate",
      1,
      true
    ]
  ],
  "min_pairs": 1
}
```

Expected output

```json
{
  "paired": 1,
  "wins": 1,
  "losses": 0,
  "ties": 0,
  "decision": "promote"
}
```

Both labels exist on p1 and only the candidate is correct. The sample meets the threshold and the candidate has more wins than losses.

## Example 2

Input

```json
{
  "events": [
    [
      "p1",
      "baseline",
      1,
      false
    ],
    [
      "p1",
      "candidate",
      1,
      true
    ],
    [
      "p1",
      "candidate",
      2,
      null
    ]
  ],
  "min_pairs": 1
}
```

Expected output

```json
{
  "paired": 0,
  "wins": 0,
  "losses": 0,
  "ties": 0,
  "decision": "hold"
}
```

Revision 2 withdraws the candidate label. The previously comparable prompt drops out of the current report.

## Part 1 · Track updates

An Event has a prompt ID, model ("baseline" or "candidate"), nonnegative integer revision, and correct (True, False, or None). All inputs are valid. Ingest events in any delivery order. For each prompt and model, the greatest revision received is authoritative. A newer None withdraws the label. Repeated deliveries at the same revision have identical contents.

latest(prompt, model) returns the current boolean or None for an absent or withdrawn label. prompts() includes every observed prompt, even after withdrawal. Calls to latest() and pair() are read-only.

## Part 2 · Match outcomes

pair(prompt) returns (baseline_correct, candidate_correct) if both current labels are available. Return None otherwise. A false outcome is a valid label. Reads may occur between any two updates.

## Part 3 · Decide a release

summarize(ledger, min_pairs) returns a dictionary with paired, wins, losses, ties, and decision. Count each currently comparable prompt once. A win means only the candidate is correct, a loss means only the baseline is correct, and equal labels are a tie. Incomplete prompts contribute nothing.

min_pairs is a positive integer. Return "promote" when paired >= min_pairs and wins > losses. Otherwise return "hold". The report must reflect all updates received before the call.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
