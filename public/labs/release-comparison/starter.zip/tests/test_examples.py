import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [['p1', 'baseline', 1, False], ['p1', 'candidate', 1, True]],
 'min_pairs': 1}
        expected = {'decision': 'promote', 'losses': 0, 'paired': 1, 'ties': 0, 'wins': 1}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['p1', 'baseline', 1, False],
            ['p1', 'candidate', 1, True],
            ['p1', 'candidate', 2, None]],
 'min_pairs': 1}
        expected = {'decision': 'hold', 'losses': 0, 'paired': 0, 'ties': 0, 'wins': 0}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
