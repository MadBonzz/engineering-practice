"""Public service entry point. Each call receives one decoded JSON request."""
from events import read_events
from ledger import OutcomeLedger
from report import summarize

def handle(request):
    ledger = OutcomeLedger()
    for event in read_events(request["events"]):
        ledger.ingest(event)
    return summarize(ledger, request["min_pairs"])
