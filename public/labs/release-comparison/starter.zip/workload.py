import math

def equivalent(a,b):
    return a == b
