import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'mode': 'document',
 'repeats': 20,
 'rows': [['d1', 0, 1], ['d1', 1, 1]],
 'seed': 4}
        expected = {'ci95': [0.5, 0.5], 'delta': 0.5}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'mode': 'row', 'repeats': 5, 'rows': [], 'seed': 7}
        expected = {'ci95': [None, None], 'delta': None}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
