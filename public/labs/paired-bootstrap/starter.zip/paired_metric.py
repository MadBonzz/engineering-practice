"""Calculate the observed paired score change."""



def delta(rows):
    """Each row is [document_id, score_A, score_B]. Return mean(B-A) over rows
    or None if empty. Each row is a paired measurement.
    """
    raise NotImplementedError("paired_metric.delta")
