"""Build one replicate under the chosen sampling unit."""

from paired_metric import delta


def replicate(rows, units, mode):
    """units is a with-replacement list of row indices (mode='row') or document
    IDs (mode='document'). In document mode each occurrence contributes
    all its original rows. Compute the row-weighted paired delta across
    the selected records, including repeated units. Empty selection
    returns None.
    """
    raise NotImplementedError("resampling.replicate")
