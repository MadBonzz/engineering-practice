"""Drive the seeded experiment and interpolate its endpoints."""

import random
from paired_metric import delta
from resampling import replicate


def interval(rows, mode, repeats, seed):
    """Return [observed_delta, lower, upper]. Sample as many units as originally
    present, with replacement, for each of repeats>=1 replicates. Use one
    random.Random(seed), randrange(len(units)) for each draw, in order.
    Row units are indices; document units occur in first-appearance
    order. Use linear interpolation at (N-1)*p of the sorted replicate
    deltas for p=.025 and .975. Empty dataset returns three nulls.
    """
    raise NotImplementedError("confidence.interval")
