# Paired statistical comparison

A release reviewer wants an uncertainty interval for a model improvement. Both models answered the same questions, and several questions can come from one document. Implement the paired statistic and let the reviewer choose the sampling unit.

## Your task

rows contains [document_id, score_A, score_B]. mode is 'row' or 'document'. repeats is the number of resamples and seed fixes their random draws.

Return delta (mean B minus A across original rows) and ci95 (lower and upper bootstrap percentiles). Use null for undefined statistics.

## Constraints

Sample units with replacement. Each repeated document contributes every one of its rows again. Use the seeded draw order and percentile interpolation specified in the interval contract so reviews can be reproduced.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- paired_metric.py (edit) — Calculate the observed paired score change.

- resampling.py (edit) — Build one replicate under the chosen sampling unit.

- confidence.py (edit) — Drive the seeded experiment and interpolate its endpoints.

## Example 1

Input

```json
{
  "rows": [
    [
      "d1",
      0,
      1
    ],
    [
      "d1",
      1,
      1
    ]
  ],
  "mode": "document",
  "repeats": 20,
  "seed": 4
}
```

Expected output

```json
{
  "delta": 0.5,
  "ci95": [
    0.5,
    0.5
  ]
}
```

The paired changes are 1 and 0. There is just one document to resample, so every replicate includes both rows and has mean 0.5.

## Example 2

Input

```json
{
  "rows": [],
  "mode": "row",
  "repeats": 5,
  "seed": 7
}
```

Expected output

```json
{
  "delta": null,
  "ci95": [
    null,
    null
  ]
}
```

There is no question to compare or resample.

## Part 1 · Estimate paired improvements

paired_metric.py · delta(rows) — Each row is [document_id, score_A, score_B]. Return mean(B-A) over rows or None if empty. Each row is a paired measurement.

resampling.py · replicate(rows, units, mode) — units is a with-replacement list of row indices (mode='row') or document IDs (mode='document'). In document mode each occurrence contributes all its original rows. Compute the row-weighted paired delta across the selected records, including repeated units. Empty selection returns None.

## Part 2 · Construct the interval

confidence.py · interval(rows, mode, repeats, seed) — Return [observed_delta, lower, upper]. Sample as many units as originally present, with replacement, for each of repeats>=1 replicates. Use one random.Random(seed), randrange(len(units)) for each draw, in order. Row units are indices; document units occur in first-appearance order. Use linear interpolation at (N-1)*p of the sorted replicate deltas for p=.025 and .975. Empty dataset returns three nulls.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
