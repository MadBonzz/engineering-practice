"""Public service entry point. Each call receives one decoded JSON request."""
from confidence import interval

def handle(request):
    delta, low, high = interval(request["rows"], request["mode"], request["repeats"], request["seed"])
    return {"delta": delta, "ci95": [low, high]}
