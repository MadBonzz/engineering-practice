"""Public service entry point. Each call receives one decoded JSON request."""
from stream_worker import serve
from session_pool import SessionPool

def handle(request):
    layers = request["layers"]
    if "events" in request:
        pool = SessionPool(layers)
        replies = []
        for session, event, tokens in request["events"]:
            if event == "close":
                pool.close(session)
                replies.append(None)
            else:
                replies.append(pool.push(session, tokens))
        return {"replies": replies}
    chunks = request["chunks"]
    return {"logits": serve(chunks, layers), "tokens_processed": sum(map(len, chunks))}
