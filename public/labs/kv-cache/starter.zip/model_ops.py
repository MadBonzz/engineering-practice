"""Fixed projections and attention used by both decoding paths."""

import math


def project(hidden, layer, position):
    """Fixed two-component projections. Position is the absolute token offset."""
    x, y = hidden
    angle = position * 0.37
    c, s = math.cos(angle), math.sin(angle)
    def rotate(a, b):
        return [a*c-b*s, a*s+b*c]
    return rotate(x, y+layer), rotate(y, x-layer), [x+y, y-x]


def attend(query, keys, values):
    scores = [sum(a*b for a, b in zip(query, key)) / math.sqrt(2) for key in keys]
    weights = [math.exp(s-max(scores)) for s in scores]
    return [sum(w*v[d] for w, v in zip(weights, values))/sum(weights) for d in range(2)]
