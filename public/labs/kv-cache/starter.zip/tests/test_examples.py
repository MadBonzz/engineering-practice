import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'chunks': [[0], []], 'layers': 1}
        expected = {'logits': [[[1, 2, -1]], []], 'tokens_processed': 1}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['a', 'push', [0]],
            ['b', 'push', [0]],
            ['a', 'close', []],
            ['a', 'push', [0]]],
 'layers': 1}
        expected = {'replies': [[[1, 2, -1]], [[1, 2, -1]], None, [[1, 2, -1]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
