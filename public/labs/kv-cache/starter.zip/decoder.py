"""Advance one token through all layers and produce its logits."""

import math
from layer_cache import advance


def decode(token, cache):
    """Each layer has a mutable [keys, values] pair. Embed integer t as [sin(t),
    cos(t)]. Pass through layers in ascending zero-based order, using
    each layer's existing token count as position. Return logits [x, y,
    x-y] from the final hidden state. Mutate the supplied cache without
    recomputing earlier projections.
    """
    raise NotImplementedError("decoder.decode")
