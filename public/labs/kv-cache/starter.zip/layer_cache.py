"""Append a token's keys and values, then read that layer's history."""

from model_ops import attend, project


def advance(hidden, layer, position, keys, values):
    """Project this token once with project(), append K and V in place, attend
    over the extended history, and return the input hidden vector plus
    the attention output elementwise.
    """
    raise NotImplementedError("layer_cache.advance")
