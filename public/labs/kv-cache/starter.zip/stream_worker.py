"""Own the cache over the lifetime of a chunked request."""

from decoder import decode


def serve(chunks, layers):
    """Start an empty multilayer cache. Consume token chunks consecutively, even
    across empty chunks. Return one list of per-token logit vectors per
    chunk. Chunk boundaries must not reset positions. Each new token may
    call project exactly once per layer.
    """
    raise NotImplementedError("stream_worker.serve")
