# Per-layer KV cache

A chat server receives a prompt, then receives one or more continuation chunks for the same request. Its current decoder recomputes the whole prefix every time. Finish the incremental path. The caller must see exactly the same next-token scores as the supplied full-prefix decoder, even when an empty chunk arrives between two tokens.

## Your task

layers is the positive number of decoder layers. chunks is an ordered list of lists of integer token IDs from a single request. The first chunk is prefill; the remaining chunks continue the same sequence. For interleaved traffic, replace chunks with events of [request_id, operation, token_list]; operation is 'push' or 'close'.

Return logits grouped by input chunk. Each token produces three logits in model vocabulary order. Also return tokens_processed, the number of real tokens across all chunks. Event mode returns {replies: [...]} with one list of token logits per push and null per close.

## Constraints

Use the provided two-dimensional projections and attention routine. Keep an independent key/value history per layer. Use absolute positions across chunk boundaries. Project each new token once per layer. Numeric tolerances are specified below. A push creates a missing session. Close discards all layers for that ID; closing an absent session is harmless. A later push to that ID starts at position zero.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- model_ops.py (provided) — Fixed projections and attention used by both decoding paths.

- layer_cache.py (edit) — Append a token's keys and values, then read that layer's history.

- decoder.py (edit) — Advance one token through all layers and produce its logits.

- stream_worker.py (edit) — Own the cache over the lifetime of a chunked request.

- session_pool.py (edit) — Own an independent cache per client and free it on close.

## Example 1

Input

```json
{
  "layers": 1,
  "chunks": [
    [
      0
    ],
    []
  ]
}
```

Expected output

```json
{
  "logits": [
    [
      [
        1,
        2,
        -1
      ]
    ],
    []
  ],
  "tokens_processed": 1
}
```

Token 0 embeds to [0, 1]. With one cached token, its attention weight is 1. The model adds [1, 1] to the embedding and reads logits from [1, 2]. The empty chunk emits no logits.

## Example 2

Input

```json
{
  "layers": 1,
  "events": [
    [
      "a",
      "push",
      [
        0
      ]
    ],
    [
      "b",
      "push",
      [
        0
      ]
    ],
    [
      "a",
      "close",
      []
    ],
    [
      "a",
      "push",
      [
        0
      ]
    ]
  ]
}
```

Expected output

```json
{
  "replies": [
    [
      [
        1,
        2,
        -1
      ]
    ],
    [
      [
        1,
        2,
        -1
      ]
    ],
    null,
    [
      [
        1,
        2,
        -1
      ]
    ]
  ]
}
```

The first token for b starts at position zero even though a is active. Closing a discards its cache; reusing that ID produces the first-token logits again.

## Part 1 · Append one attention state

layer_cache.py · advance(hidden, layer, position, keys, values) — Project this token once with project(), append K and V in place, attend over the extended history, and return the input hidden vector plus the attention output elementwise.

## Part 2 · Decode across layers

decoder.py · decode(token, cache) — Each layer has a mutable [keys, values] pair. Embed integer t as [sin(t), cos(t)]. Pass through layers in ascending zero-based order, using each layer's existing token count as position. Return logits [x, y, x-y] from the final hidden state. Mutate the supplied cache without recomputing earlier projections.

## Part 3 · Continue across chunk boundaries

stream_worker.py · serve(chunks, layers) — Start an empty multilayer cache. Consume token chunks consecutively, even across empty chunks. Return one list of per-token logit vectors per chunk. Chunk boundaries must not reset positions. Each new token may call project exactly once per layer.

Complete SessionPool.push and close for interleaved requests. Each push must use the current state for that ID; close retires it. A fresh request may reuse the same ID.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
