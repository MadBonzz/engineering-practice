"""Runtime boundary used by the gateway when several sessions share a worker."""
from decoder import decode


class SessionPool:
    def __init__(self, layers):
        self.layers = layers
        self.requests = {}

    def push(self, request_id, tokens):
        """Decode a chunk against this request's live layer states; return its logits."""
        raise NotImplementedError("SessionPool.push")

    def close(self, request_id):
        """Retire this session. Reusing its ID must start a fresh sequence."""
        raise NotImplementedError("SessionPool.close")
