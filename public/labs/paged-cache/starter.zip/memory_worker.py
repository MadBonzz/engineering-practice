"""Maintain per-request tables while processing allocation events."""

from block_pool import reserve
from page_table import locate


def replay(block_count, block_size, events):
    """Initially all numbered blocks are free. 'append', id, n reserves
    atomically and returns the physical addresses of n new tokens; return
    null on capacity failure. 'release', id frees the entire request and
    returns null (unknown is a no-op). 'free' returns sorted free IDs.
    Return one output per event. A released ID can start again at length
    zero.
    """
    raise NotImplementedError("memory_worker.replay")
