"""Public service entry point. Each call receives one decoded JSON request."""
from memory_worker import replay

def handle(request):
    events = request["events"]
    replies = replay(request["blocks"], request["block_size"], events)
    failed = sum(event[0] == "append" and reply is None for event, reply in zip(events, replies))
    return {"replies": replies, "failed_appends": failed}
