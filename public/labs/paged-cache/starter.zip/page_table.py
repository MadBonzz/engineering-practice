"""Translate logical token offsets into physical addresses."""



def locate(table, offset, block_size):
    """Return [physical_block, slot] for an allocated zero-based logical token
    offset. Caller supplies a valid offset.
    """
    raise NotImplementedError("page_table.locate")
