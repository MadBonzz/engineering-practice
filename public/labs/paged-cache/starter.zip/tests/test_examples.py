import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'block_size': 2,
 'blocks': 1,
 'events': [['append', 'a', 1],
            ['append', 'a', 2],
            ['append', 'a', 1],
            ['free']]}
        expected = {'failed_appends': 1, 'replies': [[[0, 0]], None, [[0, 1]], []]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'block_size': 1,
 'blocks': 2,
 'events': [['append', 'a', 1],
            ['release', 'a'],
            ['append', 'b', 1],
            ['free']]}
        expected = {'failed_appends': 0, 'replies': [[[0, 0]], None, [[0, 0]], [1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
