import unittest
from workload import equivalent, trial


class Part1(unittest.TestCase):
    def test_reserve_example_1(self):
        args = [[4], [0, 2, 5], 1, 0, 1]
        observed = trial('reserve', args)
        expected = {'return': [[4], [0, 2, 5], True]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_reserve_example_2(self):
        args = [[4], [0, 2, 5], 2, 1, 2]
        observed = trial('reserve', args)
        expected = {'return': [[4, 0], [2, 5], True]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part2(unittest.TestCase):
    def test_locate_example_1(self):
        args = [[3, 0, 2], 0, 1]
        observed = trial('locate', args)
        expected = {'return': [3, 0]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_locate_example_2(self):
        args = [[3, 0, 2], 1, 2]
        observed = trial('locate', args)
        expected = {'return': [3, 1]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))


class Part3(unittest.TestCase):
    def test_replay_example_1(self):
        args = [3,
 1,
 [['append', 'a', 1],
  ['append', 'b', 1],
  ['append', 'a', 1],
  ['append', 'c', 4],
  ['free'],
  ['release', 'b'],
  ['append', 'c', 1],
  ['release', 'a'],
  ['release', 'a'],
  ['append', 'a', 0],
  ['release', 'c'],
  ['free']]]
        observed = trial('replay', args)
        expected = {'return': [[[0, 0]],
            [[1, 0]],
            [[2, 0]],
            None,
            [],
            None,
            [[1, 0]],
            None,
            None,
            [],
            None,
            [0, 1, 2]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

    def test_replay_example_2(self):
        args = [3,
 2,
 [['append', 'a', 1],
  ['append', 'b', 2],
  ['append', 'a', 2],
  ['append', 'c', 8],
  ['free'],
  ['release', 'b'],
  ['append', 'c', 2],
  ['release', 'a'],
  ['release', 'a'],
  ['append', 'a', 1],
  ['release', 'c'],
  ['free']]]
        observed = trial('replay', args)
        expected = {'return': [[[0, 0]],
            [[1, 0], [1, 1]],
            [[0, 1], [2, 0]],
            None,
            [],
            None,
            [[1, 0], [1, 1]],
            None,
            None,
            [[0, 0]],
            None,
            [1, 2]]}
        self.assertTrue(equivalent(observed, expected), (observed, expected))

