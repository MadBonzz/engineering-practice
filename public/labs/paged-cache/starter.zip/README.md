# Paged KV-cache allocator

An inference server has a fixed pool of equally sized KV blocks. Several requests grow and finish in interleaved order. Build the allocator and event loop so that an append either reserves every requested slot or leaves the pool exactly as it was.

## Your task

blocks is the number of physical blocks and block_size is tokens per block. events contains ['append', id, count], ['release', id], or ['free'].

Return replies in event order. A successful append returns [physical_block, slot] for each new token; capacity failure and release return null. A free query returns sorted free block IDs. Also return failed_appends.

## Constraints

Blocks start free and are numbered from zero. Allocate the lowest available IDs. Count zero is valid. Reuse the tail of a request's last block before allocating another block. Releasing an unknown ID is harmless.

## Codebase

Start at gateway.py. The command-line caller is run_lab.py. Standard-library Python only.

- gateway.py (provided) — Start here. Follow the request from the public service into the components you own.

- block_pool.py (edit) — Decide whether a request can grow and reserve its backing blocks.

- page_table.py (edit) — Translate logical token offsets into physical addresses.

- memory_worker.py (edit) — Maintain per-request tables while processing allocation events.

## Example 1

Input

```json
{
  "blocks": 1,
  "block_size": 2,
  "events": [
    [
      "append",
      "a",
      1
    ],
    [
      "append",
      "a",
      2
    ],
    [
      "append",
      "a",
      1
    ],
    [
      "free"
    ]
  ]
}
```

Expected output

```json
{
  "replies": [
    [
      [
        0,
        0
      ]
    ],
    null,
    [
      [
        0,
        1
      ]
    ],
    []
  ],
  "failed_appends": 1
}
```

The second append needs two slots when only one remains. It fails atomically. The next one-token append can still claim slot 1.

## Example 2

Input

```json
{
  "blocks": 2,
  "block_size": 1,
  "events": [
    [
      "append",
      "a",
      1
    ],
    [
      "release",
      "a"
    ],
    [
      "append",
      "b",
      1
    ],
    [
      "free"
    ]
  ]
}
```

Expected output

```json
{
  "replies": [
    [
      [
        0,
        0
      ]
    ],
    null,
    [
      [
        0,
        0
      ]
    ],
    [
      1
    ]
  ],
  "failed_appends": 0
}
```

Releasing a returns block 0 to the pool. The lowest-free-ID rule gives it to b.

## Part 1 · Reserve capacity atomically

block_pool.py · reserve(table, blocks, length, extra, block_size) — Reserve room for extra tokens of this request. table is its ordered list of physical block IDs, blocks the sorted free IDs, length its used token count. Return [new_table, new_free, ok]. Keep old blocks; allocate lowest free IDs first, only as needed. Failure leaves both lists unchanged. Return copies or equivalent values.

## Part 2 · Translate a token address

page_table.py · locate(table, offset, block_size) — Return [physical_block, slot] for an allocated zero-based logical token offset. Caller supplies a valid offset.

## Part 3 · Replay allocation traffic

memory_worker.py · replay(block_count, block_size, events) — Initially all numbered blocks are free. 'append', id, n reserves atomically and returns the physical addresses of n new tokens; return null on capacity failure. 'release', id frees the entire request and returns null (unknown is a no-op). 'free' returns sorted free IDs. Return one output per event. A released ID can start again at length zero.

## Run locally

python run_lab.py fixtures/example_1.json

python -m unittest discover -s tests

You can also pipe a JSON object to python run_lab.py. Use ordinary Python types behind the JSON interface. Numeric answers allow relative error 1e-7 or absolute error 1e-8.
