"""Decide whether a request can grow and reserve its backing blocks."""



def reserve(table, blocks, length, extra, block_size):
    """Reserve room for extra tokens of this request. table is its ordered list
    of physical block IDs, blocks the sorted free IDs, length its used
    token count. Return [new_table, new_free, ok]. Keep old blocks;
    allocate lowest free IDs first, only as needed. Failure leaves both
    lists unchanged. Return copies or equivalent values.
    """
    raise NotImplementedError("block_pool.reserve")
