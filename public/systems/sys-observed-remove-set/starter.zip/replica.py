"""Local operations on a replica's tagged set history."""
def add(state, value, tag):
    """Return fresh state recording value under the previously unused tag. Keep all existing facts."""
    raise NotImplementedError('add')

def discard(state, value):
    """Return fresh state tombstoning every locally known tag for value. Return sorted, duplicate-free tombstones."""
    raise NotImplementedError('discard')

def visible(state):
    """Return distinct values with at least one surviving tag, in lexicographic order."""
    raise NotImplementedError('visible')
