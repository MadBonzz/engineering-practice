# Reconcile an offline set with an observed-remove CRDT

Two offline consoles edit the same set of machine labels. A console removes a label while a peer adds it again. After reconnecting, the network delivers a current update, then an older copy twice. Implement local edits and replica reconciliation so an old packet cannot resurrect a deleted tag and a concurrent add can survive.

## Implementation scope

Build the tombstone-based, state-based observed-remove set. The provided transport freezes packets at send time and lets the caller replay any delivery order. A replica's view can diverge until it receives relevant state. Tombstone collection, disk recovery, and membership changes are outside this exercise.

## Input

A JSON object has replicas (unique replica IDs) and events in execution order. Events are ["add", replica, value], ["remove", replica, value], ["read", replica], ["send", source, packetId], or ["deliver", packetId, destination]. Send saves a full, immutable snapshot under a fresh packet ID. Deliver can replay that snapshot any number of times to any replica.

## Output

Return {"reads":[...],"replicas":{...}}. Each read appends only that replica’s visible list at that moment. replicas maps every replica ID to its final visible list. Sort lists lexicographically, suppress duplicate values, and include empty replicas.

## Constraints

All replicas start empty. Replica IDs are nonempty ASCII letters. Values and packet IDs are nonempty strings. All referenced replicas and packets exist. There are up to 12 replicas and 1,000 events. Each local add gets a globally unique replica#counter tag, including repeated adds of the same value. State is {adds:{tag:value}, removed:[tag,...]}. Keep all bindings and all removal tags. Removing an absent value is a no-op.

## Example 1

Input

~~~json
{
  "replicas": [
    "A",
    "B"
  ],
  "events": [
    [
      "add",
      "A",
      "gpu"
    ],
    [
      "send",
      "A",
      "offer"
    ],
    [
      "deliver",
      "offer",
      "B"
    ],
    [
      "read",
      "B"
    ],
    [
      "remove",
      "B",
      "gpu"
    ],
    [
      "send",
      "B",
      "cancel"
    ],
    [
      "deliver",
      "cancel",
      "A"
    ],
    [
      "read",
      "A"
    ]
  ]
}
~~~

Output

~~~json
{
  "reads": [
    [
      "gpu"
    ],
    []
  ],
  "replicas": {
    "A": [],
    "B": []
  }
}
~~~

B first learns tag A#1 for gpu and reads it. Its removal records A#1. A learns about that removal in cancel.

## Example 2

Input

~~~json
{
  "replicas": [
    "A",
    "B"
  ],
  "events": [
    [
      "add",
      "A",
      "gpu"
    ],
    [
      "send",
      "A",
      "old"
    ],
    [
      "deliver",
      "old",
      "B"
    ],
    [
      "remove",
      "B",
      "gpu"
    ],
    [
      "add",
      "A",
      "gpu"
    ],
    [
      "send",
      "B",
      "rm"
    ],
    [
      "deliver",
      "rm",
      "A"
    ],
    [
      "send",
      "A",
      "new"
    ],
    [
      "deliver",
      "new",
      "B"
    ],
    [
      "deliver",
      "old",
      "B"
    ],
    [
      "read",
      "B"
    ]
  ]
}
~~~

Output

~~~json
{
  "reads": [
    [
      "gpu"
    ]
  ],
  "replicas": {
    "A": [
      "gpu"
    ],
    "B": [
      "gpu"
    ]
  }
}
~~~

B removed A#1. A created A#2 before learning of the removal. The new snapshot carries both facts, and the old copy cannot remove A#2 or restore A#1.

## Part 1 · Record local add and removal facts

Keep tag-level history and derive the visible labels. All updates return fresh state so the network can hold an older version.

replica.py · add(state, value, tag) — Return fresh state recording value under the previously unused tag. Keep all existing facts.

replica.py · discard(state, value) — Return fresh state tombstoning every locally known tag for value. Return sorted, duplicate-free tombstones.

replica.py · visible(state) — Return distinct values with at least one surviving tag, in lexicographic order.

## Part 2 · Merge out-of-order snapshots

Reconcile the two histories. A peer may see the same packet twice or receive a pre-removal snapshot after a post-removal snapshot.

anti_entropy.py · join(local, incoming) — Return a fresh history containing the union of tag bindings and the sorted union of tombstones in both states.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Shapiro et al. · Observed-Remove Set (§3.3.5)](https://www.lip6.fr/Marc.Shapiro/papers/2011/Comprehensive-CRDTs-RR7506-2011-01.pdf)

- [Bieniusa et al. · An Optimized Conflict-Free Replicated Set](https://arxiv.org/abs/1210.3368)
