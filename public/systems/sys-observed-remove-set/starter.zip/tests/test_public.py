import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_remove_two_observed_tags_and_leave_the_unrelated_key(self):
        args = [{'adds': {'A#1': 'x', 'B#1': 'x', 'C#1': 'y'}, 'removed': []}, 'x']
        expected = {'adds': {'A#1': 'x', 'B#1': 'x', 'C#1': 'y'}, 'removed': ['A#1', 'B#1']}
        actual = trial('replica.discard', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_merge_a_concurrent_add_across_a_tombstone(self):
        args = [{'adds': {'A#1': 'gpu'}, 'removed': ['A#1']},
 {'adds': {'A#1': 'gpu', 'B#1': 'gpu'}, 'removed': []}]
        expected = {'adds': {'A#1': 'gpu', 'B#1': 'gpu'}, 'removed': ['A#1']}
        actual = trial('anti_entropy.join', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

