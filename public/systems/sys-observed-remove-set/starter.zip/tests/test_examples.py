import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [['add', 'A', 'gpu'],
            ['send', 'A', 'offer'],
            ['deliver', 'offer', 'B'],
            ['read', 'B'],
            ['remove', 'B', 'gpu'],
            ['send', 'B', 'cancel'],
            ['deliver', 'cancel', 'A'],
            ['read', 'A']],
 'replicas': ['A', 'B']}
        expected = {'reads': [['gpu'], []], 'replicas': {'A': [], 'B': []}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['add', 'A', 'gpu'],
            ['send', 'A', 'old'],
            ['deliver', 'old', 'B'],
            ['remove', 'B', 'gpu'],
            ['add', 'A', 'gpu'],
            ['send', 'B', 'rm'],
            ['deliver', 'rm', 'A'],
            ['send', 'A', 'new'],
            ['deliver', 'new', 'B'],
            ['deliver', 'old', 'B'],
            ['read', 'B']],
 'replicas': ['A', 'B']}
        expected = {'reads': [['gpu']], 'replicas': {'A': ['gpu'], 'B': ['gpu']}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
