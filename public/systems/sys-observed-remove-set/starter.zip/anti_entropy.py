"""The transport calls this join for every delivered snapshot, including duplicates."""
def join(local, incoming):
    """Return a fresh history containing the union of tag bindings and the sorted union of tombstones in both states."""
    raise NotImplementedError('join')
