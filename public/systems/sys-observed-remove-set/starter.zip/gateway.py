"""Replay local edits and saved network packets in the supplied order."""
from copy import deepcopy
from anti_entropy import join
from replica import add, discard, visible

def handle(request):
    nodes = {r: {"adds": {}, "removed": []} for r in request["replicas"]}
    counters = {r: 0 for r in nodes}
    packets, reads = {}, []
    for op, *args in request["events"]:
        if op == "deliver":
            packet, destination = args
            nodes[destination] = join(nodes[destination], packets[packet])
            continue
        origin = args[0]
        if op == "add":
            counters[origin] += 1
            tag = f"{origin}#{counters[origin]}"
            nodes[origin] = add(nodes[origin], args[1], tag)
        elif op == "remove":
            nodes[origin] = discard(nodes[origin], args[1])
        elif op == "send":
            packets[args[1]] = deepcopy(nodes[origin])
        elif op == "read":
            reads.append(visible(nodes[origin]))
    return {"reads": reads, "replicas": {r: visible(s) for r, s in nodes.items()}}
