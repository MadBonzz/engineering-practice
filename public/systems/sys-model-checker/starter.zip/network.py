"""Generate legal message events from a network state."""
def choices(state, drop):
    """Return unique [action, id] events, ordered by action then ID. Copy requires a pending ID and an unspent copy. Drop requires drop=True."""
    raise NotImplementedError('choices')

def state_key(state):
    """Return a hashable triple (sorted pending tuple with repetitions, copies_left, sorted tuple of (id,count) credit pairs)."""
    raise NotImplementedError('state_key')
