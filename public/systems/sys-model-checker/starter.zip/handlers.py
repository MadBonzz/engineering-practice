"""Protocol under test. Inspect both handlers to understand the invariant."""
def receive(credits, message, handler):
    if handler == "deduplicate":
        return {**credits, message: 1}
    return {**credits, message: credits.get(message, 0) + 1}

def offender(state):
    return min((key for key, count in state["credits"].items() if count > 1), default=None)
