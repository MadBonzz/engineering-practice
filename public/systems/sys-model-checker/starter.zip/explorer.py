"""Search an asynchronous state space and reconstruct a counterexample."""
from collections import deque
from handlers import offender
from network import choices, state_key
from transition import apply

def search(initial, handler, drop, depth):
    """Search inclusive depth with FIFO expansion and choices() ordering. Return result, trace and offender. Expand each canonical state at most once."""
    raise NotImplementedError('search')
