# Build a bounded message-schedule checker

A payment handler occasionally credits the same request twice. The retry that triggers it never appears in sequential tests. Build the event explorer behind a distributed-systems test harness and return a shortest schedule that reproduces the double credit.

## Implementation scope

The supplied handlers model one replica and one unit of credit per request ID. You implement the network event choices, a canonical state key, and bounded breadth-first search. The optional replay mode lets you inspect the state reached by a witness.

## Input

A request has handler ("naive" or "deduplicate"), requests (an initial bag of 0–4 nonempty ASCII request IDs, possibly repeated), copies (0–2), and depth (0–8). Optional drop is a boolean, default false. Omit replay to search, or provide replay as an array of legal [action, id] pairs to execute exactly those actions.

## Output

Search returns {result, trace, offender}. A violation gives the first shortest schedule that credits an ID twice and the offending ID. Exhausting the inclusive bound gives {"result":"clear_within_bound","trace":[],"offender":null}. Replay returns {pending, credits, copies_left} after the supplied actions; pending is sorted and credits omits zero counts.

## Constraints

Count each delivery, copy, or drop as one step. For each state, enumerate distinct IDs lexicographically within each action, in action order deliver, copy, drop. Delivery consumes one pending occurrence. A copy leaves the original pending, enqueues one more occurrence, and spends one global copy. Drop consumes one pending occurrence when enabled. The search checks safety at depths zero through depth inclusive. Replay uses its own explicit schedule independently of depth. If more than one ID violates at a supplied initial state, return the lexicographically smallest.

## Example 1

Input

~~~json
{
  "handler": "naive",
  "requests": [
    "r"
  ],
  "copies": 1,
  "depth": 3
}
~~~

Output

~~~json
{
  "result": "violation",
  "trace": [
    [
      "copy",
      "r"
    ],
    [
      "deliver",
      "r"
    ],
    [
      "deliver",
      "r"
    ]
  ],
  "offender": "r"
}
~~~

Delivering the sole request first empties the network. Copying it first leaves two pending deliveries. The second delivery raises its credit count to two in exactly three steps.

## Example 2

Input

~~~json
{
  "handler": "deduplicate",
  "requests": [
    "r"
  ],
  "copies": 1,
  "depth": 3
}
~~~

Output

~~~json
{
  "result": "clear_within_bound",
  "trace": [],
  "offender": null
}
~~~

Even with two copies in flight, the idempotent handler records one credit for r. Every state reachable through three events satisfies the invariant.

## Part 1 · Enumerate deliveries and identify equivalent states

Treat pending messages as a multiset. Two identical messages enable one distinct event choice yet have a different future from one message.

network.py · choices(state, drop) — Return unique [action, id] events, ordered by action then ID. Copy requires a pending ID and an unspent copy. Drop requires drop=True.

network.py · state_key(state) — Return a hashable triple (sorted pending tuple with repetitions, copies_left, sorted tuple of (id,count) credit pairs).

## Part 2 · Find and reconstruct a shortest failing schedule

Use the supplied transition function, protocol invariant and your event enumerator. Preserve deterministic tie order and return a replayable witness.

explorer.py · search(initial, handler, drop, depth) — Search inclusive depth with FIFO expansion and choices() ordering. Return result, trace and offender. Expand each canonical state at most once.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Michael et al. · Teaching Rigorous Distributed Systems With Efficient Model Checking](https://ellismichael.com/papers/dslabs-eurosys19.pdf)
