"""One deterministic event delivery. Branches receive independent state."""
from handlers import receive

def apply(state, event, handler):
    action, item = event
    pending = list(state["pending"])
    credits = dict(state["credits"])
    copies = state["copies_left"]
    if action == "copy":
        pending.append(item)
        copies -= 1
    else:
        pending.remove(item)
        if action == "deliver":
            credits = receive(credits, item, handler)
    return {"pending": sorted(pending), "copies_left": copies, "credits": credits}
