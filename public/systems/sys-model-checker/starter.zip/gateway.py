"""Construct the initial state, then search it or replay a supplied witness."""
from explorer import search
from network import choices
from transition import apply

def handle(request):
    state = {"pending": sorted(request["requests"]), "credits": {}, "copies_left": request["copies"]}
    drop = request.get("drop", False)
    if "replay" not in request:
        return search(state, request["handler"], drop, request["depth"])
    for event in request["replay"]:
        if event not in choices(state, drop):
            raise ValueError("Illegal replay event")
        state = apply(state, event, request["handler"])
    return state
