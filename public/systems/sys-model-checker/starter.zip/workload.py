import importlib
import math

ALLOWED = ['explorer.search', 'gateway.handle', 'network.choices', 'network.state_key']

def trial(name, args):
    if name not in ALLOWED:
        raise ValueError('Unknown interface')
    module, function = name.rsplit('.', 1)
    return getattr(importlib.import_module(module), function)(*args)

def equivalent(actual, expected):
    if isinstance(expected, bool):
        return actual is expected
    if isinstance(expected, (int, float)):
        return type(actual) in (int, float) and actual == expected
    if isinstance(expected, list):
        return isinstance(actual, (list, tuple)) and len(actual)==len(expected) and all(equivalent(a,e) for a,e in zip(actual,expected))
    if isinstance(expected, dict):
        return isinstance(actual, dict) and actual.keys()==expected.keys() and all(equivalent(actual[k],v) for k,v in expected.items())
    return actual == expected
