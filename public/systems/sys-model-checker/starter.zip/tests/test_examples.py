import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'copies': 1, 'depth': 3, 'handler': 'naive', 'requests': ['r']}
        expected = {'offender': 'r',
 'result': 'violation',
 'trace': [['copy', 'r'], ['deliver', 'r'], ['deliver', 'r']]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'copies': 1, 'depth': 3, 'handler': 'deduplicate', 'requests': ['r']}
        expected = {'offender': None, 'result': 'clear_within_bound', 'trace': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
