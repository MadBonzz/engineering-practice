import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_distinct_ids_per_event_kind(self):
        args = [{'copies_left': 1, 'credits': {}, 'pending': ['b', 'a', 'a']}, True]
        expected = [['deliver', 'a'],
 ['deliver', 'b'],
 ['copy', 'a'],
 ['copy', 'b'],
 ['drop', 'a'],
 ['drop', 'b']]
        actual = trial('network.choices', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_two_copies_already_in_flight(self):
        args = [{'copies_left': 0, 'credits': {}, 'pending': ['x', 'x']}, 'naive', False, 2]
        expected = {'offender': 'x',
 'result': 'violation',
 'trace': [['deliver', 'x'], ['deliver', 'x']]}
        actual = trial('explorer.search', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

