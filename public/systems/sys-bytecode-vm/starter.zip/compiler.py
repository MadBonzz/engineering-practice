def compile_expr(tree):
    """Return the canonical instruction list for one AST, with absolute jump targets and a final HALT. See isa.py."""
    raise NotImplementedError('compile_expr')
