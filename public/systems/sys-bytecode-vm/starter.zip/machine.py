def execute(code, env):
    """Execute the instruction stream. Return value, ordered reads, and error as specified, including failed reads."""
    raise NotImplementedError('execute')
