'''Compile a rule once, then evaluate its bytecode against the caller's environment.'''
from compiler import compile_expr
from machine import execute

def handle(request):
    return execute(compile_expr(request["expr"]), request["env"])
