import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'env': {'cache': 7},
 'expr': ['or', ['read', 'cache'], ['read', 'backend']]}
        expected = {'error': None, 'reads': ['cache'], 'value': 7}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'env': {'cost': 4, 'quota': -2, 'ready': 0},
 'expr': ['if',
          ['read', 'ready'],
          ['add', 2, ['read', 'x']],
          ['and', ['read', 'quota'], ['read', 'cost']]]}
        expected = {'error': None, 'reads': ['ready', 'quota', 'cost'], 'value': 4}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
