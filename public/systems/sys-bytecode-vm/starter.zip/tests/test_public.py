import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_patch_a_jump_over_an_addition(self):
        args = [['and', ['read', 'a'], ['add', 1, ['read', 'b']]]]
        expected = [['READ', 'a'],
 ['JZ_KEEP', 6],
 ['DROP'],
 ['PUSH', 1],
 ['READ', 'b'],
 ['ADD'],
 ['HALT']]
        actual = trial('compiler.compile_expr', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_a_taken_branch_preserves_the_original_signed_operand(self):
        args = [[['READ', 'q'], ['JNZ_KEEP', 4], ['DROP'], ['READ', 'r'], ['HALT']], {'q': -8}]
        expected = {'error': None, 'reads': ['q'], 'value': -8}
        actual = trial('machine.execute', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

