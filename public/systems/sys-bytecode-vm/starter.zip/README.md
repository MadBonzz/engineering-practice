# Compile short-circuit expressions to a stack VM

A rule engine charges for every variable lookup. A cached result should skip a backend lookup, yet an eager compiler still reads it and can crash on an unbound name. Implement the bytecode compiler and virtual machine. The access log must show exactly which reads ran.

## Implementation scope

Implement the backend of a small expression language. A caller supplies a parsed JSON tree. The debugger and unit tests use the canonical instruction layout in isa.py, so branch targets and the placement of DROP are part of the compiler interface.

## Input

A request has expr and env. A tree is an integer, ["read", name], ["add", a, b], ["and", a, b], ["or", a, b], or ["if", condition, then_expr, else_expr]. Each operand is another tree. env maps strings to integer values. env may omit names in the tree.

## Output

Return {value, reads, error}. On success value is the integer result and error is null. Append each name to reads at the instant it is looked up, including repeated and missing reads. On the first missing lookup, stop and return null for value and the string 'unbound:' followed immediately by the name for error.

## Constraints

Zero is false and every other integer is true. and/or return the selected operand's integer, including its sign. add evaluates left first. if evaluates only its selected arm. Inputs have at most 256 AST nodes and depth at most 40. All bytecode supplied directly to the VM follows the instruction contract in isa.py, with valid forward targets, balanced stacks, and one HALT. Only a missing READ can fail.

## Example 1

Input

~~~json
{
  "expr": [
    "or",
    [
      "read",
      "cache"
    ],
    [
      "read",
      "backend"
    ]
  ],
  "env": {
    "cache": 7
  }
}
~~~

Output

~~~json
{
  "value": 7,
  "reads": [
    "cache"
  ],
  "error": null
}
~~~

The first lookup yields 7. The VM's conditional jump goes straight to HALT, preserving 7. The missing backend binding is never read.

## Example 2

Input

~~~json
{
  "expr": [
    "if",
    [
      "read",
      "ready"
    ],
    [
      "add",
      2,
      [
        "read",
        "x"
      ]
    ],
    [
      "and",
      [
        "read",
        "quota"
      ],
      [
        "read",
        "cost"
      ]
    ]
  ],
  "env": {
    "ready": 0,
    "quota": -2,
    "cost": 4
  }
}
~~~

Output

~~~json
{
  "value": 4,
  "reads": [
    "ready",
    "quota",
    "cost"
  ],
  "error": null
}
~~~

ready is zero, so the VM jumps past the add expression. The else arm reads quota. Its negative value is truthy, so and discards it and evaluates cost.

## Part 1 · Lower expressions and patch jumps

Emit one flat sequence using the canonical lowering table in isa.py. Use absolute instruction indices. Every expression leaves one result and the entire program ends with one HALT.

compiler.py · compile_expr(tree) — Return the canonical instruction list for one AST, with absolute jump targets and a final HALT. See isa.py.

## Part 2 · Execute the bytecode and record reads

Run the independent bytecode stream from instruction zero. Apply the stack and branch effects in isa.py, and preserve the read log even when an unbound lookup stops execution.

machine.py · execute(code, env) — Execute the instruction stream. Return value, ordered reads, and error as specified, including failed reads.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Robert Nystrom · Jumping Back and Forth](https://craftinginterpreters.com/jumping-back-and-forth.html)

- [LLVM tutorial · Extending the Language with Control Flow](https://llvm.org/docs/tutorial/MyFirstLanguageFrontend/LangImpl05.html)
