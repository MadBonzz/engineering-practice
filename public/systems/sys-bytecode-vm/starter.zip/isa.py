'''Instruction set and canonical lowering used by the debugger.

Instructions are lists. Targets are absolute zero-based instruction indices. The
first instruction is index 0. Unless a jump is taken, advance by one.
  PUSH n           push n
  READ name        log name, then push env[name] or stop with an error
  ADD              pop the right, then the left integer; push their sum
  DROP             pop and discard the top integer
  JZ_KEEP target   jump if top == 0; leave top unchanged
  JNZ_KEEP target  jump if top != 0; leave top unchanged
  JZ_POP target    pop and jump if the popped value is zero
  JMP target       jump unconditionally
  HALT             return the only stack item

Emit PUSH for an integer and READ for a variable. Lower add as L, R, ADD.
Lower and as L, JZ_KEEP end, DROP, R, end. Lower or identically with JNZ_KEEP.
Lower if as C, JZ_POP otherwise, T, JMP end, otherwise: F, end.
Labels mark boundaries; never emit a label instruction. A single HALT follows
the outermost expression. Do not fold constants or remove unreachable branches:
the debugger indexes every source arm.
'''
