"""Install a compacted run into one contiguous manifest interval."""
from runs import freeze, lookup

def merge(tables, start, count):
    """Replace tables[start:start+count] with one sorted run (or no run if empty), preserving visible values."""
    raise NotImplementedError('merge')
