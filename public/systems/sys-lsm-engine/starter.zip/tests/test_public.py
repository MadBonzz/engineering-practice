import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_a_disk_tombstone_shadows_an_old_value(self):
        args = [{}, [[['k', 'first']], [['k', None]]], 'k']
        expected = None
        actual = trial('runs.lookup', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_stop_wal_replay_at_the_sync_boundary(self):
        args = [[['a', '1'], ['a', None], ['a', '2']], 2]
        expected = {'a': None}
        actual = trial('recovery.replay', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_the_empty_string_is_a_live_older_value(self):
        args = [[[['k', '']], [['k', None]]], 1, 1]
        expected = [[['k', '']], [['k', None]]]
        actual = trial('compaction.merge', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

