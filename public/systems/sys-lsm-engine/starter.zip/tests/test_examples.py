import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'ops': [['put', 'b', 'old'],
         ['flush'],
         ['put', 'a', 'logged'],
         ['sync'],
         ['del', 'b'],
         ['get', 'b'],
         ['crash'],
         ['get', 'a'],
         ['get', 'b']]}
        expected = {'mem': [['a', 'logged']],
 'reads': [None, 'logged', 'old'],
 'runs': [[['b', 'old']]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'ops': [['put', 'a', 'old'],
         ['flush'],
         ['put', 'b', 'keep'],
         ['flush'],
         ['del', 'a'],
         ['flush'],
         ['compact', 1, 2],
         ['get', 'a']]}
        expected = {'mem': [],
 'reads': [None],
 'runs': [[['a', 'old']], [['a', None], ['b', 'keep']]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
