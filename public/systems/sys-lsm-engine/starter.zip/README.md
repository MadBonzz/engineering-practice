# LSM storage engine · recover writes and compact tombstones

A storage service occasionally resurrects deleted keys after its compactor runs. Implement the read path, log recovery, and range of runs selected for compaction. Replay writes across a crash and inspect the exact disk layout that results.

## Implementation scope

The harness provides atomic flush, sync, and manifest installation at explicit operation boundaries. You implement the mechanics of immutable sorted runs and a write-ahead log. Files, fsync, and power loss are modeled as deterministic data structures.

## Input

ops is an ordered array of commands. ["put",key,value] and ["del",key] append to the volatile log and update the memtable. ["get",key] reads. ["sync"] makes the current log prefix durable. ["crash"] discards unsynced records and reconstructs the memtable. ["flush"] installs all buffered writes in one durable sorted run and clears the log. ["compact",start,count] merges count adjacent disk runs starting at zero-based start, oldest run first.

## Output

Return reads (values or null from get, in order), runs (oldest to newest, each a sorted list of [key,value] pairs), and mem (the current memtable as sorted pairs). A null value in a run or memtable is a deletion marker. Empty memtable flushes add no run. Remove an empty compacted result from the manifest.

## Constraints

Keys and values are strings, including empty values. Ordering by key is lexicographic. On reads prefer the memtable, then successively older runs, stopping at the first record including a tombstone. Inside a compacted interval the newest record wins. Keep a winning tombstone only if the unselected older runs currently expose a live value for that key. Leave newer runs untouched. Flush retains all memtable tombstones. Compaction requests always use 1 ≤ count and valid bounds. No snapshots are held.

## Example 1

Input

~~~json
{
  "ops": [
    [
      "put",
      "b",
      "old"
    ],
    [
      "flush"
    ],
    [
      "put",
      "a",
      "logged"
    ],
    [
      "sync"
    ],
    [
      "del",
      "b"
    ],
    [
      "get",
      "b"
    ],
    [
      "crash"
    ],
    [
      "get",
      "a"
    ],
    [
      "get",
      "b"
    ]
  ]
}
~~~

Output

~~~json
{
  "reads": [
    null,
    "logged",
    "old"
  ],
  "runs": [
    [
      [
        "b",
        "old"
      ]
    ]
  ],
  "mem": [
    [
      "a",
      "logged"
    ]
  ]
}
~~~

The buffered delete hides b immediately. A crash loses that delete while preserving the earlier sync of a. The disk run still contains b’s original value.

## Example 2

Input

~~~json
{
  "ops": [
    [
      "put",
      "a",
      "old"
    ],
    [
      "flush"
    ],
    [
      "put",
      "b",
      "keep"
    ],
    [
      "flush"
    ],
    [
      "del",
      "a"
    ],
    [
      "flush"
    ],
    [
      "compact",
      1,
      2
    ],
    [
      "get",
      "a"
    ]
  ]
}
~~~

Output

~~~json
{
  "reads": [
    null
  ],
  "runs": [
    [
      [
        "a",
        "old"
      ]
    ],
    [
      [
        "a",
        null
      ],
      [
        "b",
        "keep"
      ]
    ]
  ],
  "mem": []
}
~~~

Only runs 1 and 2 merge. Removing a’s tombstone would make the old value in run 0 visible. The new run therefore retains both a’s marker and b.

## Part 1 · Read and freeze sorted runs

Expose the newest visible value across memory and the disk manifest.

runs.py · freeze(mem) — Return an immutable-run representation (sorted [key,value] rows) of the memtable, keeping null tombstones.

runs.py · lookup(mem, tables, key) — Return the newest visible value or None, checking mem first, then immutable tables newest first.

## Part 2 · Recover a synchronized WAL prefix

Rebuild a memtable after the emulated power cut. Preserve repeated writes and deletes in their original order.

recovery.py · replay(log, durable) — Replay the first durable records of the [key,value] log into a dict retaining the last value or tombstone per key.

## Part 3 · Compact without reviving deleted keys

Merge the selected manifest interval and install the result, preserving shadowing of older values.

compaction.py · merge(tables, start, count) — Replace tables[start:start+count] with one sorted run (or no run if empty), preserving visible values.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Google LevelDB · log files, sorted tables, recovery and compaction](https://github.com/google/leveldb/blob/main/doc/impl.md)
