"""Reconstruct in-memory state after losing the volatile WAL suffix."""
def replay(log, durable):
    """Replay the first durable records of the [key,value] log into a dict retaining the last value or tombstone per key."""
    raise NotImplementedError('replay')
