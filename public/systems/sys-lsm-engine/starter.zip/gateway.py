"""Replay write acknowledgments, durability boundaries, reads and manifest changes."""
from runs import freeze, lookup
from recovery import replay
from compaction import merge

def handle(request):
    tables, log, mem, reads = [], [], {}, []
    durable = 0
    for command, *args in request["ops"]:
        if command in ("put", "del"):
            key = args[0]
            value = args[1] if command == "put" else None
            log.append([key, value])
            mem[key] = value
        elif command == "get":
            reads.append(lookup(mem, tables, args[0]))
        elif command == "sync":
            durable = len(log)
        elif command == "crash":
            mem = replay(log, durable)
            log = log[:durable]
        elif command == "flush":
            if mem:
                tables.append(freeze(mem))
            log, mem, durable = [], {}, 0
        elif command == "compact":
            tables = merge(tables, *args)
    return {"reads": reads, "runs": tables, "mem": freeze(mem)}
