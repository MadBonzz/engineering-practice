"""Represent immutable runs as lists of [key,value] sorted by key."""
from bisect import bisect_left

def freeze(mem):
    """Return an immutable-run representation (sorted [key,value] rows) of the memtable, keeping null tombstones."""
    raise NotImplementedError('freeze')

def lookup(mem, tables, key):
    """Return the newest visible value or None, checking mem first, then immutable tables newest first."""
    raise NotImplementedError('lookup')
