"""Diff replicas interval by interval across an old and new ring."""
from token_ring import owners

def changes(old, new, rf):
    """Diff sorted token rows. Emit [left,right,old_primary,new_primary,copy_to,retire_from] for affected ranges."""
    raise NotImplementedError('changes')
