import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_equality_and_distinct_physical_replicas(self):
        args = [[[8, 'A'], [9, 'A'], [12, 'B']], 9, 4]
        expected = ['A', 'B']
        actual = trial('token_ring.owners', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_cut_only_the_newly_acquired_primary_interval(self):
        args = [[[10, 'A']], [[10, 'A'], [40, 'B']], 1]
        expected = [[10, 40, 'A', 'B', ['B'], ['A']]]
        actual = trial('handoff.changes', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

