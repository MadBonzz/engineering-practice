import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'after': {'A': [20], 'B': [100], 'C': [60]},
 'before': {'A': [20], 'B': [100]},
 'keys': [20, 21, 80, 250],
 'rf': 2}
        expected = {'moves': [[100, 20, 'A', 'A', ['C'], ['B']],
           [20, 60, 'B', 'C', ['C'], ['A']]],
 'routes': [['A', 'C'], ['C', 'B'], ['B', 'A'], ['A', 'C']]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'after': {'A': [10, 30]},
 'before': {'A': [10, 30], 'B': [90]},
 'keys': [31, 90],
 'rf': 3}
        expected = {'moves': [[90, 10, 'A', 'A', [], ['B']],
           [10, 30, 'A', 'A', [], ['B']],
           [30, 90, 'B', 'A', [], ['B']]],
 'routes': [['A'], ['A']]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
