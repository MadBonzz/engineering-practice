"""Ring index shared by online routing and the offline transfer planner."""
from bisect import bisect_left

def build(members):
    """Return increasing [position, physical_node] rows for the member-to-token mapping."""
    raise NotImplementedError('build')

def owners(tokens, key, rf):
    """Return up to rf distinct physical nodes clockwise, starting at the first position >= key and wrapping."""
    raise NotImplementedError('owners')
