"""Resolve client keys and prepare the handoff manifest for the same membership change."""
from token_ring import build, owners
from handoff import changes

def handle(request):
    old, new = build(request["before"]), build(request["after"])
    rf = request["rf"]
    return {"routes": [owners(new, key, rf) for key in request["keys"]],
            "moves": changes(old, new, rf)}
