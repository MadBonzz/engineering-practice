# Consistent hashing · plan a live replica handoff

A storage cluster is adding and removing virtual nodes while keys remain live. Build its placement service and a handoff planner. An operator must know exactly which ranges need copying, which replicas can retire, and which machine will answer each read.

## Implementation scope

Plan a transition between two token assignments. The supplied gateway builds both rings and asks your range planner for a complete diff. Hashes and token positions are injected so a failing placement is easy to reproduce by hand.

## Input

before and after map each physical node name to its virtual-node positions. rf is the desired number of distinct physical replicas. keys is a list of already-hashed read keys. All positions and keys are integers from 0 through 255.

## Output

routes contains one list of post-change owners per input key, in input order. moves contains [left, right, old_primary, new_primary, copy_to, retire_from] for each affected elementary range (left, right]. An empty ring has null primary. Order copy_to by the new preference list and retire_from by the old one.

## Constraints

Sort the union of old and new token positions. Each position ends one elementary range whose left boundary is the previous position in this circular order. A single boundary covers the entire ring. Emit records in ascending right-boundary order if the primary or membership changes. Ignore backup-only reordering and keep adjacent records separate. Equality belongs to the token at that position. Positions are unique within each snapshot. rf is 1–16. A node may own many tokens. Return as many distinct nodes as exist, up to rf.

## Example 1

Input

~~~json
{
  "before": {
    "A": [
      20
    ],
    "B": [
      100
    ]
  },
  "after": {
    "A": [
      20
    ],
    "B": [
      100
    ],
    "C": [
      60
    ]
  },
  "rf": 2,
  "keys": [
    20,
    21,
    80,
    250
  ]
}
~~~

Output

~~~json
{
  "routes": [
    [
      "A",
      "C"
    ],
    [
      "C",
      "B"
    ],
    [
      "B",
      "A"
    ],
    [
      "A",
      "C"
    ]
  ],
  "moves": [
    [
      100,
      20,
      "A",
      "A",
      [
        "C"
      ],
      [
        "B"
      ]
    ],
    [
      20,
      60,
      "B",
      "C",
      [
        "C"
      ],
      [
        "A"
      ]
    ]
  ]
}
~~~

C takes primary responsibility for (20,60]. It also replaces B as A’s backup on the wrapped range (100,20]. Reads at 20 still go to A. No data moves on (60,100].

## Example 2

Input

~~~json
{
  "before": {
    "A": [
      10,
      30
    ],
    "B": [
      90
    ]
  },
  "after": {
    "A": [
      10,
      30
    ]
  },
  "rf": 3,
  "keys": [
    31,
    90
  ]
}
~~~

Output

~~~json
{
  "routes": [
    [
      "A"
    ],
    [
      "A"
    ]
  ],
  "moves": [
    [
      90,
      10,
      "A",
      "A",
      [],
      [
        "B"
      ]
    ],
    [
      10,
      30,
      "A",
      "A",
      [],
      [
        "B"
      ]
    ],
    [
      30,
      90,
      "B",
      "A",
      [],
      [
        "B"
      ]
    ]
  ]
}
~~~

A owns two virtual nodes but stores one copy of each key. Removing B leaves A as the sole owner. Only the last range changes primary, and A already has that range.

## Part 1 · Index virtual nodes and route reads

Build a sorted token index, then walk it clockwise without counting the same physical machine twice.

token_ring.py · build(members) — Return increasing [position, physical_node] rows for the member-to-token mapping.

token_ring.py · owners(tokens, key, rf) — Return up to rf distinct physical nodes clockwise, starting at the first position >= key and wrapping.

## Part 2 · Plan exact replica transfers

Partition the whole hash space using both snapshots. Reuse the router once per ring per right endpoint.

handoff.py · changes(old, new, rf) — Diff sorted token rows. Emit [left,right,old_primary,new_primary,copy_to,retire_from] for affected ranges.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DeCandia et al. · Dynamo, sections 4.2 and 4.3](https://www.amazon.science/publications/dynamo-amazons-highly-available-key-value-store)
