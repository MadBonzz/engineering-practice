from cohort import transition

def deliver(phase, states, event):
    """Return [next_phase,new_states]. Gate votes and delivery by phase; advance after the last required acknowledgement. Each trace event includes its reply."""
    raise NotImplementedError('deliver')
