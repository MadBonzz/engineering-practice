"""Replay coordinator delivery and recovery events for one transaction."""
from coordinator import deliver
from termination import recover

def handle(request):
    phase = "VOTE"
    states = dict.fromkeys(request["members"], "INIT")
    recoveries = []
    for event in request["events"]:
        kind = event[0]
        if kind == "crash":
            phase = "DOWN"
        elif kind == "recover":
            if phase == "DOWN":
                verdict, states = recover(states, event[1])
                recoveries.append(verdict)
        elif phase != "DOWN":
            phase, states = deliver(phase, states, event)
    return {"coordinator": phase, "cohorts": states, "recoveries": recoveries}
