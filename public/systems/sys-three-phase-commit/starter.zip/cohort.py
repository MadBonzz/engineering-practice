def transition(state, message):
    """Return the durable successor for YES, NO, precommit, commit or abort. Terminal states absorb all messages. A READY voter can abort, and a PREPARED voter can only commit."""
    raise NotImplementedError('transition')
