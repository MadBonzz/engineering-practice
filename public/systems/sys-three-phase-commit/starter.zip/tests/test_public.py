import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_a_final_decision_cannot_skip_precommit(self):
        args = ['READY', 'commit']
        expected = 'READY'
        actual = trial('cohort.transition', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_last_positive_vote_opens_precommit(self):
        args = ['VOTE', {'A': 'READY', 'B': 'INIT'}, ['vote', 'B', 'YES']]
        expected = ['PRECOMMIT', {'A': 'READY', 'B': 'READY'}]
        actual = trial('coordinator.deliver', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_wait_for_the_missing_respondent(self):
        args = [{'a': 'PREPARED', 'b': 'READY'}, ['a']]
        expected = ['WAIT', {'a': 'PREPARED', 'b': 'READY'}]
        actual = trial('termination.recover', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

