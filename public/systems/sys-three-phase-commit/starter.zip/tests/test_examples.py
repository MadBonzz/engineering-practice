import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [['vote', 'A', 'YES'],
            ['vote', 'B', 'YES'],
            ['precommit', 'A'],
            ['crash'],
            ['recover', ['A', 'B']]],
 'members': ['A', 'B']}
        expected = {'cohorts': {'A': 'COMMITTED', 'B': 'COMMITTED'},
 'coordinator': 'DOWN',
 'recoveries': ['COMMIT']}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['vote', 'A', 'YES'],
            ['vote', 'B', 'YES'],
            ['crash'],
            ['recover', ['A']],
            ['recover', ['A', 'B']]],
 'members': ['A', 'B']}
        expected = {'cohorts': {'A': 'ABORTED', 'B': 'ABORTED'},
 'coordinator': 'DOWN',
 'recoveries': ['WAIT', 'ABORT']}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
