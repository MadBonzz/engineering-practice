# Three-phase commit · recover an interrupted transfer

A transfer spans two or more ledger shards. The coordinator can disappear between any two message deliveries. Implement the coordinator, the durable participant transitions and a replacement's termination procedure. Your replay must give the same final decision to every shard whenever the recovery assumptions hold.

## Implementation scope

One transaction with durable shard state and a single fenced coordinator. The supported recovery model has bounded delay, no partition and every participant available to the replacement. An incomplete survey explicitly returns WAIT. A successful recovery event simulates reliable prepare/ack and final-decision rounds without intermediate failures; a slow link alone never authorizes commit or abort.

## Input

members lists distinct shard IDs. events is an ordered list. [vote,id,YES|NO] records a first vote and its reply atomically. [precommit,id], [commit,id] and [abort,id] deliver a message and its acknowledgement atomically. [crash] fences the original coordinator. [recover,[ids...]] runs the replacement's recovery round using exactly the listed respondents. All tags are lowercase JSON strings except YES and NO.

## Output

Return coordinator (VOTE, PRECOMMIT, COMMIT, ABORT or DOWN), cohorts (ID to durable INIT, READY, PREPARED, COMMITTED or ABORTED), and recoveries (one WAIT, COMMIT or ABORT for each recovery attempted after a crash). A fenced coordinator stays DOWN even after recovery.

## Constraints

Only a live coordinator processes a vote or delivery. Start in VOTE with every shard INIT. Accept the first vote from each INIT shard in VOTE. Any NO selects ABORT; unanimous YES selects PRECOMMIT. PRECOMMIT sends prepare messages; unanimous durable PREPARED acknowledgements select COMMIT. Deliveries outside their matching coordinator phase leave state unchanged. Ignore repeats and stale messages. Recovery applies its decision to all shards only with a complete report; WAIT leaves every state unchanged. Transaction IDs and shard IDs are valid, and traces contain at most one coordinator crash.

## Example 1

Input

~~~json
{
  "members": [
    "A",
    "B"
  ],
  "events": [
    [
      "vote",
      "A",
      "YES"
    ],
    [
      "vote",
      "B",
      "YES"
    ],
    [
      "precommit",
      "A"
    ],
    [
      "crash"
    ],
    [
      "recover",
      [
        "A",
        "B"
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "coordinator": "DOWN",
  "cohorts": {
    "A": "COMMITTED",
    "B": "COMMITTED"
  },
  "recoveries": [
    "COMMIT"
  ]
}
~~~

A reached PREPARED, which proves both shards voted YES. The replacement prepares B before committing both.

## Example 2

Input

~~~json
{
  "members": [
    "A",
    "B"
  ],
  "events": [
    [
      "vote",
      "A",
      "YES"
    ],
    [
      "vote",
      "B",
      "YES"
    ],
    [
      "crash"
    ],
    [
      "recover",
      [
        "A"
      ]
    ],
    [
      "recover",
      [
        "A",
        "B"
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "coordinator": "DOWN",
  "cohorts": {
    "A": "ABORTED",
    "B": "ABORTED"
  },
  "recoveries": [
    "WAIT",
    "ABORT"
  ]
}
~~~

The first survey cannot rule out a PREPARED shard. The full survey finds two READY shards. No shard saw a precommit, so the replacement aborts.

## Part 1 · Persist votes and decisions

Encode valid local state edges; a duplicate or an old message must have no effect.

cohort.py · transition(state, message) — Return the durable successor for YES, NO, precommit, commit or abort. Terminal states absorb all messages. A READY voter can abort, and a PREPARED voter can only commit.

## Part 2 · Advance after acknowledgements

Gate messages on the active phase and count distinct shard acknowledgements.

coordinator.py · deliver(phase, states, event) — Return [next_phase,new_states]. Gate votes and delivery by phase; advance after the last required acknowledgement. Each trace event includes its reply.

## Part 3 · Terminate after coordinator loss

Recover from a full durable survey and defer an incomplete one. Complete missing precommits before final commit.

termination.py · recover(states, visible) — Return [verdict,new_states]. A complete survey with PREPARED or COMMITTED commits, completing the prepare round first. All other reachable complete surveys abort. Incomplete evidence returns WAIT.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Dale Skeen · Nonblocking commit protocols](https://doi.org/10.1145/582318.582339)

- [Rutgers CS 417 · Distributed transactions and 3PC failure assumptions](https://people.cs.rutgers.edu/pxk/classes/417/notes/transactions.html)
