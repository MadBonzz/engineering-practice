from cohort import transition

def recover(states, visible):
    """Return [verdict,new_states]. A complete survey with PREPARED or COMMITTED commits, completing the prepare round first. All other reachable complete surveys abort. Incomplete evidence returns WAIT."""
    raise NotImplementedError('recover')
