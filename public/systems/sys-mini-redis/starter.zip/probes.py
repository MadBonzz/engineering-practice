"""JSON-friendly probes for the real byte-oriented module interfaces."""
from commands import execute
from protocol import parse_request, ProtocolError
from store import delete_many, lookup, put

def frame(wire):
    try:
        result = parse_request(wire.encode("latin1"))
    except ProtocolError:
        return {"error": "protocol"}
    if result is None:
        return None
    args, used = result
    return {"args": [a.decode("latin1") for a in args], "used": used}

def store_trace(ops):
    records, results = {}, []
    for op, now, *args in ops:
        key = args[0].encode("latin1")
        if op == "put":
            put(records, key, args[1].encode("latin1"), now, args[2])
            results.append(None)
        elif op == "get":
            value = lookup(records, key, now)
            results.append(None if value is None else value.decode("latin1"))
        elif op == "del":
            results.append(delete_many(records, [x.encode("latin1") for x in args], now))
    return results

def command_trace(ops):
    records = {}
    replies = []
    for now, arguments in ops:
        wire = execute(records, [arg.encode("latin1") for arg in arguments], now)
        replies.append(wire.decode("latin1"))
    return replies
