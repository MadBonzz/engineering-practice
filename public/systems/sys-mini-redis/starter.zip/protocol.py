"""Decode one RESP2 request from the beginning of a TCP receive buffer."""

class NeedMore(Exception):
    """Internal signal for an incomplete but still possible frame."""

class ProtocolError(ValueError):
    """The peer sent a malformed or out-of-range frame."""

def header(data, start, marker, maximum):
    """Read MARKER<decimal>CRLF. Return (nonnegative length, next offset)."""
    if start >= len(data):
        raise NeedMore
    if data[start:start + 1] != marker:
        raise ProtocolError("unexpected type marker")
    end = data.find(b"\r\n", start + 1)
    if end == -1:
        if len(data) - start > 11:
            raise ProtocolError("header too long")
        raise NeedMore
    digits = data[start + 1:end]
    if not 1 <= len(digits) <= 9 or not digits.isdigit():
        raise ProtocolError("bad length")
    length = int(digits)
    if length > maximum:
        raise ProtocolError("length exceeds lab limit")
    return length, end + 2

def parse_request(data):
    """Return (list of bytes arguments, consumed byte count) for the first complete frame, None for an incomplete frame, or raise ProtocolError for a malformed frame. Use header() with limits 1024 arguments and 65536 bytes per bulk string. Reject empty command arrays."""
    raise NotImplementedError('parse_request')
