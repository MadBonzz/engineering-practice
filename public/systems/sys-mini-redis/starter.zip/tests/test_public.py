import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_consume_one_request_and_leave_the_following_frame(self):
        args = ['*1\r\n$4\r\nPING\r\n*2\r\n$3\r\nGET\r\n$1\r\nk\r\n']
        expected = {'args': ['PING'], 'used': 14}
        actual = trial('probes.frame', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_lookup_immediately_before_and_at_an_expiry(self):
        args = [[['put', 20, 'a', 'v', 3], ['get', 22, 'a'], ['get', 23, 'a'], ['del', 23, 'a']]]
        expected = [None, 'v', None, 0]
        actual = trial('probes.store_trace', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_basic_ping_and_binary_echo(self):
        args = [[[0, ['pinG']], [0, ['PING', '\x00']]]]
        expected = ['+PONG\r\n', '$1\r\n\x00\r\n']
        actual = trial('probes.command_trace', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

