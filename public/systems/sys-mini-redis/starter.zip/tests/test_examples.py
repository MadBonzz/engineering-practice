import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [{'at': 10,
             'client': 'writer',
             'wire': '*5\r\n'
                     '$3\r\n'
                     'SET\r\n'
                     '$1\r\n'
                     'k\r\n'
                     '$1\r\n'
                     'v\r\n'
                     '$2\r\n'
                     'PX\r\n'
                     '$1\r\n'
                     '5\r\n'},
            {'at': 14,
             'client': 'reader',
             'wire': '*2\r\n$3\r\nGET\r\n$1\r\nk\r\n'},
            {'at': 15,
             'client': 'reader',
             'wire': '*2\r\n$3\r\nGET\r\n$1\r\nk\r\n'}]}
        expected = {'pending': {}, 'replies': ['+OK\r\n', '$1\r\nv\r\n', '$-1\r\n']}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [{'at': 0, 'client': 'A', 'wire': '*1\r\n$4\r\nPI'},
            {'at': 1, 'client': 'B', 'wire': '*1\r\n$4\r\nPING\r\n'},
            {'at': 2,
             'client': 'A',
             'wire': 'NG\r\n*2\r\n$4\r\nPING\r\n$2\r\n\x00ÿ\r\n*2\r'}]}
        expected = {'pending': {'A': 3},
 'replies': ['', '+PONG\r\n', '+PONG\r\n$2\r\n\x00ÿ\r\n']}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
