"""Translate raw command arguments to a single reply on the wire."""
from store import delete_many, lookup, put

CRLF = b"\r\n"
ARITY = b"-ERR wrong number of arguments\r\n"
SYNTAX = b"-ERR syntax error\r\n"
EXPIRY = b"-ERR invalid expire time\r\n"
UNKNOWN = b"-ERR unknown command\r\n"

def bulk(value):
    """Encode None as a null bulk string and bytes as a length-prefixed string."""
    raise NotImplementedError('bulk')

def execute(records, args, now_ms):
    """Return RESP2 bytes for PING [message], SET key value [PX ms], GET key or DEL key [key ...]. Ignore ASCII case in the verb and PX. Validate before writing. See constants for the four command errors."""
    raise NotImplementedError('execute')
