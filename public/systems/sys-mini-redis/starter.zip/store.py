"""The shared database maps byte keys to (byte value, expiry_ms or None)."""

def lookup(records, key, now_ms):
    """Return the live bytes value, or None for missing/expired keys. A deadline is exclusive: expire and remove the record when now_ms >= expiry_ms."""
    raise NotImplementedError('lookup')

def put(records, key, value, now_ms, ttl_ms=None):
    """Replace any old record, setting an absolute deadline of now_ms + ttl_ms. A missing TTL clears any prior expiry. The dispatcher validates TTLs."""
    raise NotImplementedError('put')

def delete_many(records, keys, now_ms):
    """Delete keys and return the count of live entries removed. Missing, expired and repeated keys contribute zero after their first removal."""
    raise NotImplementedError('delete_many')
