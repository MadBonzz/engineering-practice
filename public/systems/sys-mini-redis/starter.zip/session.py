"""Every connection owns one receive buffer; all connections share one database."""
from commands import execute
from protocol import ProtocolError, parse_request

class Session:
    def __init__(self, records):
        self.records = records
        self.pending = b""
        self.closed = False

    def feed(self, chunk, now_ms):
        self.pending += chunk
        output = []
        offset = 0
        while offset < len(self.pending):
            try:
                parsed = parse_request(self.pending[offset:])
            except ProtocolError:
                output.append(b"-ERR protocol error\r\n")
                self.pending = b""
                self.closed = True
                return b"".join(output)
            if parsed is None:
                break
            args, used = parsed
            output.append(execute(self.records, args, now_ms))
            offset += used
        self.pending = self.pending[offset:]
        return b"".join(output)
