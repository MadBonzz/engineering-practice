"""Replay deterministic byte chunks and per-connection disconnects."""
from session import Session

def handle(request):
    records = {}
    clients = {}
    replies = []
    for event in request["events"]:
        name = event["client"]
        if event.get("close"):
            clients.pop(name, None)
            replies.append("")
            continue
        if name not in clients:
            clients[name] = Session(records)
        client = clients[name]
        reply = client.feed(event["wire"].encode("latin1"), event["at"])
        replies.append(reply.decode("latin1"))
        if client.closed:
            del clients[name]
    pending = {c: len(s.pending) for c, s in clients.items() if s.pending}
    return {"replies": replies, "pending": pending}
