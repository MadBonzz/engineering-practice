"""With the server running, use python demo.py --port 6380 in a second terminal."""
import argparse
import socket

def request(*args):
    frame = [b"*" + str(len(args)).encode() + b"\r\n"]
    for arg in args:
        frame += [b"$" + str(len(arg)).encode() + b"\r\n", arg, b"\r\n"]
    return b"".join(frame)

def expect(stream, expected):
    result = stream.read(len(expected))
    if result != expected:
        raise AssertionError(f"Expected {expected!r}, received {result!r}")
    print(repr(result))

def main(port):
    addr = ("127.0.0.1", port)
    with socket.create_connection(addr, timeout=3) as first, socket.create_connection(addr, timeout=3) as second:
        with first.makefile("rb") as first_input, second.makefile("rb") as second_input:
            value = b"A\x00\r\n\xff"
            packet = request(b"SET", b"lab:demo", value)
            first.sendall(packet[:9])
            second.sendall(request(b"PING"))
            expect(second_input, b"+PONG\r\n")
            first.sendall(packet[9:])
            expect(first_input, b"+OK\r\n")
            second.sendall(request(b"GET", b"lab:demo") + request(b"DEL", b"lab:demo"))
            expect(second_input, b"$5\r\n" + value + b"\r\n:1\r\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=6380)
    main(parser.parse_args().port)
