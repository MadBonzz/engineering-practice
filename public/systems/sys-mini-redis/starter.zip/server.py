"""Run python server.py --port 6380 in a terminal. Listens only on 127.0.0.1."""
import argparse
import asyncio
import time

from session import Session

def connection_handler(records):
    async def handle(reader, writer):
        session = Session(records)
        try:
            while not session.closed:
                chunk = await reader.read(65536)
                if not chunk:
                    break
                now_ms = time.monotonic_ns() // 1_000_000
                writer.write(session.feed(chunk, now_ms))
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError):
            pass
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError):
                pass
    return handle

async def main(port):
    server = await asyncio.start_server(connection_handler({}), "127.0.0.1", port)
    async with server:
        print(f"Listening on 127.0.0.1:{server.sockets[0].getsockname()[1]}", flush=True)
        await server.serve_forever()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=6380)
    try:
        asyncio.run(main(parser.parse_args().port))
    except KeyboardInterrupt:
        pass
