"""The bench and command-line runner share this JSON entry point."""
from coordinator import replay

def handle(request):
    return replay(request["splits"], request["reducers"], request["events"])
