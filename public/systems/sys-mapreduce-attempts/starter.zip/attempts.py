"""Pure task-level ledger. Attempt IDs are scoped to a logical task."""
def transition(row, event, attempt):
    """Return [fresh_row, status_or_None]. Row fields are sorted active, sorted retired and winner (a string or None). Follow the attempt lifecycle in the brief."""
    raise NotImplementedError('transition')
