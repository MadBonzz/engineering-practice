"""Deterministic intermediate partitioning and reduction."""
def scatter(shard, count):
    """Map tokens to [token,1] records. Return count bucket lists. Route by the sum of UTF-8 bytes modulo count, preserving shard order within each bucket."""
    raise NotImplementedError('scatter')

def reduce_bucket(map_outputs, index):
    """Aggregate every winning map's bucket at index and return [token,total] rows in lexicographic token order."""
    raise NotImplementedError('reduce_bucket')
