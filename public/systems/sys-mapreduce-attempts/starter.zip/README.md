# Commit MapReduce output under retries and speculation

A slow worker keeps running after the scheduler starts a backup. Both send a completion; another worker reports success after its attempt expired. Build the coordinator for a word-count service so each logical map contributes exactly one output and readers only see a complete job. The trace lets you deliberately pick which worker finishes first.

## Implementation scope

Run a deterministic coordinator simulation for map and reduce attempts. Each worker computes the given word-count function. Logical output files live in an in-memory manifest and the first valid finisher wins. Assume committed files are durable and the coordinator stays up. The original system's worker-local map-file recovery, filesystem atomic renames and speculative-launch heuristics are additional mechanisms.

## Input

splits is an array of token arrays (one map task per split); reducers is a positive integer. events contains ["start", task, attempt], ["expire", task, attempt], ["finish", task, attempt], and ["read"]. Task IDs are m0,m1,… for splits and r0,r1,… for reducer partitions. IDs are zero-indexed. Events are processed in list order.

## Output

Return winners (task → accepted attempt ID or null); finishes (one status per finish, in order); reads (one publication snapshot per read); and partitions (final snapshot). A snapshot is null until all reducers commit, then an array in reducer-index order. Each partition is an array of [token, count] pairs sorted by token. A finished empty partition is [].

## Constraints

A start launches an attempt unless the task has won, the ID was previously retired on this task, or it is a reduce task with any uncommitted map. An early launch is ignored and can be issued again later. Expire retires an active attempt only. Start and expire on a committed task are no-ops. Before commitment, finish accepts the first active finisher (status accepted), clears active IDs and commits its output; all inactive finishes are stale. After commitment, finish from the winner is replay and any other is superseded. Attempts are scoped per task. There are 0–64 splits, 1–16 reducers and up to 2,000 events. Task IDs are valid. Tokens and attempt IDs are nonempty strings. Route a token by sum of its UTF-8 bytes modulo reducer count.

## Example 1

Input

~~~json
{
  "splits": [
    [
      "kiwi",
      "fig",
      "fig"
    ],
    [
      "fig"
    ]
  ],
  "reducers": 1,
  "events": [
    [
      "start",
      "m0",
      "P"
    ],
    [
      "finish",
      "m0",
      "P"
    ],
    [
      "start",
      "m1",
      "Q"
    ],
    [
      "finish",
      "m1",
      "Q"
    ],
    [
      "start",
      "r0",
      "S"
    ],
    [
      "finish",
      "r0",
      "S"
    ],
    [
      "read"
    ]
  ]
}
~~~

Output

~~~json
{
  "winners": {
    "m0": "P",
    "m1": "Q",
    "r0": "S"
  },
  "finishes": [
    "accepted",
    "accepted",
    "accepted"
  ],
  "reads": [
    [
      [
        [
          "fig",
          3
        ],
        [
          "kiwi",
          1
        ]
      ]
    ]
  ],
  "partitions": [
    [
      [
        "fig",
        3
      ],
      [
        "kiwi",
        1
      ]
    ]
  ]
}
~~~

Three fig records from two winning maps land in reducer 0. Once S commits, the read sees fig=3 and kiwi=1.

## Example 2

Input

~~~json
{
  "splits": [
    [
      "a",
      "a"
    ]
  ],
  "reducers": 1,
  "events": [
    [
      "start",
      "r0",
      "early"
    ],
    [
      "start",
      "m0",
      "slow"
    ],
    [
      "expire",
      "m0",
      "slow"
    ],
    [
      "start",
      "m0",
      "new"
    ],
    [
      "start",
      "m0",
      "backup"
    ],
    [
      "finish",
      "m0",
      "slow"
    ],
    [
      "finish",
      "m0",
      "backup"
    ],
    [
      "finish",
      "m0",
      "new"
    ],
    [
      "finish",
      "m0",
      "backup"
    ],
    [
      "finish",
      "r0",
      "early"
    ],
    [
      "read"
    ],
    [
      "start",
      "r0",
      "now"
    ],
    [
      "finish",
      "r0",
      "now"
    ]
  ]
}
~~~

Output

~~~json
{
  "winners": {
    "m0": "backup",
    "r0": "now"
  },
  "finishes": [
    "stale",
    "accepted",
    "superseded",
    "replay",
    "stale",
    "accepted"
  ],
  "reads": [
    null
  ],
  "partitions": [
    [
      [
        "a",
        2
      ]
    ]
  ]
}
~~~

The early reduce launch is ignored. The expired map is stale, backup wins, new is superseded, and repeating backup is a replay. The reduce must be launched again after the maps finish. The two occurrences of a are counted once each.

## Part 1 · Arbitrate competing attempts

Maintain a ledger for one task. Keep active attempts, retired attempts and the winner. Preserve retired IDs on commitment. Return None for start/expire status and the specified status for every finish.

attempts.py · transition(row, event, attempt) — Return [fresh_row, status_or_None]. Row fields are sorted active, sorted retired and winner (a string or None). Follow the attempt lifecycle in the brief.

## Part 2 · Shuffle and aggregate the winning files

Each map emits one [token,1] record per occurrence into its reducer bucket. Each reducer receives the same bucket index from every winning map and emits key totals in deterministic order.

shuffle.py · scatter(shard, count) — Map tokens to [token,1] records. Return count bucket lists. Route by the sum of UTF-8 bytes modulo count, preserving shard order within each bucket.

shuffle.py · reduce_bucket(map_outputs, index) — Aggregate every winning map's bucket at index and return [token,total] rows in lexicographic token order.

## Part 3 · Wire the barrier and output manifest

Track the ledger and finalized output per task. Honor the map barrier when a reducer asks to start. Execute a worker's map or reduce only when transition returns accepted. Serve read and final snapshots from fully committed reducer outputs.

coordinator.py · replay(splits, reducers, events) — Execute the trace. Enforce the map barrier at reduce start, publish each accepted output once, and reveal partitions only when all reducers have committed.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Dean & Ghemawat · MapReduce (§3.3 task re-execution, §3.6 backup tasks, §4.1 partitioning)](https://research.google/pubs/mapreduce-simplified-data-processing-on-large-clusters/)
