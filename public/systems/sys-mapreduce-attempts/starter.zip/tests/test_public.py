import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_speculative_winner_closes_other_attempts(self):
        args = [{'active': ['a', 'b'], 'retired': [], 'winner': None}, 'finish', 'b']
        expected = [{'active': [], 'retired': [], 'winner': 'b'}, 'accepted']
        actual = trial('attempts.transition', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_route_utf_8_bytes_and_preserve_input_order(self):
        args = [['a', 'b', 'aa', 'é'], 2]
        expected = [[['b', 1], ['aa', 1], ['é', 1]], [['a', 1]]]
        actual = trial('shuffle.scatter', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_a_reduce_start_before_the_barrier_creates_no_live_attempt(self):
        args = [[['x']], 1, [['start', 'r0', 'first'], ['finish', 'r0', 'first']]]
        expected = {'finishes': ['stale'],
 'partitions': None,
 'reads': [],
 'winners': {'m0': None, 'r0': None}}
        actual = trial('coordinator.replay', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

