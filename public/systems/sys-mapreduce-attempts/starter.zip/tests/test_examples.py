import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [['start', 'm0', 'P'],
            ['finish', 'm0', 'P'],
            ['start', 'm1', 'Q'],
            ['finish', 'm1', 'Q'],
            ['start', 'r0', 'S'],
            ['finish', 'r0', 'S'],
            ['read']],
 'reducers': 1,
 'splits': [['kiwi', 'fig', 'fig'], ['fig']]}
        expected = {'finishes': ['accepted', 'accepted', 'accepted'],
 'partitions': [[['fig', 3], ['kiwi', 1]]],
 'reads': [[[['fig', 3], ['kiwi', 1]]]],
 'winners': {'m0': 'P', 'm1': 'Q', 'r0': 'S'}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['start', 'r0', 'early'],
            ['start', 'm0', 'slow'],
            ['expire', 'm0', 'slow'],
            ['start', 'm0', 'new'],
            ['start', 'm0', 'backup'],
            ['finish', 'm0', 'slow'],
            ['finish', 'm0', 'backup'],
            ['finish', 'm0', 'new'],
            ['finish', 'm0', 'backup'],
            ['finish', 'r0', 'early'],
            ['read'],
            ['start', 'r0', 'now'],
            ['finish', 'r0', 'now']],
 'reducers': 1,
 'splits': [['a', 'a']]}
        expected = {'finishes': ['stale',
              'accepted',
              'superseded',
              'replay',
              'stale',
              'accepted'],
 'partitions': [[['a', 2]]],
 'reads': [None],
 'winners': {'m0': 'backup', 'r0': 'now'}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
