"""Schedule replay and output manifests shared by all task attempts."""
from copy import deepcopy
from attempts import transition
from shuffle import scatter, reduce_bucket

def replay(splits, reducers, events):
    """Execute the trace. Enforce the map barrier at reduce start, publish each accepted output once, and reveal partitions only when all reducers have committed."""
    raise NotImplementedError('replay')
