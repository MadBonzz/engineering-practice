"""Replay wire and timer events at one membership observer."""
from membership import hear
from detector import handle_probe, expire

def handle(request):
    table = {n: [0, "alive"] for n in request["members"]}
    observer = request["observer"]
    pending, sent = {}, []
    for event in request["events"]:
        if event[0] == "gossip":
            sent.extend(hear(table, observer, *event[1:]))
        elif event[0] == "expire":
            sent.extend(expire(table, *event[1:]))
        else:
            sent.extend(handle_probe(table, pending, observer, request["helpers"], event))
    return {"table": table, "sent": sent}
