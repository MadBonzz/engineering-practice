from membership import merge

def handle_probe(table, pending, observer, limit, event):
    """Mutate table/pending and return outbound messages for one probe, timeout or ACK. Keep target, original incarnation and stage for each pending token."""
    raise NotImplementedError('handle_probe')

def expire(table, node, inc):
    """Confirm a suspect whose current incarnation equals inc. Update in place and return the emitted messages."""
    raise NotImplementedError('expire')
