PRECEDENCE = {"alive": 0, "suspect": 1, "dead": 2}

def merge(record, rumor):
    """Return the winning [incarnation,status]. Compare incarnation first; break ties by alive < suspect < dead."""
    raise NotImplementedError('merge')

def hear(table, observer, node, inc, status):
    """Merge incoming gossip into table in place. Return outgoing ALIVE messages when the observer refutes a current or newer self-suspicion."""
    raise NotImplementedError('hear')
