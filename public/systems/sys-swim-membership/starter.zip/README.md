# SWIM membership · investigate a false suspicion

A slow service answers a relayed ping just as a timeout fires. Later, stale gossip accuses the recovered process again. Implement the failure detector and incarnation-aware membership table at a single observer. Return the outgoing messages so an operator can distinguish a relayed success from a declaration of failure.

## Implementation scope

A deterministic observer-level SWIM-style replay of probing, suspicion and refutation. The trace supplies rumor delivery, expiration and scheduling. Helper selection is deterministic for grading; random peer sampling, gossip retransmission budgets and full-cluster convergence are outside the exercise.

## Input

members contains distinct node IDs, observer names the local member, and helpers is a nonnegative limit. All members start [0,alive]. Replay events in order: [probe,token,target], [direct_timeout,token], [indirect_timeout,token], [ack,token], [gossip,node,inc,status], [expire,node,inc]. inc is a nonnegative integer; status is alive, suspect or dead. Each probe uses a fresh token and a remote target.

## Output

Return table mapping each member to [incarnation,status], plus sent as ordered message arrays: [PING,token,target], [PING_REQ,token,helper,target], [SUSPECT,node,inc], [ALIVE,observer,inc] or [DEAD,node,inc]. A received remote rumor updates only the table. Announce locally generated suspicion, refutation or death once when it changes state.

## Constraints

Probe only an alive target. On direct timeout, send PING_REQ to at most helpers currently alive third parties in ID order. Any matching ACK closes the pending probe. Indirect timeout suspects only a still-alive target at the probed incarnation. Unknown, late and wrong-phase events are ignored. Remote gossip orders records by incarnation, then alive < suspect < dead. An accepted higher incarnation can rejoin. Expire confirms only a matching suspect. A suspect rumor about self at or above the local incarnation emits ALIVE with rumor incarnation + 1; other self rumors are ignored.

## Example 1

Input

~~~json
{
  "members": [
    "A",
    "B",
    "C"
  ],
  "observer": "A",
  "helpers": 1,
  "events": [
    [
      "probe",
      "p",
      "B"
    ],
    [
      "direct_timeout",
      "p"
    ],
    [
      "ack",
      "p"
    ],
    [
      "indirect_timeout",
      "p"
    ]
  ]
}
~~~

Output

~~~json
{
  "table": {
    "A": [
      0,
      "alive"
    ],
    "B": [
      0,
      "alive"
    ],
    "C": [
      0,
      "alive"
    ]
  },
  "sent": [
    [
      "PING",
      "p",
      "B"
    ],
    [
      "PING_REQ",
      "p",
      "C",
      "B"
    ]
  ]
}
~~~

A asks C to relay a ping to B. The matching acknowledgement closes p. Its late timeout emits nothing.

## Example 2

Input

~~~json
{
  "members": [
    "A",
    "B",
    "C"
  ],
  "observer": "A",
  "helpers": 1,
  "events": [
    [
      "probe",
      "p",
      "B"
    ],
    [
      "direct_timeout",
      "p"
    ],
    [
      "indirect_timeout",
      "p"
    ],
    [
      "gossip",
      "B",
      1,
      "alive"
    ],
    [
      "expire",
      "B",
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "table": {
    "A": [
      0,
      "alive"
    ],
    "B": [
      1,
      "alive"
    ],
    "C": [
      0,
      "alive"
    ]
  },
  "sent": [
    [
      "PING",
      "p",
      "B"
    ],
    [
      "PING_REQ",
      "p",
      "C",
      "B"
    ],
    [
      "SUSPECT",
      "B",
      0
    ]
  ]
}
~~~

B's later incarnation supersedes the suspicion. Expiring the old timer cannot mark B dead.

## Part 1 · Merge rumors and refute suspicion

Define the partial order on versions and issue a higher incarnation when this node is suspected.

membership.py · merge(record, rumor) — Return the winning [incarnation,status]. Compare incarnation first; break ties by alive < suspect < dead.

membership.py · hear(table, observer, node, inc, status) — Merge incoming gossip into table in place. Return outgoing ALIVE messages when the observer refutes a current or newer self-suspicion.

## Part 2 · Drive direct and indirect probes

Correlate acknowledgements with tokens and fence failure timers by incarnation.

detector.py · handle_probe(table, pending, observer, limit, event) — Mutate table/pending and return outbound messages for one probe, timeout or ACK. Keep target, original incarnation and stage for each pending token.

detector.py · expire(table, node, inc) — Confirm a suspect whose current incarnation equals inc. Update in place and return the emitted messages.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Das, Gupta and Motivala · SWIM group membership](https://www.cs.cornell.edu/projects/Quicksilver/public_pdfs/SWIM.pdf)
