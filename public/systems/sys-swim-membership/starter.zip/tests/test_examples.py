import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [['probe', 'p', 'B'],
            ['direct_timeout', 'p'],
            ['ack', 'p'],
            ['indirect_timeout', 'p']],
 'helpers': 1,
 'members': ['A', 'B', 'C'],
 'observer': 'A'}
        expected = {'sent': [['PING', 'p', 'B'], ['PING_REQ', 'p', 'C', 'B']],
 'table': {'A': [0, 'alive'], 'B': [0, 'alive'], 'C': [0, 'alive']}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['probe', 'p', 'B'],
            ['direct_timeout', 'p'],
            ['indirect_timeout', 'p'],
            ['gossip', 'B', 1, 'alive'],
            ['expire', 'B', 0]],
 'helpers': 1,
 'members': ['A', 'B', 'C'],
 'observer': 'A'}
        expected = {'sent': [['PING', 'p', 'B'],
          ['PING_REQ', 'p', 'C', 'B'],
          ['SUSPECT', 'B', 0]],
 'table': {'A': [0, 'alive'], 'B': [1, 'alive'], 'C': [0, 'alive']}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
