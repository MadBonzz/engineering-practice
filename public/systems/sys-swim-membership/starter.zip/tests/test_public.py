import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_same_incarnation_gossip_preserves_suspicion(self):
        args = [[3, 'suspect'], [3, 'alive']]
        expected = [3, 'suspect']
        actual = trial('membership.merge', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_a_direct_timeout_delegates_to_c(self):
        args = [{'A': [0, 'alive'], 'B': [0, 'alive'], 'C': [1, 'alive']},
 {'p': ['B', 0, 'direct']},
 'A',
 1,
 ['direct_timeout', 'p']]
        expected = [['PING_REQ', 'p', 'C', 'B']]
        actual = trial('detector.handle_probe', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

