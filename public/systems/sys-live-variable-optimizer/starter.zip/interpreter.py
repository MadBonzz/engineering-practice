'''Executable semantics. The budget counts block entries, independent of body lengths.'''
def run(blocks, entry, initial, budget):
    env = dict(initial)
    trace = []
    label = entry
    for _ in range(budget):
        block = blocks[label]
        for inst in block["body"]:
            op, *args = inst
            if op == "emit":
                trace.append(env[args[0]])
            elif op == "const":
                env[args[0]] = args[1]
            elif op == "copy":
                env[args[0]] = env[args[1]]
            elif op == "add":
                env[args[0]] = env[args[1]] + env[args[2]]
            elif op == "div":
                if env[args[2]] == 0:
                    return {"status": "division_by_zero", "value": None, "trace": trace}
                env[args[0]] = env[args[1]] // env[args[2]]
        op, *args = block["end"]
        if op == "ret":
            return {"status": "return", "value": env[args[0]], "trace": trace}
        if op == "jump":
            label = args[0]
        else:
            label = args[1] if env[args[0]] != 0 else args[2]
    return {"status": "budget", "value": None, "trace": trace}
