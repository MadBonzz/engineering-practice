'''Utilities shared by analysis, optimizer and execution.'''
def successors(end):
    if end[0] == "jump":
        return end[1:]
    if end[0] == "br":
        return end[2:]
    return []

def end_reads(end):
    return {end[1]} if end[0] in ("br", "ret") else set()

def operands(inst):
    '''Return the defined name (or None) and the set of names read.'''
    op = inst[0]
    if op == "emit":
        return None, {inst[1]}
    if op == "const":
        return inst[1], set()
    return inst[1], set(inst[2:])

def select(blocks, kept):
    return {label: {"body": [block["body"][i] for i in kept[label]], "end": block["end"]}
            for label, block in blocks.items()}
