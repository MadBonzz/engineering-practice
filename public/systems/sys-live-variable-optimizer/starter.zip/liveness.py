from ir import end_reads, operands, successors

def solve(blocks):
    """Return sorted live-in variable lists by block, at the least fixed point for the given bodies."""
    raise NotImplementedError('solve')
