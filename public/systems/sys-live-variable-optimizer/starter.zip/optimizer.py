from ir import end_reads, operands, select, successors
from liveness import solve

def retained(blocks):
    """Return original zero-based body indices remaining after repeated liveness-based dead assignment elimination."""
    raise NotImplementedError('retained')
