'''Run the optimizer, attach its analysis and execute the retained IR.'''
from ir import select
from interpreter import run
from liveness import solve
from optimizer import retained

def handle(request):
    kept = retained(request["blocks"])
    optimized = select(request["blocks"], kept)
    result = run(optimized, request["entry"], request["env"], request["budget"])
    return {"kept": kept, "live_in": solve(optimized), "result": result}
