# Remove dead assignments across a control-flow graph

A compiler deletes an accumulator that a loop reads on its next iteration. Its cleanup pass also keeps whole chains that feed a single unused value. Implement backward liveness and an optimizer over a small imperative IR, then run the optimized program in the supplied interpreter. An emitted event or a division error is observable even if the destination is never read.

## Implementation scope

Implement the classical least fixed point for liveness. At each optimization round, take block live-outs from that round's unmodified CFG, scan bodies backward, and drop pure writes to dead variables without adding their operands to liveness. Recompute after pruning until no instruction is removed. Keep every div, emit, and terminator. This defines the required output even for dead cycles of mutually dependent assignments.

## Input

blocks maps labels to {body, end}. A body is an ordered list of instructions ["const", dst, int], ["copy", dst, src], ["add", dst, a, b], ["div", dst, a, b], or ["emit", src]. A terminator is ["ret", src], ["jump", label], or ["br", cond, true_label, false_label]. entry names the first block, env maps incoming variables to integers, and budget is the maximum number of block visits.

## Output

Return kept, live_in, and result. kept maps every block to the original zero-based body indices retained in original order. live_in maps every block of the final program to its sorted list of live variables at entry. result is {status, value, trace}; status is 'return', 'division_by_zero', or 'budget'. value is null unless the program returns. trace lists the integer values emitted before stopping.

## Constraints

All labels and reachable reads are defined. Inputs have 1–40 blocks, 0–40 instructions per block, and a visit budget of 1–256. Arithmetic is integer arithmetic. Division floors toward negative infinity and traps on zero. br takes its true edge for a nonzero value. On budget exhaustion stop before entering the next block. Analyse every given block and both edges of br, including untaken edges.

## Example 1

Input

~~~json
{
  "blocks": {
    "entry": {
      "body": [
        [
          "const",
          "tmp",
          2
        ],
        [
          "add",
          "stale",
          "tmp",
          "p"
        ],
        [
          "const",
          "x",
          3
        ],
        [
          "emit",
          "x"
        ]
      ],
      "end": [
        "jump",
        "exit"
      ]
    },
    "exit": {
      "body": [
        [
          "copy",
          "unused",
          "stale"
        ]
      ],
      "end": [
        "ret",
        "x"
      ]
    }
  },
  "env": {
    "p": 7
  },
  "entry": "entry",
  "budget": 32
}
~~~

Output

~~~json
{
  "kept": {
    "entry": [
      2,
      3
    ],
    "exit": []
  },
  "live_in": {
    "entry": [],
    "exit": [
      "x"
    ]
  },
  "result": {
    "status": "return",
    "value": 3,
    "trace": [
      3
    ]
  }
}
~~~

Removing exit's unused copy makes stale dead in the predecessor. On a later pass the add disappears, and hence so does the constant that feeds it. The emit and return still see 3.

## Example 2

Input

~~~json
{
  "blocks": {
    "entry": {
      "body": [
        [
          "const",
          "n",
          2
        ],
        [
          "const",
          "step",
          -1
        ],
        [
          "const",
          "z",
          0
        ]
      ],
      "end": [
        "jump",
        "loop"
      ]
    },
    "loop": {
      "body": [
        [
          "emit",
          "n"
        ],
        [
          "add",
          "n",
          "n",
          "step"
        ]
      ],
      "end": [
        "br",
        "n",
        "loop",
        "exit"
      ]
    },
    "exit": {
      "body": [],
      "end": [
        "ret",
        "n"
      ]
    }
  },
  "env": {},
  "entry": "entry",
  "budget": 32
}
~~~

Output

~~~json
{
  "kept": {
    "entry": [
      0,
      1
    ],
    "loop": [
      0,
      1
    ],
    "exit": []
  },
  "live_in": {
    "entry": [],
    "loop": [
      "n",
      "step"
    ],
    "exit": [
      "n"
    ]
  },
  "result": {
    "status": "return",
    "value": 0,
    "trace": [
      2,
      1
    ]
  }
}
~~~

On each loop visit emit reads the current n before add writes its replacement. The back edge carries both n and step. The unused z initialization disappears. After emitting 2 and 1 the branch exits with n equal to zero.

## Part 1 · Solve backward liveness through cycles

Compute live-in on the given CFG before any pruning. At a block exit take the union of successor live-ins. Include terminator reads, then process each instruction backward, killing its destination before adding its reads. Return every block's live-in as a sorted list.

liveness.py · solve(blocks) — Return sorted live-in variable lists by block, at the least fixed point for the given bodies.

## Part 2 · Prune across blocks without changing observable behavior

Return the surviving original instruction indices by block. For each round solve liveness on the current program, prune backward from each block's live-out and terminator reads, then repeat after any removal. Effectful operations must survive even when their destination is dead.

optimizer.py · retained(blocks) — Return original zero-based body indices remaining after repeated liveness-based dead assignment elimination.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Cornell CS 4120 · Live Variable Analysis](https://www.cs.cornell.edu/courses/cs4120/2023sp/notes/livevar/)

- [Cornell CS 6120 · Data Flow](https://www.cs.cornell.edu/courses/cs6120/2020fa/lesson/4/)
