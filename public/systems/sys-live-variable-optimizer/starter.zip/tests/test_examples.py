import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'blocks': {'entry': {'body': [['const', 'tmp', 2],
                               ['add', 'stale', 'tmp', 'p'],
                               ['const', 'x', 3],
                               ['emit', 'x']],
                      'end': ['jump', 'exit']},
            'exit': {'body': [['copy', 'unused', 'stale']],
                     'end': ['ret', 'x']}},
 'budget': 32,
 'entry': 'entry',
 'env': {'p': 7}}
        expected = {'kept': {'entry': [2, 3], 'exit': []},
 'live_in': {'entry': [], 'exit': ['x']},
 'result': {'status': 'return', 'trace': [3], 'value': 3}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'blocks': {'entry': {'body': [['const', 'n', 2],
                               ['const', 'step', -1],
                               ['const', 'z', 0]],
                      'end': ['jump', 'loop']},
            'exit': {'body': [], 'end': ['ret', 'n']},
            'loop': {'body': [['emit', 'n'], ['add', 'n', 'n', 'step']],
                     'end': ['br', 'n', 'loop', 'exit']}},
 'budget': 32,
 'entry': 'entry',
 'env': {}}
        expected = {'kept': {'entry': [0, 1], 'exit': [], 'loop': [0, 1]},
 'live_in': {'entry': [], 'exit': ['n'], 'loop': ['n', 'step']},
 'result': {'status': 'return', 'trace': [2, 1], 'value': 0}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
