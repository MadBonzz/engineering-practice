import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_a_loop_carried_variable_reads_its_old_value(self):
        args = [{'done': {'body': [], 'end': ['ret', 'x']},
  'entry': {'body': [['add', 'x', 'x', 's']], 'end': ['br', 'x', 'entry', 'done']}}]
        expected = {'done': ['x'], 'entry': ['s', 'x']}
        actual = trial('liveness.solve', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_eliminate_transitive_cross_block_dead_uses(self):
        args = [{'entry': {'body': [['const', 'tmp', 2],
                     ['add', 'stale', 'tmp', 'p'],
                     ['const', 'x', 3],
                     ['emit', 'x']],
            'end': ['jump', 'exit']},
  'exit': {'body': [['copy', 'unused', 'stale']], 'end': ['ret', 'x']}}]
        expected = {'entry': [2, 3], 'exit': []}
        actual = trial('optimizer.retained', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

