from fib import lookup

def change_word(checksum, old, new):
    """Apply RFC 1624 Eq. 3 to a 16-bit header checksum and one changed 16-bit network-order word. Return an unsigned checksum."""
    raise NotImplementedError('change_word')

def forward(root, dst, ttl, proto, checksum):
    """Return a drop reason or [forward,hop,adjusted TTL,adjusted checksum] for one validated transit packet."""
    raise NotImplementedError('forward')
