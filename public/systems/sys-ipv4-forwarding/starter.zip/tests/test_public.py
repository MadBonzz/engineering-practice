import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_attach_a_route_below_the_default(self):
        args = [{'hop': 'd'}, '128.0.0.0/2', 'a']
        expected = {'1': {'0': {'hop': 'a'}}, 'hop': 'd'}
        actual = trial('fib.install', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_ones_complement_boundary_yields_zero(self):
        args = [65279, 529, 273]
        expected = 0
        actual = trial('forwarding.change_word', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

