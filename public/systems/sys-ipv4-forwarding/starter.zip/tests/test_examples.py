import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [['add', '0.0.0.0/0', 'wan'],
            ['add', '10.0.0.0/8', 'lan'],
            ['send', '10.1.2.3', 4, 17, 4660],
            ['del', '10.0.0.0/8'],
            ['send', '10.1.2.3', 4, 17, 4660]]}
        expected = [['forward', 'lan', 3, 4916], ['forward', 'wan', 3, 4916]]
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [['add', '198.51.100.7/32', 'host'],
            ['send', '198.51.100.7', 1, 6, 123],
            ['send', '198.51.100.8', 64, 6, 123],
            ['send', '198.51.100.7', 2, 17, 65279]]}
        expected = [['drop', 'time-exceeded'],
 ['drop', 'no-route'],
 ['forward', 'host', 1, 0]]
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
