'''Feed control-plane updates and transit packets to the same forwarding table.'''
from fib import install
from forwarding import forward

def handle(request):
    root = {}
    packets = []
    for op, *fields in request["events"]:
        if op == "add":
            install(root,*fields)
        elif op == "del":
            install(root,fields[0],None)
        else:
            packets.append(forward(root,*fields))
    return packets
