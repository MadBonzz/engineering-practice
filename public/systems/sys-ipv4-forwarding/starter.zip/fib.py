from address_bits import path, prefix_path

def install(root, cidr, hop):
    """Mutate and return root. Node keys "0"/"1" are child dictionaries, and "hop" is optional. A None hop removes the route and prunes empty nodes, preserving the root."""
    raise NotImplementedError('install')

def lookup(root, address):
    """Return the most specific next hop for the IPv4 address, or None if no prefix matches. Inspect at most 32 child edges."""
    raise NotImplementedError('lookup')
