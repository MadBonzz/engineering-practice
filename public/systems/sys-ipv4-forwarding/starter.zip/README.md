# Build a forwarding trie and update IPv4 headers

A router learns a specific subnet and later loses it. Packets should switch to the remaining covering route, leave with one fewer hop, and carry a consistent header checksum. Build the forwarding information base and connect it to the packet path.

## Implementation scope

An IPv4 unicast forwarding core with a dynamic binary prefix trie and an incremental Internet checksum. The trace supplies validated headers and names the egress next hop. Drop reasons stand in for generating ICMP messages. ARP, local delivery, options, fragmentation, and routing-protocol convergence are outside the model.

## Input

events is an ordered list. [add,cidr,hop] installs or replaces one route to a string next hop. [del,cidr] withdraws that exact prefix if present. [send,dst,ttl,proto,checksum] supplies an IPv4 destination, TTL (1–255), protocol (0–255), and an existing 16-bit header checksum. CIDRs have canonical network addresses; all IP addresses are ordinary dotted IPv4 strings.

## Output

Return a list in send order. Each result is [forward,hop,newTTL,newChecksum], [drop,time-exceeded], or [drop,no-route]. Route updates do not emit output. In this lab a TTL of one yields time-exceeded even if the route table is empty.

## Constraints

Walk address bits from most significant to least. Prefer the matching route with the longest prefix length; /0 is a valid default and /32 an exact host. A withdrawal keeps both more-specific descendants and shorter alternatives. Decrement TTL by one and update only the combined TTL/protocol 16-bit word using RFC 1624 equation 3, folding end-around carry. Keep the canonical zero checksum from that equation.

## Example 1

Input

~~~json
{
  "events": [
    [
      "add",
      "0.0.0.0/0",
      "wan"
    ],
    [
      "add",
      "10.0.0.0/8",
      "lan"
    ],
    [
      "send",
      "10.1.2.3",
      4,
      17,
      4660
    ],
    [
      "del",
      "10.0.0.0/8"
    ],
    [
      "send",
      "10.1.2.3",
      4,
      17,
      4660
    ]
  ]
}
~~~

Output

~~~json
[
  [
    "forward",
    "lan",
    3,
    4916
  ],
  [
    "forward",
    "wan",
    3,
    4916
  ]
]
~~~

10.1.2.3 matches both routes at first; withdrawing /8 reveals /0. In each packet 0x0411 becomes 0x0311, changing checksum 0x1234 to 0x1334.

## Example 2

Input

~~~json
{
  "events": [
    [
      "add",
      "198.51.100.7/32",
      "host"
    ],
    [
      "send",
      "198.51.100.7",
      1,
      6,
      123
    ],
    [
      "send",
      "198.51.100.8",
      64,
      6,
      123
    ],
    [
      "send",
      "198.51.100.7",
      2,
      17,
      65279
    ]
  ]
}
~~~

Output

~~~json
[
  [
    "drop",
    "time-exceeded"
  ],
  [
    "drop",
    "no-route"
  ],
  [
    "forward",
    "host",
    1,
    0
  ]
]
~~~

The first TTL expires. The next address misses the host route. The final packet's checksum 0xFEFF and TTL/protocol update 0x0211 → 0x0111 produce 0x0000 by one's-complement arithmetic.

## Part 1 · Maintain the forwarding information base

Insert, replace, and withdraw exact CIDRs without damaging neighboring routes. Resolve destinations by remembering the last matching hop.

fib.py · install(root, cidr, hop) — Mutate and return root. Node keys "0"/"1" are child dictionaries, and "hop" is optional. A None hop removes the route and prunes empty nodes, preserving the root.

fib.py · lookup(root, address) — Return the most specific next hop for the IPv4 address, or None if no prefix matches. Inspect at most 32 child edges.

## Part 2 · Decrement TTL and repair the checksum

Dispatch or drop each incoming packet and incrementally replace its TTL/protocol header word using one's-complement arithmetic.

forwarding.py · change_word(checksum, old, new) — Apply RFC 1624 Eq. 3 to a 16-bit header checksum and one changed 16-bit network-order word. Return an unsigned checksum.

forwarding.py · forward(root, dst, ttl, proto, checksum) — Return a drop reason or [forward,hop,adjusted TTL,adjusted checksum] for one validated transit packet.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [RFC 1812 · IPv4 forwarding and longest-match route selection](https://www.rfc-editor.org/rfc/rfc1812)

- [RFC 1624 · Incremental update of the Internet checksum](https://www.rfc-editor.org/rfc/rfc1624)
