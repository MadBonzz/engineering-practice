'''Provided address parser. The high-order bit of an IPv4 address is bit 0.'''
from ipaddress import IPv4Address, IPv4Network

def path(value, length=32):
    address = int(IPv4Address(value))
    return [str((address >> (31-i)) & 1) for i in range(length)]

def prefix_path(cidr):
    network = IPv4Network(cidr)
    return path(network.network_address,network.prefixlen)
