"""Validate and publish a write set as a single atomic commit."""
def publish(chains, staged, snapshot, clock):
    """Return [status,new_clock,new_chains]. Each chain holds ascending [timestamp,value] versions; never partially publish."""
    raise NotImplementedError('publish')
