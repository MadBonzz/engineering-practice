"""Look up committed and transaction-local values."""
def read(chains, staged, snapshot, key):
    """Return the value in staged or at the latest committed version <= snapshot. Missing and deleted keys read as None."""
    raise NotImplementedError('read')
