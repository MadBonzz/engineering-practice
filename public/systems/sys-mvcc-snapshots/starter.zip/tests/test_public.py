import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_a_snapshot_between_deletion_and_reinsertion(self):
        args = [{'x': [[0, 3], [3, None], [5, 8]]}, {}, 4, 'x']
        expected = None
        actual = trial('version_store.read', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_abort_every_write_when_a_touched_key_has_a_newer_tombstone(self):
        args = [{'x': [[0, 1], [2, None]]}, {'new': 8, 'x': 4}, 0, 2]
        expected = ['abort', 2, {'x': [[0, 1], [2, None]]}]
        actual = trial('commit_log.publish', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

