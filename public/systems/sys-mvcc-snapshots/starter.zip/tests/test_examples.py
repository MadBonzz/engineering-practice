import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'initial': {'balance': 100},
 'ops': [['begin', 'a'],
         ['begin', 'b'],
         ['put', 'a', 'balance', 90],
         ['get', 'b', 'balance'],
         ['commit', 'a'],
         ['get', 'b', 'balance'],
         ['put', 'b', 'balance', 80],
         ['commit', 'b']]}
        expected = {'live': {'balance': 90},
 'outcomes': [['a', 'commit', 1], ['b', 'abort', None]],
 'reads': [['b', 'balance', 100], ['b', 'balance', 100]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'initial': {'alice': 1, 'bob': 1},
 'ops': [['begin', 't1'],
         ['begin', 't2'],
         ['get', 't1', 'bob'],
         ['get', 't2', 'alice'],
         ['put', 't1', 'alice', 0],
         ['put', 't2', 'bob', 0],
         ['commit', 't1'],
         ['commit', 't2']]}
        expected = {'live': {'alice': 0, 'bob': 0},
 'outcomes': [['t1', 'commit', 1], ['t2', 'commit', 2]],
 'reads': [['t1', 'bob', 1], ['t2', 'alice', 1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
