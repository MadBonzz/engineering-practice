"""Own transaction lifetimes and expose operations in trace order."""
from version_store import read
from commit_log import publish

def handle(request):
    chains = {key: [[0, value]] for key, value in request["initial"].items()}
    clock = 0
    active, reads, outcomes = {}, [], []
    for action, tx_id, *args in request["ops"]:
        if action == "begin":
            active[tx_id] = [clock, {}]
            continue
        snapshot, staged = active[tx_id]
        if action == "get":
            key = args[0]
            reads.append([tx_id, key, read(chains, staged, snapshot, key)])
        elif action in ("put", "del"):
            staged[args[0]] = args[1] if action == "put" else None
        elif action in ("commit", "abort"):
            status = "abort"
            if action == "commit":
                status, clock, chains = publish(chains, staged, snapshot, clock)
            outcomes.append([tx_id, status, clock if status == "commit" else None])
            del active[tx_id]
    live = {key: history[-1][1] for key, history in chains.items() if history[-1][1] is not None}
    return {"reads": reads, "outcomes": outcomes, "live": live}
