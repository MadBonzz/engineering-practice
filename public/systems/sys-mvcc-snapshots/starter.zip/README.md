# MVCC · implement snapshot isolation and reproduce write skew

Two on-call engineers each see the other person on duty and take themselves off call. Your transaction engine should reproduce that outcome under snapshot isolation, while rejecting two concurrent writers to the same key. Implement version selection and atomic commit, then use the replay trace to explain the difference.

## Implementation scope

The engine simulates interleaved point reads, writes, and deletes with one logical commit clock. Transactions capture their snapshot at begin. The harness retains history for all snapshots. This version uses optimistic first-committer-wins validation.

## Input

initial maps string keys to integer values at version 0. ops contains ["begin",id], ["get",id,key], ["put",id,key,value], ["del",id,key], ["commit",id], or ["abort",id]. Each id begins once. All subsequent operations reference an open transaction. A transaction can issue repeated reads and writes.

## Output

Return reads as [id,key,value_or_null] in get order, outcomes as [id,"commit",timestamp] or [id,"abort",null] in completion order, and live as a map of the latest non-deleted keys. Only a successful transaction with writes increments the clock. A successful read-only transaction reports the current clock.

## Constraints

Read the transaction’s private writes first, including deletes. Otherwise pick the committed version with the largest timestamp ≤ the transaction’s snapshot. On commit, check every written key for a committed version newer than the snapshot, including tombstones. One conflict aborts the entire transaction. Install all uncontended writes at a single fresh timestamp. A delete of a missing key still writes a version. Reads of keys written by others do not themselves cause an abort. Explicit aborts publish nothing.

## Example 1

Input

~~~json
{
  "initial": {
    "balance": 100
  },
  "ops": [
    [
      "begin",
      "a"
    ],
    [
      "begin",
      "b"
    ],
    [
      "put",
      "a",
      "balance",
      90
    ],
    [
      "get",
      "b",
      "balance"
    ],
    [
      "commit",
      "a"
    ],
    [
      "get",
      "b",
      "balance"
    ],
    [
      "put",
      "b",
      "balance",
      80
    ],
    [
      "commit",
      "b"
    ]
  ]
}
~~~

Output

~~~json
{
  "reads": [
    [
      "b",
      "balance",
      100
    ],
    [
      "b",
      "balance",
      100
    ]
  ],
  "outcomes": [
    [
      "a",
      "commit",
      1
    ],
    [
      "b",
      "abort",
      null
    ]
  ],
  "live": {
    "balance": 90
  }
}
~~~

Both transactions begin at 0. B reads the original balance before and after A commits. When B tries to publish, A’s version 1 is newer than B’s snapshot, so B aborts.

## Example 2

Input

~~~json
{
  "initial": {
    "alice": 1,
    "bob": 1
  },
  "ops": [
    [
      "begin",
      "t1"
    ],
    [
      "begin",
      "t2"
    ],
    [
      "get",
      "t1",
      "bob"
    ],
    [
      "get",
      "t2",
      "alice"
    ],
    [
      "put",
      "t1",
      "alice",
      0
    ],
    [
      "put",
      "t2",
      "bob",
      0
    ],
    [
      "commit",
      "t1"
    ],
    [
      "commit",
      "t2"
    ]
  ]
}
~~~

Output

~~~json
{
  "reads": [
    [
      "t1",
      "bob",
      1
    ],
    [
      "t2",
      "alice",
      1
    ]
  ],
  "outcomes": [
    [
      "t1",
      "commit",
      1
    ],
    [
      "t2",
      "commit",
      2
    ]
  ],
  "live": {
    "alice": 0,
    "bob": 0
  }
}
~~~

Each transaction reads its colleague’s original value and writes only its own row. The write sets are disjoint, so both commits succeed and the on-call invariant fails. This is write skew.

## Part 1 · Serve reads from the correct snapshot

Resolve the transaction’s private overlay and version chain, including historical reads after a delete.

version_store.py · read(chains, staged, snapshot, key) — Return the value in staged or at the latest committed version <= snapshot. Missing and deleted keys read as None.

## Part 2 · Validate and publish a write set atomically

Apply first-committer-wins to all written keys before installing any new version.

commit_log.py · publish(chains, staged, snapshot, clock) — Return [status,new_clock,new_chains]. Each chain holds ascending [timestamp,value] versions; never partially publish.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [PostgreSQL · transaction isolation and serialization anomalies](https://www.postgresql.org/docs/current/transaction-iso.html)
