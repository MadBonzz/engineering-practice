"""Deterministic per-link FIFO transport with live balances and one snapshot instance."""
from collections import deque
from markers import mark
from channels import record_payment, assemble

def handle(request):
    balances = request["balances"].copy()
    edges = request["edges"]
    queues = {(a, b): deque() for a, b in edges}
    cuts = dict.fromkeys(balances)

    def receive_marker(node, sender):
        incoming = [a for a, b in edges if b == node]
        cuts[node], broadcast = mark(cuts[node], balances[node], incoming, sender)
        if broadcast:
            for a, b in edges:
                if a == node:
                    queues[a, b].append(None)

    for event in request["events"]:
        if event[0] == "start":
            receive_marker(event[1], None)
        else:
            a, b = event[1:3]
            queue = queues[a, b]
            if event[0] == "send":
                payment = event[3:]
                balances[a] -= payment[1]
                queue.append(payment)
            elif queue:
                payment = queue.popleft()
                if payment is None:
                    receive_marker(b, a)
                else:
                    balances[b] += payment[1]
                    cuts[b] = record_payment(cuts[b], a, payment)
    return assemble(cuts, edges)
