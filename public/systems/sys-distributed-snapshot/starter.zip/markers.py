def mark(cut, balance, incoming, sender):
    """Return [next_cut,broadcast]. cut is None or {balance,open,messages}. Open uses sorted sender IDs. sender=None starts locally; a marker closes its sender. Broadcast only on first recording."""
    raise NotImplementedError('mark')
