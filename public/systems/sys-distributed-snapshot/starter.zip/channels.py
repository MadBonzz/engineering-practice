def record_payment(cut, sender, payment):
    """Return next_cut, copying a payment [id,amount] into this sender's log only while its channel is open. Preserve other channels and the frozen balance."""
    raise NotImplementedError('record_payment')

def assemble(cuts, edges):
    """Format a partial or complete cut, exposing all directed channel logs and all local balances. Sum credits only when every node recorded and all channels closed."""
    raise NotImplementedError('assemble')
