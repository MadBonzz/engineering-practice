# Distributed snapshot · account for money in flight

Two ledgers transfer credits over FIFO links. Recording both balances while payments are moving can make credits seem to disappear. Implement the Chandy–Lamport marker rules and channel recorder in the supplied transport simulator. Produce a consistent cut that an auditor can add up.

## Implementation scope

One asynchronous snapshot with reliable FIFO channels, arbitrary delivery interleaving and no process failures. A trace may intentionally stop mid-snapshot. The scheduler, live account debit/credit and per-link queues are provided; the snapshot logic is yours.

## Input

balances maps node IDs to initial integer credits. edges lists distinct directed [source,destination] links. Replay [send,source,destination,id,amount], [deliver,source,destination] and [start,node]. Each send debits immediately and queues the identified positive transfer. Each deliver consumes one oldest message (payment or marker) from that link. Delivering from an empty queue does nothing.

## Output

Return local mapping every ID to its frozen balance or null, channels mapping every 'source>destination' edge to [[id,amount],...] in FIFO order (empty until anything is recorded), complete indicating every node was recorded and every incoming channel closed, and total equal to the sum of frozen balances plus recorded transfers only when complete; otherwise total is null.

## Constraints

Only one snapshot instance. start may repeat at the same initiator; record and broadcast once per node. A first marker records the receiver before it does anything else and closes the arriving channel. Upon first recording, enqueue a marker on every outgoing link before processing the next event. Subsequent markers close only their arriving links. An incoming payment always credits the live balance; append it to the snapshot only if that receiver has recorded and the arriving link is still open. Nodes are reachable from the initiator; IDs exclude '>', and traces use valid transfers with unique IDs and sufficient funds.

## Example 1

Input

~~~json
{
  "balances": {
    "A": 10,
    "B": 10
  },
  "edges": [
    [
      "A",
      "B"
    ],
    [
      "B",
      "A"
    ]
  ],
  "events": [
    [
      "send",
      "B",
      "A",
      "x",
      4
    ],
    [
      "start",
      "A"
    ],
    [
      "deliver",
      "A",
      "B"
    ],
    [
      "deliver",
      "B",
      "A"
    ],
    [
      "deliver",
      "B",
      "A"
    ]
  ]
}
~~~

Output

~~~json
{
  "local": {
    "A": 10,
    "B": 6
  },
  "channels": {
    "A>B": [],
    "B>A": [
      [
        "x",
        4
      ]
    ]
  },
  "complete": true,
  "total": 20
}
~~~

B sent four credits before its snapshot. A received them after its own snapshot but before the marker on B>A. The audit counts 10 + 6 + 4.

## Example 2

Input

~~~json
{
  "balances": {
    "A": 10,
    "B": 10
  },
  "edges": [
    [
      "A",
      "B"
    ],
    [
      "B",
      "A"
    ]
  ],
  "events": [
    [
      "send",
      "A",
      "B",
      "x",
      3
    ],
    [
      "start",
      "A"
    ],
    [
      "deliver",
      "A",
      "B"
    ],
    [
      "deliver",
      "A",
      "B"
    ],
    [
      "deliver",
      "B",
      "A"
    ]
  ]
}
~~~

Output

~~~json
{
  "local": {
    "A": 7,
    "B": 13
  },
  "channels": {
    "A>B": [],
    "B>A": []
  },
  "complete": true,
  "total": 20
}
~~~

The A>B queue delivers x before A's marker. B already includes those three credits when it freezes; both recorded channels are empty.

## Part 1 · Freeze the receiver on its first marker

Implement local initiation and the first-versus-subsequent marker rules. Make repeated starts idempotent.

markers.py · mark(cut, balance, incoming, sender) — Return [next_cut,broadcast]. cut is None or {balance,open,messages}. Open uses sorted sender IDs. sender=None starts locally; a marker closes its sender. Broadcast only on first recording.

## Part 2 · Record payments crossing the cut

Preserve per-link arrival order and assemble partial and complete snapshots from the same structures.

channels.py · record_payment(cut, sender, payment) — Return next_cut, copying a payment [id,amount] into this sender's log only while its channel is open. Preserve other channels and the frozen balance.

channels.py · assemble(cuts, edges) — Format a partial or complete cut, exposing all directed channel logs and all local balances. Sum credits only when every node recorded and all channels closed.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Chandy and Lamport · Distributed Snapshots](https://lamport.azurewebsites.net/pubs/chandy.pdf)
