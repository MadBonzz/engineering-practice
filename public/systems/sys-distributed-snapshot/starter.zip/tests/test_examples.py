import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'balances': {'A': 10, 'B': 10},
 'edges': [['A', 'B'], ['B', 'A']],
 'events': [['send', 'B', 'A', 'x', 4],
            ['start', 'A'],
            ['deliver', 'A', 'B'],
            ['deliver', 'B', 'A'],
            ['deliver', 'B', 'A']]}
        expected = {'channels': {'A>B': [], 'B>A': [['x', 4]]},
 'complete': True,
 'local': {'A': 10, 'B': 6},
 'total': 20}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'balances': {'A': 10, 'B': 10},
 'edges': [['A', 'B'], ['B', 'A']],
 'events': [['send', 'A', 'B', 'x', 3],
            ['start', 'A'],
            ['deliver', 'A', 'B'],
            ['deliver', 'A', 'B'],
            ['deliver', 'B', 'A']]}
        expected = {'channels': {'A>B': [], 'B>A': []},
 'complete': True,
 'local': {'A': 7, 'B': 13},
 'total': 20}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
