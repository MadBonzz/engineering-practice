import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_first_marker_closes_just_its_incoming_channel(self):
        args = [None, 6, ['D', 'B'], 'B']
        expected = [{'balance': 6, 'messages': {'B': [], 'D': []}, 'open': ['D']}, True]
        actual = trial('markers.mark', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_open_channel_records_a_payment(self):
        args = [{'balance': 5, 'messages': {'B': []}, 'open': ['B']}, 'B', ['p', 2]]
        expected = {'balance': 5, 'messages': {'B': [['p', 2]]}, 'open': ['B']}
        actual = trial('channels.record_payment', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

