# Schedule interactive jobs with multilevel feedback queues

A long batch job owns the CPU when an interactive job wakes up. Build an event-driven scheduler that reacts immediately, preserves CPU usage across interruptions, and occasionally restores priority. Its dispatch trace is the only evidence available when a job finishes late.

## Implementation scope

One CPU, FIFO queues at each priority, optional global boosts, and alternating CPU/I/O bursts. Time, interrupt handling, and context switches are deterministic. I/O devices can serve any number of sleeping jobs.

## Input

quanta is a nonempty array of positive CPU allotments from highest priority (level 0) to lowest. boost is 0 (disabled) or a positive period. Each job has a distinct string id, nonnegative arrive time, and an odd-length list of positive bursts alternating CPU, I/O duration, CPU. Jobs may be absent.

## Output

Return {timeline, finished}. Each timeline interval [start,end,id,level] represents CPU execution over [start,end). Merge adjacent intervals with the same id and level. Omit idle time. finished maps each id to its completion time.

## Constraints

Charge CPU at the old level first. Exhausting a level budget demotes one level (capped at the bottom) and resets its budget, even if a burst ends then. A continuing job goes to the tail on exhaustion and to its own queue's head on interruption. A sleeping job keeps unused budget and wakes at its queue's tail. At each positive boost multiple, after charging/requeueing and before arrivals/wakes, reset budgets of all unfinished jobs and concatenate ready queues in old priority/FIFO order into level 0. Then enqueue arrivals/wakes sorted by id, and dispatch the highest nonempty queue. New jobs start at 0. Traces end by time 100,000.

## Example 1

Input

~~~json
{
  "quanta": [
    2,
    4
  ],
  "boost": 0,
  "jobs": [
    {
      "id": "A",
      "arrive": 0,
      "bursts": [
        6
      ]
    },
    {
      "id": "B",
      "arrive": 3,
      "bursts": [
        1
      ]
    }
  ]
}
~~~

Output

~~~json
{
  "timeline": [
    [
      0,
      2,
      "A",
      0
    ],
    [
      2,
      3,
      "A",
      1
    ],
    [
      3,
      4,
      "B",
      0
    ],
    [
      4,
      7,
      "A",
      1
    ]
  ],
  "finished": {
    "A": 7,
    "B": 4
  }
}
~~~

A consumes two ticks at level 0. B arrives during A's lower-priority slice and finishes immediately. A resumes with three ticks of its level-1 budget.

## Example 2

Input

~~~json
{
  "quanta": [
    2,
    3
  ],
  "boost": 4,
  "jobs": [
    {
      "id": "X",
      "arrive": 0,
      "bursts": [
        1,
        2,
        3
      ]
    },
    {
      "id": "Y",
      "arrive": 0,
      "bursts": [
        5
      ]
    }
  ]
}
~~~

Output

~~~json
{
  "timeline": [
    [
      0,
      1,
      "X",
      0
    ],
    [
      1,
      3,
      "Y",
      0
    ],
    [
      3,
      4,
      "X",
      0
    ],
    [
      4,
      6,
      "Y",
      0
    ],
    [
      6,
      8,
      "X",
      0
    ],
    [
      8,
      9,
      "Y",
      0
    ]
  ],
  "finished": {
    "X": 8,
    "Y": 9
  }
}
~~~

X's two level-0 ticks straddle its I/O. At time 4 the boost promotes queued Y then X. At time 8 X finishes, and the next boost brings Y back to level 0.

## Part 1 · Account for CPU and dispatch by priority

Make accounting independent of why a run stopped; pick FIFO within the highest nonempty priority.

dispatch_policy.py · charge(level, budget, elapsed, quanta) — Given 0 < elapsed <= budget, return [new_level,new_budget]. A consumed allotment rolls over even at the bottom.

dispatch_policy.py · take(queues) — Remove and return the first job ID in the highest nonempty queue, or None if idle.

## Part 2 · Drive the scheduler from events

Maintain ready queues and wake times. Advance by the shortest competing deadline and emit half-open CPU intervals.

event_loop.py · schedule(jobs, quanta, boost) — Return the compressed timeline and completion map. Jump to the next arrival/wake, boost, burst end or budget exhaustion and resolve ties per the contract.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Arpaci-Dusseau and Arpaci-Dusseau · Scheduling with multilevel feedback queues](https://pages.cs.wisc.edu/~remzi/OSTEP/cpu-sched-mlfq.pdf)
