import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_retain_a_partially_consumed_level_budget(self):
        args = [0, 2, 1, [2, 5]]
        expected = [0, 1]
        actual = trial('dispatch_policy.charge', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_skip_idle_time_before_first_arrival(self):
        args = [[{'arrive': 3, 'bursts': [2], 'id': 'a'}], [1, 2], 0]
        expected = {'finished': {'a': 5}, 'timeline': [[3, 4, 'a', 0], [4, 5, 'a', 1]]}
        actual = trial('event_loop.schedule', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

