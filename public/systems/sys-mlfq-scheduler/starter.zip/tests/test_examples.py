import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'boost': 0,
 'jobs': [{'arrive': 0, 'bursts': [6], 'id': 'A'},
          {'arrive': 3, 'bursts': [1], 'id': 'B'}],
 'quanta': [2, 4]}
        expected = {'finished': {'A': 7, 'B': 4},
 'timeline': [[0, 2, 'A', 0],
              [2, 3, 'A', 1],
              [3, 4, 'B', 0],
              [4, 7, 'A', 1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'boost': 4,
 'jobs': [{'arrive': 0, 'bursts': [1, 2, 3], 'id': 'X'},
          {'arrive': 0, 'bursts': [5], 'id': 'Y'}],
 'quanta': [2, 3]}
        expected = {'finished': {'X': 8, 'Y': 9},
 'timeline': [[0, 1, 'X', 0],
              [1, 3, 'Y', 0],
              [3, 4, 'X', 0],
              [4, 6, 'Y', 0],
              [6, 8, 'X', 0],
              [8, 9, 'Y', 0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
