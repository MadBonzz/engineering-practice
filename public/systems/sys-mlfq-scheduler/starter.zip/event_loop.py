from dispatch_policy import charge, take
from timeline import record

def schedule(jobs, quanta, boost):
    """Return the compressed timeline and completion map. Jump to the next arrival/wake, boost, burst end or budget exhaustion and resolve ties per the contract."""
    raise NotImplementedError('schedule')
