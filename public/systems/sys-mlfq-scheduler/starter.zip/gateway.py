'''Kernel trace entry point. The input order does not break simultaneous ties.'''
from event_loop import schedule

def handle(request):
    return schedule(request["jobs"], request["quanta"], request["boost"])
