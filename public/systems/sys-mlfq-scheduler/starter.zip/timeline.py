'''Provided rendering helper. Retain level changes, merge identical adjacent spans.'''
def record(trace, start, end, pid, level):
    if trace and trace[-1][1] == start and trace[-1][2:] == [pid,level]:
        trace[-1][1] = end
    else:
        trace.append([start,end,pid,level])
