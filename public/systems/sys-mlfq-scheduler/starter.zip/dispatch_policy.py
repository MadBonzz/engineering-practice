def charge(level, budget, elapsed, quanta):
    """Given 0 < elapsed <= budget, return [new_level,new_budget]. A consumed allotment rolls over even at the bottom."""
    raise NotImplementedError('charge')

def take(queues):
    """Remove and return the first job ID in the highest nonempty queue, or None if idle."""
    raise NotImplementedError('take')
