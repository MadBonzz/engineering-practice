'''Render sparse buffered offsets as sorted, non-overlapping half-open ranges.'''
def ranges(pending):
    out = []
    for pos in sorted(int(key) for key in pending):
        if out and pos == out[-1][1]:
            out[-1][1] += 1
        else:
            out.append([pos,pos+1])
    return out
