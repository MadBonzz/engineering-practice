import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_clip_the_left_and_right_edges_and_preserve_an_overlap(self):
        args = [{'2': 255}, 1, 3, 0, '0011223344']
        expected = {'1': 17, '2': 255, '3': 51}
        actual = trial('window.accept', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_deliver_binary_prefix_but_keep_far_data(self):
        args = [{'0': 0, '1': 255, '3': 2}, 0]
        expected = ['00ff', 2, {'3': 2}]
        actual = trial('delivery.drain', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

