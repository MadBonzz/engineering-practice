import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'capacity': 5,
 'segments': [[2, '4344', True], [1, '62', False], [0, '414243', False]]}
        expected = {'closed': True, 'emitted': ['', '', '41624344'], 'next': 4, 'pending': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'capacity': 3,
 'segments': [[2, '00ff', True],
              [0, 'abcd', False],
              [0, 'abcd', False],
              [3, 'ff', False]]}
        expected = {'closed': True,
 'emitted': ['', 'abcd00', '', 'ff'],
 'next': 4,
 'pending': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
