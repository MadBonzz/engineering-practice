'''Replay real byte strings, remembering end-of-stream independently of byte delivery.'''
from window import accept
from delivery import drain
from inspection import ranges

def handle(request):
    pending = {}
    cursor = 0
    final = None
    emitted = []
    for offset, payload, end in request["segments"]:
        if end:
            final = offset + len(payload) // 2
        pending = accept(pending,cursor,request["capacity"],offset,payload)
        batch, cursor, pending = drain(pending,cursor)
        emitted.append(batch)
    return {"emitted":emitted, "next":cursor, "pending":ranges(pending), "closed":cursor == final}
