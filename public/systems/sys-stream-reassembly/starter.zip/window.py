def accept(pending, cursor, capacity, offset, payload):
    """Return an updated offset-to-byte dict. Keys are decimal offset strings; values are byte integers. Decode hex payload, filter to the window fixed at cursor, and retain the first copy."""
    raise NotImplementedError('accept')
