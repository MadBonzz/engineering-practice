def drain(pending, cursor):
    """Return [emittedHex, nextCursor, remainingDict], removing consecutive bytes from cursor up to the first gap. Preserve the input dict."""
    raise NotImplementedError('drain')
