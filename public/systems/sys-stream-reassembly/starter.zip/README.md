# Reassemble an out-of-order byte stream

A file transfer delivers some bytes twice, some in the wrong order, and its end marker before a gap is filled. Implement the receive buffer that reconstructs exactly the byte sequence an application can read after each delivery.

## Implementation scope

This laboratory isolates stream reassembly after converting transport sequence numbers to absolute offsets. It uses an eagerly reading application, a bounded byte window, and an explicit reliable end-of-stream announcement. Handshaking, congestion control, wire-level FIN acknowledgment, and sequence-number wraparound belong to other transport layers.

## Input

capacity is a positive receive window in bytes. segments is an arrival-ordered list of [offset, hexData, end]. Offsets count bytes starting at zero; hexData has two hex digits per byte. A true end announces that the exclusive stream length is offset plus payload length. Empty payloads are valid.

## Output

Return emitted, a list of lowercase hex strings (one per arrival, empty when the gap stays open); next, the first undelivered byte offset; pending, sorted maximal half-open ranges [start,end) of retained bytes; and closed, true exactly when the announced length equals next.

## Constraints

Freeze the receive window [next,next+capacity) at the start of each arrival. Insert only bytes in it. Previously retained bytes win conflicting overlaps. Then emit and discard the longest contiguous prefix starting at next; future bytes clipped out must be retransmitted. Remember an end announcement even if some payload lies outside the window. End announcements agree; no segment extends beyond the final length. At most 256 segments with 4,096 bytes each.

## Example 1

Input

~~~json
{
  "capacity": 5,
  "segments": [
    [
      2,
      "4344",
      true
    ],
    [
      1,
      "62",
      false
    ],
    [
      0,
      "414243",
      false
    ]
  ]
}
~~~

Output

~~~json
{
  "emitted": [
    "",
    "",
    "41624344"
  ],
  "next": 4,
  "pending": [],
  "closed": true
}
~~~

CD arrives at offsets 2 and 3 with the end marker. Lowercase b fills offset 1. The final ABC supplies offset 0, while b and C already occupy the overlapping positions.

## Example 2

Input

~~~json
{
  "capacity": 3,
  "segments": [
    [
      2,
      "00ff",
      true
    ],
    [
      0,
      "abcd",
      false
    ],
    [
      0,
      "abcd",
      false
    ],
    [
      3,
      "ff",
      false
    ]
  ]
}
~~~

Output

~~~json
{
  "emitted": [
    "",
    "abcd00",
    "",
    "ff"
  ],
  "next": 4,
  "pending": [],
  "closed": true
}
~~~

The initial window [0,3) retains only byte 00 at offset 2 but records length 4. Filling the gap delivers three bytes. Duplicates before next are ignored; retransmitting ff at offset 3 closes the stream.

## Part 1 · Clip payloads to the receive window

Merge arbitrary binary segments at their byte offsets and preserve the earliest accepted value at each offset.

window.py · accept(pending, cursor, capacity, offset, payload) — Return an updated offset-to-byte dict. Keys are decimal offset strings; values are byte integers. Decode hex payload, filter to the window fixed at cursor, and retain the first copy.

## Part 2 · Deliver only a gap-free prefix

Remove contiguous bytes starting at the cursor. Leave every byte beyond the first gap available for a later packet.

delivery.py · drain(pending, cursor) — Return [emittedHex, nextCursor, remainingDict], removing consecutive bytes from cursor up to the first gap. Preserve the input dict.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [RFC 9293 · Transmission Control Protocol, segment processing and receive sequence space](https://www.rfc-editor.org/rfc/rfc9293)
