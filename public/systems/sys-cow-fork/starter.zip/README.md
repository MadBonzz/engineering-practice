# Implement copy-on-write fork and page faults

A worker forks immediately before reading a shared dataset. Eager copying doubles memory use, but sharing a writable page lets the child corrupt its parent. Finish the page-table clone and write-fault paths, then replay forks, writes, and exits against a reference-counted physical allocator.

## Implementation scope

A userspace simulator represents one integer per page. The supplied allocator, page-table trace driver, and read/exit paths stand in for kernel machinery. The lab models mapping permissions, allocation, and reclamation without emulating a CPU or TLB.

## Input

pages lists [virtualPage, initialValue, permission] for process init. Each distinct virtualPage is a string. Permission is W or R. ops contains [fork,parent,child], [write,pid,page,value], [read,pid,page], or [exit,pid] in execution order.

## Output

Return events (only read and write outcomes, in order), mappings (each surviving pid maps page names to [frameID, permission]), and frames (live frame IDs as string keys, each mapped to [value, referenceCount]). Reads emit [read,value]. Writes emit [write,ok], [write,copy], [write,upgrade], or [write,protection].

## Constraints

Frame IDs are integers allocated from zero in input order and never reused. W is writable/private, C is shared-by-fork copy-on-write, R is permanently read-only. A denied write leaves the process alive. Every read/write names a mapped page, every process exists, and fork creates a fresh PID. Exit frees a frame only after the last reference disappears.

## Example 1

Input

~~~json
{
  "pages": [
    [
      "p",
      7,
      "W"
    ]
  ],
  "ops": [
    [
      "fork",
      "init",
      "a"
    ],
    [
      "write",
      "a",
      "p",
      9
    ],
    [
      "read",
      "init",
      "p"
    ],
    [
      "exit",
      "a"
    ],
    [
      "write",
      "init",
      "p",
      5
    ]
  ]
}
~~~

Output

~~~json
{
  "events": [
    [
      "write",
      "copy"
    ],
    [
      "read",
      7
    ],
    [
      "write",
      "upgrade"
    ]
  ],
  "mappings": {
    "init": {
      "p": [
        0,
        "W"
      ]
    }
  },
  "frames": {
    "0": [
      5,
      1
    ]
  }
}
~~~

The child's write creates frame 1. The parent still reads 7 from frame 0. Exiting the child frees frame 1; the parent can now write in place.

## Example 2

Input

~~~json
{
  "pages": [
    [
      "code",
      42,
      "R"
    ]
  ],
  "ops": [
    [
      "fork",
      "init",
      "b"
    ],
    [
      "write",
      "b",
      "code",
      0
    ],
    [
      "exit",
      "init"
    ],
    [
      "read",
      "b",
      "code"
    ]
  ]
}
~~~

Output

~~~json
{
  "events": [
    [
      "write",
      "protection"
    ],
    [
      "read",
      42
    ]
  ],
  "mappings": {
    "b": {
      "code": [
        0,
        "R"
      ]
    }
  },
  "frames": {
    "0": [
      42,
      1
    ]
  }
}
~~~

Fork shares the code page as R. A denied write changes no bytes, and the remaining child keeps frame 0 alive after its parent exits.

## Part 1 · Share frames during fork

Mark parent and child mappings appropriately, build independently editable entries, and update physical reference counts.

vm_fork.py · clone_table(parent, memory) — Return a distinct child page table. Change writable mappings in both tables to C, retain R/C permissions, and add one frame reference per new mapping.

## Part 2 · Handle writes without leaking frames

Distinguish true protection faults from COW. Allocate only when another mapping still owns the frame.

vm_fault.py · store(table, memory, page, value) — Mutate this mapping and the allocator. Return protection for R, ok for W, upgrade for sole-owner C, and copy for multi-owner C. After a successful write the mapping is W.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the request.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [MIT 6.1810 · Copy-on-write fork for xv6](https://pdos.csail.mit.edu/6.1810/2024/labs/cow.html)
