import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_protect_both_mapping_kinds(self):
        args = [{'text': [1, 'R'], 'x': [0, 'W']},
 {'frames': {'0': [9, 1], '1': [4, 1]}, 'next': 2}]
        expected = {'text': [1, 'R'], 'x': [0, 'C']}
        actual = trial('vm_fork.clone_table', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_sole_reference_upgrades_in_place(self):
        args = [{'x': [0, 'C']}, {'frames': {'0': [6, 1]}, 'next': 1}, 'x', 13]
        expected = 'upgrade'
        actual = trial('vm_fault.store', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

