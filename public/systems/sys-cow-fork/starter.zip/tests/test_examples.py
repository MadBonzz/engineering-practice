import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'ops': [['fork', 'init', 'a'],
         ['write', 'a', 'p', 9],
         ['read', 'init', 'p'],
         ['exit', 'a'],
         ['write', 'init', 'p', 5]],
 'pages': [['p', 7, 'W']]}
        expected = {'events': [['write', 'copy'], ['read', 7], ['write', 'upgrade']],
 'frames': {'0': [5, 1]},
 'mappings': {'init': {'p': [0, 'W']}}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'ops': [['fork', 'init', 'b'],
         ['write', 'b', 'code', 0],
         ['exit', 'init'],
         ['read', 'b', 'code']],
 'pages': [['code', 42, 'R']]}
        expected = {'events': [['write', 'protection'], ['read', 42]],
 'frames': {'0': [42, 1]},
 'mappings': {'b': {'code': [0, 'R']}}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
