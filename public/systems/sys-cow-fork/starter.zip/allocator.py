'''Physical frame allocator. Tables use string keys so traces round-trip through JSON.'''
def alloc(memory, value):
    frame = memory["next"]
    memory["next"] += 1
    memory["frames"][str(frame)] = [value, 1]
    return frame

def release(memory, frame):
    key = str(frame)
    memory["frames"][key][1] -= 1
    if memory["frames"][key][1] == 0:
        del memory["frames"][key]
