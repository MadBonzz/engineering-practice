from allocator import alloc, release

def store(table, memory, page, value):
    """Mutate this mapping and the allocator. Return protection for R, ok for W, upgrade for sole-owner C, and copy for multi-owner C. After a successful write the mapping is W."""
    raise NotImplementedError('store')
