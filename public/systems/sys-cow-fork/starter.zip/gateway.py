'''Replay process operations and expose the final physical and virtual memory.'''
from allocator import alloc, release
from vm_fork import clone_table
from vm_fault import store

def handle(request):
    memory = {"next": 0, "frames": {}}
    processes = {"init": {}}
    for page, value, permission in request["pages"]:
        processes["init"][page] = [alloc(memory,value), permission]
    events = []
    for op, pid, *args in request["ops"]:
        space = processes[pid]
        if op == "fork":
            processes[args[0]] = clone_table(space, memory)
        elif op == "write":
            events.append(["write", store(space,memory,*args)])
        elif op == "read":
            frame = space[args[0]][0]
            events.append(["read", memory["frames"][str(frame)][0]])
        elif op == "exit":
            for frame, _ in space.values():
                release(memory,frame)
            del processes[pid]
    return {"events": events, "mappings": processes, "frames": memory["frames"]}
