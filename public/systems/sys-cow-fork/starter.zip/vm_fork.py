def clone_table(parent, memory):
    """Return a distinct child page table. Change writable mappings in both tables to C, retain R/C permissions, and add one frame reference per new mapping."""
    raise NotImplementedError('clone_table')
