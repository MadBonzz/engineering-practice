"""JSON request boundary. Trace this caller before editing the implementation modules."""
from landscape_study import landscape_study


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return landscape_study(**request)
