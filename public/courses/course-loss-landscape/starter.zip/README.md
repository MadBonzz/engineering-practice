# Investigate curvature, momentum and learning-rate stability

A researcher needs a controlled test bed to distinguish curvature effects from stochasticity and optimizer state. Implement a replayable quadratic experiment runner.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

A symmetric Hessian, linear term, initial point, optimizer recipes and deterministic noise.

## Output

Full trajectories, noiseless losses and the best final recipe.

## Constraints

All dimensions agree; learning-rate and noise sequences have equal lengths. Negative-curvature directions are allowed; all outputs remain finite.

## Example 1

Input

~~~json
{
  "point": [
    1,
    1
  ],
  "hessian": [
    [
      1,
      0
    ],
    [
      0,
      4
    ]
  ],
  "linear": [
    0,
    0
  ],
  "recipes": [
    {
      "name": "small",
      "rates": [
        0.1,
        0.1,
        0.1
      ],
      "momentum": 0,
      "decay": 0
    },
    {
      "name": "large",
      "rates": [
        0.6,
        0.6,
        0.6
      ],
      "momentum": 0,
      "decay": 0
    }
  ],
  "noises": [
    [
      0,
      0
    ],
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "runs": {
    "small": {
      "points": [
        [
          1,
          1
        ],
        [
          0.9,
          0.6
        ],
        [
          0.81,
          0.36
        ],
        [
          0.7290000000000001,
          0.216
        ]
      ],
      "losses": [
        2.5,
        1.125,
        0.58725,
        0.3590325000000001
      ]
    },
    "large": {
      "points": [
        [
          1,
          1
        ],
        [
          0.4,
          -1.4
        ],
        [
          0.16000000000000003,
          1.96
        ],
        [
          0.06400000000000002,
          -2.7439999999999998
        ]
      ],
      "losses": [
        2.5,
        3.9999999999999996,
        7.696,
        15.061119999999997
      ]
    }
  },
  "best": "small"
}
~~~

A step safe for one direction can be unstable for a sharper direction.

## Example 2

Input

~~~json
{
  "point": [
    1,
    1
  ],
  "hessian": [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  "linear": [
    0,
    0
  ],
  "recipes": [
    {
      "name": "small",
      "rates": [
        0.1,
        0.1,
        0.1
      ],
      "momentum": 0,
      "decay": 0
    },
    {
      "name": "large",
      "rates": [
        0.6,
        0.6,
        0.6
      ],
      "momentum": 0,
      "decay": 0
    }
  ],
  "noises": [
    [
      0,
      0
    ],
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "runs": {
    "small": {
      "points": [
        [
          1,
          1
        ],
        [
          0.9,
          0.9
        ],
        [
          0.81,
          0.81
        ],
        [
          0.7290000000000001,
          0.7290000000000001
        ]
      ],
      "losses": [
        1.0,
        0.81,
        0.6561000000000001,
        0.5314410000000002
      ]
    },
    "large": {
      "points": [
        [
          1,
          1
        ],
        [
          0.4,
          0.4
        ],
        [
          0.16000000000000003,
          0.16000000000000003
        ],
        [
          0.06400000000000002,
          0.06400000000000002
        ]
      ],
      "losses": [
        1.0,
        0.16000000000000003,
        0.02560000000000001,
        0.0040960000000000015
      ]
    }
  },
  "best": "large"
}
~~~

Changing only curvature changes the stability comparison.

## Part 1 · Measure a local loss landscape

Return loss=0.5*x^T H x+b^T x and gradient=Hx+b for a symmetric square H. H may be indefinite. Shapes agree and dimension>=1.

quadratic_state.py · quadratic_state(point, hessian, linear) — Return loss=0.5*x^T H x+b^T x and gradient=Hx+b for a symmetric square H. H may be indefinite. Shapes agree and dimension>=1.

## Part 2 · Replay controlled trajectories

For each learning rate eta and supplied additive gradient-noise vector: v=momentum*v+gradient+noise; x=(1-eta*decay)*x-eta*v. Start v=0. Return points and exact noiseless losses INCLUDING the initial state. No bias correction or (1-momentum) scaling. 0<=momentum<1, eta/decay>=0.

momentum_path.py · momentum_path(point, hessian, linear, rates, noises, momentum, decay) — For each learning rate eta and supplied additive gradient-noise vector: v=momentum*v+gradient+noise; x=(1-eta*decay)*x-eta*v. Start v=0. Return points and exact noiseless losses INCLUDING the initial state. No bias correction or (1-momentum) scaling. 0<=momentum<1, eta/decay>=0.

## Part 3 · Compare fixed-horizon interventions

Run each {name,rates,momentum,decay} from the SAME initial point and supplied noises. Return runs mapping names to paths, and best by final noiseless loss then lexical name; no recipes gives best=null. Noise/rate lengths agree for every recipe. This finite-horizon toy model need not behave like a trained neural network.

landscape_study.py · landscape_study(point, hessian, linear, recipes, noises) — Run each {name,rates,momentum,decay} from the SAME initial point and supplied noises. Return runs mapping names to paths, and best by final noiseless loss then lexical name; no recipes gives best=null. Noise/rate lengths agree for every recipe. This finite-horizon toy model need not behave like a trained neural network.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Deep Learning Alchemy · assignment a2_hyperparameter_scaling](https://deep-learning-alchemy.github.io/assets/assignments/a2_hyperparameter_scaling.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-hyperparameter-scaling.html)

- [Deep Learning Alchemy · assignment a3_optimization2](https://deep-learning-alchemy.github.io/assets/assignments/a3_optimization2.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-optimization-2.html)


## Prediction and experimentation

1. Predict stability when eta crosses 2/lambda_max in the positive-definite, noise-free, zero-momentum case.
2. Introduce momentum or a saddle direction. Which parts of that prediction no longer apply?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
