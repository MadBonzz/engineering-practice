import math
import copy
import itertools
from collections import Counter


def quadratic_state(point, hessian, linear):
    """Return loss=0.5*x^T H x+b^T x and gradient=Hx+b for a symmetric square H. H may be indefinite. Shapes agree and dimension>=1."""
    raise NotImplementedError('quadratic_state')
