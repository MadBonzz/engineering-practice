import math
import copy
import itertools
from collections import Counter
from quadratic_state import quadratic_state
from momentum_path import momentum_path

def landscape_study(point, hessian, linear, recipes, noises):
    """Run each {name,rates,momentum,decay} from the SAME initial point and supplied noises. Return runs mapping names to paths, and best by final noiseless loss then lexical name; no recipes gives best=null. Noise/rate lengths agree for every recipe. This finite-horizon toy model need not behave like a trained neural network."""
    raise NotImplementedError('landscape_study')
