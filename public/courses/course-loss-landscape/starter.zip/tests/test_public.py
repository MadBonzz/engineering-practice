import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_anisotropic_bowl(self):
        args = [[1, 2], [[1, 0], [0, 2]], [0, 0]]
        expected = {'gradient': [1, 4], 'loss': 4.5}
        actual = trial('quadratic_state.quadratic_state', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_linear_term(self):
        args = [[0], [[2]], [3]]
        expected = {'gradient': [3], 'loss': 0.0}
        actual = trial('quadratic_state.quadratic_state', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_one_exact_step(self):
        args = [[1], [[2]], [0], [0.5], [[0]], 0, 0]
        expected = {'losses': [1.0, 0.0], 'points': [[1], [0.0]]}
        actual = trial('momentum_path.momentum_path', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_initial_measurement(self):
        args = [[1], [[2]], [0], [], [], 0, 0]
        expected = {'losses': [1.0], 'points': [[1]]}
        actual = trial('momentum_path.momentum_path', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_stability_comparison(self):
        args = [[1, 1],
 [[1, 0], [0, 4]],
 [0, 0],
 [{'decay': 0, 'momentum': 0, 'name': 'small', 'rates': [0.1, 0.1, 0.1]},
  {'decay': 0, 'momentum': 0, 'name': 'large', 'rates': [0.6, 0.6, 0.6]}],
 [[0, 0], [0, 0], [0, 0]]]
        expected = {'best': 'small',
 'runs': {'large': {'losses': [2.5, 3.9999999999999996, 7.696, 15.061119999999997],
                    'points': [[1, 1],
                               [0.4, -1.4],
                               [0.16000000000000003, 1.96],
                               [0.06400000000000002, -2.7439999999999998]]},
          'small': {'losses': [2.5, 1.125, 0.58725, 0.3590325000000001],
                    'points': [[1, 1],
                               [0.9, 0.6],
                               [0.81, 0.36],
                               [0.7290000000000001, 0.216]]}}}
        actual = trial('landscape_study.landscape_study', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_recipes(self):
        args = [[1], [[1]], [0], [], []]
        expected = {'best': None, 'runs': {}}
        actual = trial('landscape_study.landscape_study', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

