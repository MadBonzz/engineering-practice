import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'hessian': [[1, 0], [0, 4]],
 'linear': [0, 0],
 'noises': [[0, 0], [0, 0], [0, 0]],
 'point': [1, 1],
 'recipes': [{'decay': 0,
              'momentum': 0,
              'name': 'small',
              'rates': [0.1, 0.1, 0.1]},
             {'decay': 0,
              'momentum': 0,
              'name': 'large',
              'rates': [0.6, 0.6, 0.6]}]}
        expected = {'best': 'small',
 'runs': {'large': {'losses': [2.5,
                               3.9999999999999996,
                               7.696,
                               15.061119999999997],
                    'points': [[1, 1],
                               [0.4, -1.4],
                               [0.16000000000000003, 1.96],
                               [0.06400000000000002,
                                -2.7439999999999998]]},
          'small': {'losses': [2.5, 1.125, 0.58725, 0.3590325000000001],
                    'points': [[1, 1],
                               [0.9, 0.6],
                               [0.81, 0.36],
                               [0.7290000000000001, 0.216]]}}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'hessian': [[1, 0], [0, 1]],
 'linear': [0, 0],
 'noises': [[0, 0], [0, 0], [0, 0]],
 'point': [1, 1],
 'recipes': [{'decay': 0,
              'momentum': 0,
              'name': 'small',
              'rates': [0.1, 0.1, 0.1]},
             {'decay': 0,
              'momentum': 0,
              'name': 'large',
              'rates': [0.6, 0.6, 0.6]}]}
        expected = {'best': 'large',
 'runs': {'large': {'losses': [1.0,
                               0.16000000000000003,
                               0.02560000000000001,
                               0.0040960000000000015],
                    'points': [[1, 1],
                               [0.4, 0.4],
                               [0.16000000000000003, 0.16000000000000003],
                               [0.06400000000000002,
                                0.06400000000000002]]},
          'small': {'losses': [1.0,
                               0.81,
                               0.6561000000000001,
                               0.5314410000000002],
                    'points': [[1, 1],
                               [0.9, 0.9],
                               [0.81, 0.81],
                               [0.7290000000000001, 0.7290000000000001]]}}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
