import math
import copy
import itertools
from collections import Counter
from quadratic_state import quadratic_state

def momentum_path(point, hessian, linear, rates, noises, momentum, decay):
    """For each learning rate eta and supplied additive gradient-noise vector: v=momentum*v+gradient+noise; x=(1-eta*decay)*x-eta*v. Start v=0. Return points and exact noiseless losses INCLUDING the initial state. No bias correction or (1-momentum) scaling. 0<=momentum<1, eta/decay>=0."""
    raise NotImplementedError('momentum_path')
