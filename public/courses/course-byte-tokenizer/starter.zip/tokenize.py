import math
import copy
import itertools
from collections import Counter
from merge_pair import merge_pair
from learn_merges import learn_merges

def tokenize(documents, texts, budget):
    """Train merges on documents, apply them to each text in learned order, and decode through the learned byte vocabulary. Return merges, encoded token lists, decoded strings. Unseen Unicode must round-trip; text boundaries cannot merge. No normalization or special-token interpretation."""
    raise NotImplementedError('tokenize')
