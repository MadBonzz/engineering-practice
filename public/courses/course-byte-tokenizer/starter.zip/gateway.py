"""JSON request boundary. Trace this caller before editing the implementation modules."""
from tokenize import tokenize


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return tokenize(**request)
