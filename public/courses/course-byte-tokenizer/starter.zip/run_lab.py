"""Read one JSON problem input from a file or stdin and write the response."""
import json
import sys
from gateway import handle


def main():
    if len(sys.argv) == 2:
        with open(sys.argv[1], encoding="utf-8") as stream:
            request = json.load(stream)
    else:
        request = json.load(sys.stdin)
    print(json.dumps(handle(request), indent=2, ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
