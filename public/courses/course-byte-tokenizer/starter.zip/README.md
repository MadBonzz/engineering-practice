# Build a reversible byte-pair tokenizer

An ingestion service needs a tokenizer that can be trained on small shards and reproduce token IDs exactly. Implement merge training and lossless text transport.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Training documents, texts to encode, and a nonnegative merge budget.

## Output

Merge ranks, encoded sequences and reconstructed strings.

## Constraints

Each document is one pretokenized segment; no GPT-style regex, special-token policy or vocabulary pruning. Ties choose the smallest ID pair. Inputs are unchanged.

## Example 1

Input

~~~json
{
  "documents": [
    "abab",
    "ab"
  ],
  "texts": [
    "abab",
    "cab",
    ""
  ],
  "budget": 2
}
~~~

Output

~~~json
{
  "merges": [
    [
      97,
      98,
      256
    ],
    [
      256,
      256,
      257
    ]
  ],
  "encoded": [
    [
      257
    ],
    [
      99,
      256
    ],
    []
  ],
  "decoded": [
    "abab",
    "cab",
    ""
  ]
}
~~~

A frequent pair is merged before a pair of merged tokens.

## Example 2

Input

~~~json
{
  "documents": [],
  "texts": [
    "\u00e9",
    "\ud83d\ude42",
    ""
  ],
  "budget": 0
}
~~~

Output

~~~json
{
  "merges": [],
  "encoded": [
    [
      195,
      169
    ],
    [
      240,
      159,
      153,
      130
    ],
    []
  ],
  "decoded": [
    "\u00e9",
    "\ud83d\ude42",
    ""
  ]
}
~~~

The byte vocabulary handles unseen Unicode.

## Part 1 · Apply one ranked merge

Replace non-overlapping adjacent occurrences of pair by new_id, scanning left to right. Return a new token list; overlapping matches are not both consumed.

merge_pair.py · merge_pair(tokens, pair, new_id) — Replace non-overlapping adjacent occurrences of pair by new_id, scanning left to right. Return a new token list; overlapping matches are not both consumed.

## Part 2 · Train deterministic merge ranks

UTF-8 encode each document separately (initial IDs 0..255). Repeat up to budget times: count adjacent pairs across documents, choose highest frequency then lexicographically smallest pair of IDs, assign new ID 256+step and replace that pair in every document. Stop when no pair remains. Return [left,right,new_id] merges. Never merge across documents; empty documents allowed. This is byte-level BPE without regex pretokenization or special tokens.

learn_merges.py · learn_merges(documents, budget) — UTF-8 encode each document separately (initial IDs 0..255). Repeat up to budget times: count adjacent pairs across documents, choose highest frequency then lexicographically smallest pair of IDs, assign new ID 256+step and replace that pair in every document. Stop when no pair remains. Return [left,right,new_id] merges. Never merge across documents; empty documents allowed. This is byte-level BPE without regex pretokenization or special tokens.

## Part 3 · Encode and decode unseen text

Train merges on documents, apply them to each text in learned order, and decode through the learned byte vocabulary. Return merges, encoded token lists, decoded strings. Unseen Unicode must round-trip; text boundaries cannot merge. No normalization or special-token interpretation.

tokenize.py · tokenize(documents, texts, budget) — Train merges on documents, apply them to each text in learned order, and decode through the learned byte vocabulary. Return merges, encoded token lists, decoded strings. Unseen Unicode must round-trip; text boundaries cannot merge. No normalization or special-token interpretation.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A1, byte-level BPE](https://github.com/stanford-cs336/assignment1-basics/blob/6191c1a18088ec6edce02bad4451e445193abb8b/cs336_spring2025_assignment1_basics.pdf)


## Prediction and experimentation

1. Predict the tokenization of a repeated byte when merge candidates overlap.
2. Train on ASCII and encode an unseen emoji. Explain why decoding remains possible.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
