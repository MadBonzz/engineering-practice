import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_overlapping_pair(self):
        args = [[1, 1, 1], [1, 1], 256]
        expected = [256, 1]
        actual = trial('merge_pair.merge_pair', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_empty_input(self):
        args = [[], [1, 2], 256]
        expected = []
        actual = trial('merge_pair.merge_pair', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_one_pair(self):
        args = [['ab'], 1]
        expected = [[97, 98, 256]]
        actual = trial('learn_merges.learn_merges', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_boundary_isolation(self):
        args = [['a', 'b'], 2]
        expected = []
        actual = trial('learn_merges.learn_merges', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_round_trip(self):
        args = [['ab'], ['ab'], 1]
        expected = {'decoded': ['ab'], 'encoded': [[256]], 'merges': [[97, 98, 256]]}
        actual = trial('tokenize.tokenize', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_unseen_utf_8(self):
        args = [[], ['é'], 0]
        expected = {'decoded': ['é'], 'encoded': [[195, 169]], 'merges': []}
        actual = trial('tokenize.tokenize', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

