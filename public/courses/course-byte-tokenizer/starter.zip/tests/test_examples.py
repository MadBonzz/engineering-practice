import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'budget': 2, 'documents': ['abab', 'ab'], 'texts': ['abab', 'cab', '']}
        expected = {'decoded': ['abab', 'cab', ''],
 'encoded': [[257], [99, 256], []],
 'merges': [[97, 98, 256], [256, 256, 257]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'budget': 0, 'documents': [], 'texts': ['é', '🙂', '']}
        expected = {'decoded': ['é', '🙂', ''],
 'encoded': [[195, 169], [240, 159, 153, 130], []],
 'merges': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
