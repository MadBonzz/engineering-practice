import math
import copy
import itertools
from collections import Counter


def merge_pair(tokens, pair, new_id):
    """Replace non-overlapping adjacent occurrences of pair by new_id, scanning left to right. Return a new token list; overlapping matches are not both consumed."""
    raise NotImplementedError('merge_pair')
