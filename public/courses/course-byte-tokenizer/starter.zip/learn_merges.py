import math
import copy
import itertools
from collections import Counter
from merge_pair import merge_pair

def learn_merges(documents, budget):
    """UTF-8 encode each document separately (initial IDs 0..255). Repeat up to budget times: count adjacent pairs across documents, choose highest frequency then lexicographically smallest pair of IDs, assign new ID 256+step and replace that pair in every document. Stop when no pair remains. Return [left,right,new_id] merges. Never merge across documents; empty documents allowed. This is byte-level BPE without regex pretokenization or special tokens."""
    raise NotImplementedError('learn_merges')
