"""Reproduce each controlled input; save JSON output for your experiment notebook."""
import copy
import json
from pathlib import Path
from gateway import handle


def main():
    requests=json.loads(Path(__file__).with_name("fixtures").joinpath("experiments.json").read_text())
    for index,request in enumerate(requests,1):
        try:
            result=handle(copy.deepcopy(request))
        except NotImplementedError as error:
            raise SystemExit("Complete the lab before running experiments: " + str(error))
        print(json.dumps({"experiment":index,"input":request,"output":result},allow_nan=False))


if __name__ == "__main__":
    main()
