import math
import copy
import itertools
from collections import Counter


def unscale_gradient(scaled, scale, limit):
    """Return {finite,gradient}. A scaled entry may be null to denote nonfinite hardware output. If any is null or abs(entry)>limit, return finite=false and gradient=null. Equality to limit is valid. Otherwise divide each entry by positive scale. This checks overflow before division."""
    raise NotImplementedError('unscale_gradient')
