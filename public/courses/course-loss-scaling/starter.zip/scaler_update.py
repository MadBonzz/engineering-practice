import math
import copy
import itertools
from collections import Counter
from unscale_gradient import unscale_gradient

def scaler_update(state, finite, interval):
    """state={scale,good}. On overflow halve scale with minimum 1 and reset good=0. On success increment good; at interval successes double scale and reset good. interval>0. Return a new state."""
    raise NotImplementedError('scaler_update')
