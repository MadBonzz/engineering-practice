# Recover training after a mixed-precision overflow

A mixed-precision worker must preserve model state when any microbatch overflows. Implement the loss-scale controller and atomic update boundary.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Master weights, unscaled gradient microbatches, scaler state and a simulated finite-range limit.

## Output

Applied/skipped decisions, master weights and final scale.

## Constraints

This models overflow control, not IEEE FP16 rounding. Supplied gradients are sums; no weight decay or Adam moments are modeled. Values are finite numbers or null.

## Example 1

Input

~~~json
{
  "weights": [
    1
  ],
  "batches": [
    [
      [
        2
      ]
    ],
    [
      [
        9
      ]
    ],
    [
      [
        2
      ]
    ]
  ],
  "state": {
    "scale": 4,
    "good": 0
  },
  "lr": 0.1,
  "limit": 16,
  "interval": 2
}
~~~

Output

~~~json
{
  "weights": [
    0.6000000000000001
  ],
  "state": {
    "scale": 2.0,
    "good": 1
  },
  "applied": [
    true,
    false,
    true
  ]
}
~~~

One overflowing step is skipped; the following step can recover.

## Example 2

Input

~~~json
{
  "weights": [
    1
  ],
  "batches": [
    [
      [
        2
      ],
      [
        null
      ]
    ]
  ],
  "state": {
    "scale": 4,
    "good": 0
  },
  "lr": 0.1,
  "limit": 16,
  "interval": 2
}
~~~

Output

~~~json
{
  "weights": [
    1
  ],
  "state": {
    "scale": 2.0,
    "good": 0
  },
  "applied": [
    false
  ]
}
~~~

A later bad microbatch invalidates the entire step.

## Part 1 · Validate scaled gradients

Return {finite,gradient}. A scaled entry may be null to denote nonfinite hardware output. If any is null or abs(entry)>limit, return finite=false and gradient=null. Equality to limit is valid. Otherwise divide each entry by positive scale. This checks overflow before division.

unscale_gradient.py · unscale_gradient(scaled, scale, limit) — Return {finite,gradient}. A scaled entry may be null to denote nonfinite hardware output. If any is null or abs(entry)>limit, return finite=false and gradient=null. Equality to limit is valid. Otherwise divide each entry by positive scale. This checks overflow before division.

## Part 2 · Maintain the scale controller

state={scale,good}. On overflow halve scale with minimum 1 and reset good=0. On success increment good; at interval successes double scale and reset good. interval>0. Return a new state.

scaler_update.py · scaler_update(state, finite, interval) — state={scale,good}. On overflow halve scale with minimum 1 and reset good=0. On success increment good; at interval successes double scale and reset good. interval>0. Return a new state.

## Part 3 · Make each optimizer step atomic

Each batch contains unscaled microbatch gradient vectors (possibly null entries). Simulate scaling each vector with the current scale; if any scaled microbatch overflows, skip the whole optimizer step. Otherwise sum the unscaled vectors and apply SGD. Always update scaler once per batch. Return weights,state,applied boolean list; skipped steps do not change weights.

precision_session.py · precision_session(weights, batches, state, lr, limit, interval) — Each batch contains unscaled microbatch gradient vectors (possibly null entries). Simulate scaling each vector with the current scale; if any scaled microbatch overflows, skip the whole optimizer step. Otherwise sum the unscaled vectors and apply SGD. Always update scaler once per batch. Return weights,state,applied boolean list; skipped steps do not change weights.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A2, mixed precision](https://github.com/stanford-cs336/assignment2-systems/blob/e495ed740080661ab084914674d3e10048778889/cs336_spring2025_assignment2_systems.pdf)

- [DL Systems · large-model training](https://dlsyscourse.org/lectures/)


## Prediction and experimentation

1. Predict the effect of an overflow in the final microbatch.
2. Keep gradients fixed and vary the initial scale. Does a larger scale always apply more updates?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
