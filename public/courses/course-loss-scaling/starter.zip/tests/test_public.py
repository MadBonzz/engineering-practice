import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_finite_boundary(self):
        args = [[8, -4], 4, 8]
        expected = {'finite': True, 'gradient': [2.0, -1.0]}
        actual = trial('unscale_gradient.unscale_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_nonfinite_marker(self):
        args = [[None, 1], 4, 8]
        expected = {'finite': False, 'gradient': None}
        actual = trial('unscale_gradient.unscale_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_successful_step(self):
        args = [{'good': 0, 'scale': 4}, True, 2]
        expected = {'good': 1, 'scale': 4}
        actual = trial('scaler_update.scaler_update', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_growth(self):
        args = [{'good': 1, 'scale': 4}, True, 2]
        expected = {'good': 0, 'scale': 8}
        actual = trial('scaler_update.scaler_update', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_recover_after_overflow(self):
        args = [[1], [[[2]], [[9]], [[2]]], {'good': 0, 'scale': 4}, 0.1, 16, 2]
        expected = {'applied': [True, False, True],
 'state': {'good': 1, 'scale': 2.0},
 'weights': [0.6000000000000001]}
        actual = trial('precision_session.precision_session', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_steps(self):
        args = [[1], [], {'good': 0, 'scale': 4}, 0.1, 16, 2]
        expected = {'applied': [], 'state': {'good': 0, 'scale': 4}, 'weights': [1]}
        actual = trial('precision_session.precision_session', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

