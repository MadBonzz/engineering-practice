import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'batches': [[[2]], [[9]], [[2]]],
 'interval': 2,
 'limit': 16,
 'lr': 0.1,
 'state': {'good': 0, 'scale': 4},
 'weights': [1]}
        expected = {'applied': [True, False, True],
 'state': {'good': 1, 'scale': 2.0},
 'weights': [0.6000000000000001]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'batches': [[[2], [None]]],
 'interval': 2,
 'limit': 16,
 'lr': 0.1,
 'state': {'good': 0, 'scale': 4},
 'weights': [1]}
        expected = {'applied': [False], 'state': {'good': 0, 'scale': 2.0}, 'weights': [1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
