"""JSON request boundary. Trace this caller before editing the implementation modules."""
from precision_session import precision_session


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return precision_session(**request)
