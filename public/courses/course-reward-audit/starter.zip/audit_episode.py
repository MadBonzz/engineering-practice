import math
import copy
import itertools
from collections import Counter
from discounted_returns import discounted_returns

def audit_episode(events, gamma, time_penalty, coin_reward, goal_reward, repeat_coins):
    """Events are 'move', 'coin:<id>', or 'goal'. Stop at FIRST goal; ignore later events. Each processed event pays -time_penalty, plus coin_reward on the first visit to a coin (or every visit if repeat_coins), or goal_reward at goal. Return proxy_return (discounted from start), true_success (0/1), steps, unique_coins and returns. A time penalty also applies at the goal. No implicit terminal bonus without a goal."""
    raise NotImplementedError('audit_episode')
