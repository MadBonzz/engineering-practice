"""JSON request boundary. Trace this caller before editing the implementation modules."""
from reward_audit import reward_audit


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return reward_audit(**request)
