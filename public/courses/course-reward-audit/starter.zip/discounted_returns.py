import math
import copy
import itertools
from collections import Counter


def discounted_returns(rewards, gamma):
    """Return reward-to-go per step, G[t]=r[t]+gamma*G[t+1], terminal G[T]=0. 0<=gamma<=1. Empty episodes return []."""
    raise NotImplementedError('discounted_returns')
