# Detect a reward specification that favors the wrong behavior

A policy evaluation dashboard reports better reward while actual task completion falls. Build a replay audit that exposes a repeatable-reward loophole.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Named policies with fixed event traces and an explicit reward/discount configuration.

## Output

Proxy scores, true success rates, selected policy and objective mismatch.

## Constraints

Allowed events are documented; IDs are nonempty strings. The exercise audits observations and incentives, not learned policies or causal effects of retraining.

## Example 1

Input

~~~json
{
  "policies": {
    "finish": [
      [
        "move",
        "goal"
      ]
    ],
    "farm": [
      [
        "coin:a",
        "coin:a",
        "coin:a",
        "coin:a"
      ]
    ]
  },
  "gamma": 1,
  "time_penalty": 0,
  "coin_reward": 1,
  "goal_reward": 3,
  "repeat_coins": true
}
~~~

Output

~~~json
{
  "policies": {
    "finish": {
      "proxy": 3.0,
      "success_rate": 1.0
    },
    "farm": {
      "proxy": 4.0,
      "success_rate": 0.0
    }
  },
  "selected": "farm",
  "mismatch": true
}
~~~

The proxy winner can fail the actual task.

## Example 2

Input

~~~json
{
  "policies": {
    "finish": [
      [
        "move",
        "goal"
      ]
    ],
    "farm": [
      [
        "coin:a",
        "coin:a",
        "coin:a",
        "coin:a"
      ]
    ]
  },
  "gamma": 1,
  "time_penalty": 0,
  "coin_reward": 1,
  "goal_reward": 3,
  "repeat_coins": false
}
~~~

Output

~~~json
{
  "policies": {
    "finish": {
      "proxy": 3.0,
      "success_rate": 1.0
    },
    "farm": {
      "proxy": 1.0,
      "success_rate": 0.0
    }
  },
  "selected": "finish",
  "mismatch": false
}
~~~

A one-time pickup rule changes the incentive on the same traces.

## Part 1 · Compute episodic credit

Return reward-to-go per step, G[t]=r[t]+gamma*G[t+1], terminal G[T]=0. 0<=gamma<=1. Empty episodes return [].

discounted_returns.py · discounted_returns(rewards, gamma) — Return reward-to-go per step, G[t]=r[t]+gamma*G[t+1], terminal G[T]=0. 0<=gamma<=1. Empty episodes return [].

## Part 2 · Replay the reward contract

Events are 'move', 'coin:<id>', or 'goal'. Stop at FIRST goal; ignore later events. Each processed event pays -time_penalty, plus coin_reward on the first visit to a coin (or every visit if repeat_coins), or goal_reward at goal. Return proxy_return (discounted from start), true_success (0/1), steps, unique_coins and returns. A time penalty also applies at the goal. No implicit terminal bonus without a goal.

audit_episode.py · audit_episode(events, gamma, time_penalty, coin_reward, goal_reward, repeat_coins) — Events are 'move', 'coin:<id>', or 'goal'. Stop at FIRST goal; ignore later events. Each processed event pays -time_penalty, plus coin_reward on the first visit to a coin (or every visit if repeat_coins), or goal_reward at goal. Return proxy_return (discounted from start), true_success (0/1), steps, unique_coins and returns. A time penalty also applies at the goal. No implicit terminal bonus without a goal.

## Part 3 · Compare the proxy winner to task success

policies maps names to nonempty lists of event episodes. Return mean proxy reward and success_rate per policy, selected name by MAX proxy (lexical name tie), and mismatch=true iff selected success rate is below the best observed success rate. No policies gives selected=null,mismatch=false. Evaluate fixed traces; this is not RL training.

reward_audit.py · reward_audit(policies, gamma, time_penalty, coin_reward, goal_reward, repeat_coins) — policies maps names to nonempty lists of event episodes. Return mean proxy reward and success_rate per policy, selected name by MAX proxy (lexical name tie), and mismatch=true iff selected success rate is below the best observed success rate. No policies gives selected=null,mismatch=false. Evaluate fixed traces; this is not RL training.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Deep Learning Alchemy · assignment a7_exotic_rl](https://deep-learning-alchemy.github.io/assets/assignments/a7_exotic_rl.pdf)

- [CS336 2025 · alignment and reward-based learning](https://cs336.stanford.edu/spring2025/)


## Prediction and experimentation

1. Predict the proxy winner before running, then check the separate success metric.
2. Change only the repeat-pickup rule. Does a repaired trace score prove a retrained agent cannot find another loophole?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
