import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_discounted_future_rewards(self):
        args = [[1, 2, 3], 0.5]
        expected = [2.75, 3.5, 3.0]
        actual = trial('discounted_returns.discounted_returns', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_empty_episode(self):
        args = [[], 1]
        expected = []
        actual = trial('discounted_returns.discounted_returns', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_terminal_success(self):
        args = [['move', 'goal'], 1, 1, 2, 5, False]
        expected = {'proxy_return': 3.0,
 'returns': [3.0, 4.0],
 'steps': 2,
 'true_success': 1,
 'unique_coins': 0}
        actual = trial('audit_episode.audit_episode', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_single_pickup(self):
        args = [['coin:a', 'coin:a'], 1, 0, 2, 5, False]
        expected = {'proxy_return': 2.0,
 'returns': [2.0, 0.0],
 'steps': 2,
 'true_success': 0,
 'unique_coins': 1}
        actual = trial('audit_episode.audit_episode', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_proxy_mismatch(self):
        args = [{'farm': [['coin:a', 'coin:a', 'coin:a', 'coin:a']], 'finish': [['move', 'goal']]},
 1,
 0,
 1,
 3,
 True]
        expected = {'mismatch': True,
 'policies': {'farm': {'proxy': 4.0, 'success_rate': 0.0},
              'finish': {'proxy': 3.0, 'success_rate': 1.0}},
 'selected': 'farm'}
        actual = trial('reward_audit.reward_audit', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_policies(self):
        args = [{}, 1, 0, 1, 3, True]
        expected = {'mismatch': False, 'policies': {}, 'selected': None}
        actual = trial('reward_audit.reward_audit', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

