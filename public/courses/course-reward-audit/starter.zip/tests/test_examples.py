import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'coin_reward': 1,
 'gamma': 1,
 'goal_reward': 3,
 'policies': {'farm': [['coin:a', 'coin:a', 'coin:a', 'coin:a']],
              'finish': [['move', 'goal']]},
 'repeat_coins': True,
 'time_penalty': 0}
        expected = {'mismatch': True,
 'policies': {'farm': {'proxy': 4.0, 'success_rate': 0.0},
              'finish': {'proxy': 3.0, 'success_rate': 1.0}},
 'selected': 'farm'}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'coin_reward': 1,
 'gamma': 1,
 'goal_reward': 3,
 'policies': {'farm': [['coin:a', 'coin:a', 'coin:a', 'coin:a']],
              'finish': [['move', 'goal']]},
 'repeat_coins': False,
 'time_penalty': 0}
        expected = {'mismatch': False,
 'policies': {'farm': {'proxy': 1.0, 'success_rate': 0.0},
              'finish': {'proxy': 3.0, 'success_rate': 1.0}},
 'selected': 'finish'}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
