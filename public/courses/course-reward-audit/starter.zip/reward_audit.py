import math
import copy
import itertools
from collections import Counter
from discounted_returns import discounted_returns
from audit_episode import audit_episode

def reward_audit(policies, gamma, time_penalty, coin_reward, goal_reward, repeat_coins):
    """policies maps names to nonempty lists of event episodes. Return mean proxy reward and success_rate per policy, selected name by MAX proxy (lexical name tie), and mismatch=true iff selected success rate is below the best observed success rate. No policies gives selected=null,mismatch=false. Evaluate fixed traces; this is not RL training."""
    raise NotImplementedError('reward_audit')
