import math
import copy
import itertools
from collections import Counter


def shard_ranges(size, ranks):
    """Partition size parameters into contiguous nearly equal shards across positive ranks. First size%ranks ranks get one extra element. Return [start,end] for every rank, including empty shards."""
    raise NotImplementedError('shard_ranges')
