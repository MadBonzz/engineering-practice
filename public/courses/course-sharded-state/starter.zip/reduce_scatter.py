import math
import copy
import itertools
from collections import Counter
from shard_ranges import shard_ranges

def reduce_scatter(gradients, counts):
    """Each rank supplies a full gradient SUM and a positive example count. Sum across ranks and divide by total examples; then return each rank's contiguous shard. Shapes are R×P; P may be zero. Rank order is stable."""
    raise NotImplementedError('reduce_scatter')
