import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'bytes_per_element': 4,
 'counts': [1, 3],
 'gradients': [[2, 4, 6], [0, 0, 0]],
 'lr': 0.1,
 'weights': [1, 2, 3]}
        expected = {'shards': [[0.95, 1.9], [2.85]],
 'state_bytes': [32, 16],
 'weights': [0.95, 1.9, 2.85]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'bytes_per_element': 4,
 'counts': [1, 3],
 'gradients': [[2, 4, 6], [0, 0, 0]],
 'lr': 0,
 'weights': [1, 2, 3]}
        expected = {'shards': [[1.0, 2.0], [3.0]],
 'state_bytes': [32, 16],
 'weights': [1.0, 2.0, 3.0]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
