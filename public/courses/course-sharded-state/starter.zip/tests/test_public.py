import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_uneven_split(self):
        args = [5, 3]
        expected = [[0, 2], [2, 4], [4, 5]]
        actual = trial('shard_ranges.shard_ranges', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_empty_owners(self):
        args = [2, 4]
        expected = [[0, 1], [1, 2], [2, 2], [2, 2]]
        actual = trial('shard_ranges.shard_ranges', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_unequal_local_counts(self):
        args = [[[2, 4], [0, 0]], [1, 3]]
        expected = [[0.5], [1.0]]
        actual = trial('reduce_scatter.reduce_scatter', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_one_rank(self):
        args = [[[1, 2, 3]], [1]]
        expected = [[1.0, 2.0, 3.0]]
        actual = trial('reduce_scatter.reduce_scatter', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_gather_owner_updates(self):
        args = [[1, 2, 3], [[2, 4, 6], [0, 0, 0]], [1, 3], 0.1, 4]
        expected = {'shards': [[0.95, 1.9], [2.85]],
 'state_bytes': [32, 16],
 'weights': [0.95, 1.9, 2.85]}
        actual = trial('sharded_step.sharded_step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_zero_step(self):
        args = [[1], [[1], [1]], [1, 1], 0, 2]
        expected = {'shards': [[1.0], []], 'state_bytes': [8, 0], 'weights': [1.0]}
        actual = trial('sharded_step.sharded_step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

