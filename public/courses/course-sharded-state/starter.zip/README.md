# Shard optimizer ownership without changing the update

A distributed trainer is moving optimizer state off replicated workers. Implement ownership, weighted reduce-scatter and reconstruction while preserving a single-worker SGD result.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Weights, each rank’s gradient sums and counts, step size and storage element size.

## Output

Owner shards, reconstructed weights and per-rank optimizer-state bytes.

## Constraints

All ranks participate; local counts are positive. Communication is simulated deterministically, not measured. Only an SGD update is tested.

## Example 1

Input

~~~json
{
  "weights": [
    1,
    2,
    3
  ],
  "gradients": [
    [
      2,
      4,
      6
    ],
    [
      0,
      0,
      0
    ]
  ],
  "counts": [
    1,
    3
  ],
  "lr": 0.1,
  "bytes_per_element": 4
}
~~~

Output

~~~json
{
  "shards": [
    [
      0.95,
      1.9
    ],
    [
      2.85
    ]
  ],
  "weights": [
    0.95,
    1.9,
    2.85
  ],
  "state_bytes": [
    32,
    16
  ]
}
~~~

Example counts differ across ranks.

## Example 2

Input

~~~json
{
  "weights": [
    1,
    2,
    3
  ],
  "gradients": [
    [
      2,
      4,
      6
    ],
    [
      0,
      0,
      0
    ]
  ],
  "counts": [
    1,
    3
  ],
  "lr": 0,
  "bytes_per_element": 4
}
~~~

Output

~~~json
{
  "shards": [
    [
      1.0,
      2.0
    ],
    [
      3.0
    ]
  ],
  "weights": [
    1.0,
    2.0,
    3.0
  ],
  "state_bytes": [
    32,
    16
  ]
}
~~~

A zero learning rate preserves gathered parameters.

## Part 1 · Assign unique parameter ownership

Partition size parameters into contiguous nearly equal shards across positive ranks. First size%ranks ranks get one extra element. Return [start,end] for every rank, including empty shards.

shard_ranges.py · shard_ranges(size, ranks) — Partition size parameters into contiguous nearly equal shards across positive ranks. First size%ranks ranks get one extra element. Return [start,end] for every rank, including empty shards.

## Part 2 · Reduce example-weighted gradients

Each rank supplies a full gradient SUM and a positive example count. Sum across ranks and divide by total examples; then return each rank's contiguous shard. Shapes are R×P; P may be zero. Rank order is stable.

reduce_scatter.py · reduce_scatter(gradients, counts) — Each rank supplies a full gradient SUM and a positive example count. Sum across ranks and divide by total examples; then return each rank's contiguous shard. Shapes are R×P; P may be zero. Rank order is stable.

## Part 3 · Update owners and reconstruct replicas

Return shards after owner-only SGD, all-gathered weights, and state_bytes per rank. Each owner stores 4 arrays per owned parameter (master weight, gradient, first and second moment); model replicas and communication buffers excluded. No Adam update is performed. lr>=0, bytes_per_element>0.

sharded_step.py · sharded_step(weights, gradients, counts, lr, bytes_per_element) — Return shards after owner-only SGD, all-gathered weights, and state_bytes per rank. Each owner stores 4 arrays per owned parameter (master weight, gradient, first and second moment); model replicas and communication buffers excluded. No Adam update is performed. lr>=0, bytes_per_element>0.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A2, sharded optimizer state](https://github.com/stanford-cs336/assignment2-systems/blob/e495ed740080661ab084914674d3e10048778889/cs336_spring2025_assignment2_systems.pdf)

- [DL Systems · training large models](https://dlsyscourse.org/lectures/)


## Prediction and experimentation

1. Predict the failure caused by averaging rank means when rank batch sizes differ.
2. Does doubling ranks exactly halve peak owner memory for a five-parameter model?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
