import math
import copy
import itertools
from collections import Counter
from shard_ranges import shard_ranges
from reduce_scatter import reduce_scatter

def sharded_step(weights, gradients, counts, lr, bytes_per_element):
    """Return shards after owner-only SGD, all-gathered weights, and state_bytes per rank. Each owner stores 4 arrays per owned parameter (master weight, gradient, first and second moment); model replicas and communication buffers excluded. No Adam update is performed. lr>=0, bytes_per_element>0."""
    raise NotImplementedError('sharded_step')
