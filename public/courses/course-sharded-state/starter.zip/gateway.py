"""JSON request boundary. Trace this caller before editing the implementation modules."""
from sharded_step import sharded_step


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return sharded_step(**request)
