import math
import copy
import itertools
from collections import Counter
from low_rank_logits import low_rank_logits

def head_metrics(hidden, left, right, labels):
    """Return logits, mean cross-entropy and head parameter count D*R+R*V. labels are valid class IDs. Use stable log-sum-exp. Count factor parameters, not the product matrix or hidden activations."""
    raise NotImplementedError('head_metrics')
