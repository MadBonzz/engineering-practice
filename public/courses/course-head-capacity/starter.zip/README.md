# Compare factorized output heads under a parameter budget

An architecture study asks whether a smaller output head can preserve held-out likelihood. Build the factorized projection and a fixed-feature comparison tool.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Held-out hidden vectors, named factorized heads, labels and a parameter budget.

## Output

Each head’s logits/loss/parameter count and the feasible winner.

## Constraints

No training or low-rank approximation is performed here. Factor shapes agree; candidate names are unique. Comparisons apply only to the supplied features and checkpoints.

## Example 1

Input

~~~json
{
  "hidden": [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  "heads": [
    {
      "name": "rank1",
      "left": [
        [
          1
        ],
        [
          1
        ]
      ],
      "right": [
        [
          1,
          -1
        ]
      ]
    },
    {
      "name": "rank2",
      "left": [
        [
          1,
          0
        ],
        [
          0,
          1
        ]
      ],
      "right": [
        [
          1,
          -1
        ],
        [
          -1,
          1
        ]
      ]
    }
  ],
  "labels": [
    0,
    1
  ],
  "budget": 8
}
~~~

Output

~~~json
{
  "results": {
    "rank1": {
      "logits": [
        [
          1,
          -1
        ],
        [
          1,
          -1
        ]
      ],
      "loss": 1.1269280110429727,
      "parameters": 4
    },
    "rank2": {
      "logits": [
        [
          1,
          -1
        ],
        [
          -1,
          1
        ]
      ],
      "loss": 0.1269280110429727,
      "parameters": 8
    }
  },
  "best": "rank2"
}
~~~

The two factors determine both expressivity and storage.

## Example 2

Input

~~~json
{
  "hidden": [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  "heads": [
    {
      "name": "rank1",
      "left": [
        [
          1
        ],
        [
          1
        ]
      ],
      "right": [
        [
          1,
          -1
        ]
      ]
    },
    {
      "name": "rank2",
      "left": [
        [
          1,
          0
        ],
        [
          0,
          1
        ]
      ],
      "right": [
        [
          1,
          -1
        ],
        [
          -1,
          1
        ]
      ]
    }
  ],
  "labels": [
    0,
    1
  ],
  "budget": 4
}
~~~

Output

~~~json
{
  "results": {
    "rank1": {
      "logits": [
        [
          1,
          -1
        ],
        [
          1,
          -1
        ]
      ],
      "loss": 1.1269280110429727,
      "parameters": 4
    },
    "rank2": {
      "logits": [
        [
          1,
          -1
        ],
        [
          -1,
          1
        ]
      ],
      "loss": 0.1269280110429727,
      "parameters": 8
    }
  },
  "best": "rank1"
}
~~~

A tighter budget excludes one candidate.

## Part 1 · Compose the factorized projection

Compute H(LR): H is B×D, L is D×R, R is R×V; all dimensions positive. Return B×V logits without bias. This is a factorized output head, not a LoRA residual update.

low_rank_logits.py · low_rank_logits(hidden, left, right) — Compute H(LR): H is B×D, L is D×R, R is R×V; all dimensions positive. Return B×V logits without bias. This is a factorized output head, not a LoRA residual update.

## Part 2 · Measure likelihood and stored capacity

Return logits, mean cross-entropy and head parameter count D*R+R*V. labels are valid class IDs. Use stable log-sum-exp. Count factor parameters, not the product matrix or hidden activations.

head_metrics.py · head_metrics(hidden, left, right, labels) — Return logits, mean cross-entropy and head parameter count D*R+R*V. labels are valid class IDs. Use stable log-sum-exp. Count factor parameters, not the product matrix or hidden activations.

## Part 3 · Make a constrained comparison

Evaluate candidate heads {name,left,right}; return results for all, and best feasible name by validation loss then parameter count then lexical name. Feasible means parameters<=budget; no fit gives null. Hidden features and validation examples are held fixed. This compares supplied checkpoints, not retrained capacity.

capacity_report.py · capacity_report(hidden, heads, labels, budget) — Evaluate candidate heads {name,left,right}; return results for all, and best feasible name by validation loss then parameter count then lexical name. Feasible means parameters<=budget; no fit gives null. Hidden features and validation examples are held fixed. This compares supplied checkpoints, not retrained capacity.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Deep Learning Alchemy · assignment a5_capacity](https://deep-learning-alchemy.github.io/assets/assignments/a5_capacity.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-capacity.html)

- [CS336 2025 · architectures and mixture of experts](https://cs336.stanford.edu/spring2025/)


## Prediction and experimentation

1. Predict whether lower factor rank necessarily means higher validation loss for supplied, unequally trained heads.
2. Construct hidden vectors whose label distinction is lost by a rank-one projection.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
