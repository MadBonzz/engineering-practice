import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'budget': 8,
 'heads': [{'left': [[1], [1]], 'name': 'rank1', 'right': [[1, -1]]},
           {'left': [[1, 0], [0, 1]],
            'name': 'rank2',
            'right': [[1, -1], [-1, 1]]}],
 'hidden': [[1, 0], [0, 1]],
 'labels': [0, 1]}
        expected = {'best': 'rank2',
 'results': {'rank1': {'logits': [[1, -1], [1, -1]],
                       'loss': 1.1269280110429727,
                       'parameters': 4},
             'rank2': {'logits': [[1, -1], [-1, 1]],
                       'loss': 0.1269280110429727,
                       'parameters': 8}}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'budget': 4,
 'heads': [{'left': [[1], [1]], 'name': 'rank1', 'right': [[1, -1]]},
           {'left': [[1, 0], [0, 1]],
            'name': 'rank2',
            'right': [[1, -1], [-1, 1]]}],
 'hidden': [[1, 0], [0, 1]],
 'labels': [0, 1]}
        expected = {'best': 'rank1',
 'results': {'rank1': {'logits': [[1, -1], [1, -1]],
                       'loss': 1.1269280110429727,
                       'parameters': 4},
             'rank2': {'logits': [[1, -1], [-1, 1]],
                       'loss': 0.1269280110429727,
                       'parameters': 8}}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
