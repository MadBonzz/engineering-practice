import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_rank_one_projection(self):
        args = [[[1, 2]], [[1], [2]], [[3, -1]]]
        expected = [[15, -5]]
        actual = trial('low_rank_logits.low_rank_logits', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_identity_factors(self):
        args = [[[1, 2]], [[1, 0], [0, 1]], [[1, 0], [0, 1]]]
        expected = [[1, 2]]
        actual = trial('low_rank_logits.low_rank_logits', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_parameter_accounting(self):
        args = [[[0]], [[1]], [[1, 2]], [1]]
        expected = {'logits': [[0, 0]], 'loss': 0.6931471805599453, 'parameters': 3}
        actual = trial('head_metrics.head_metrics', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_one_class(self):
        args = [[[1]], [[1]], [[0]], [0]]
        expected = {'logits': [[0]], 'loss': 0.0, 'parameters': 2}
        actual = trial('head_metrics.head_metrics', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_budgeted_choice(self):
        args = [[[1, 0], [0, 1]],
 [{'left': [[1], [1]], 'name': 'rank1', 'right': [[1, -1]]},
  {'left': [[1, 0], [0, 1]], 'name': 'rank2', 'right': [[1, -1], [-1, 1]]}],
 [0, 1],
 8]
        expected = {'best': 'rank2',
 'results': {'rank1': {'logits': [[1, -1], [1, -1]],
                       'loss': 1.1269280110429727,
                       'parameters': 4},
             'rank2': {'logits': [[1, -1], [-1, 1]],
                       'loss': 0.1269280110429727,
                       'parameters': 8}}}
        actual = trial('capacity_report.capacity_report', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_feasible_head(self):
        args = [[[1, 0], [0, 1]],
 [{'left': [[1], [1]], 'name': 'rank1', 'right': [[1, -1]]},
  {'left': [[1, 0], [0, 1]], 'name': 'rank2', 'right': [[1, -1], [-1, 1]]}],
 [0, 1],
 0]
        expected = {'best': None,
 'results': {'rank1': {'logits': [[1, -1], [1, -1]],
                       'loss': 1.1269280110429727,
                       'parameters': 4},
             'rank2': {'logits': [[1, -1], [-1, 1]],
                       'loss': 0.1269280110429727,
                       'parameters': 8}}}
        actual = trial('capacity_report.capacity_report', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

