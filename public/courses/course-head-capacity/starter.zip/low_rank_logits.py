import math
import copy
import itertools
from collections import Counter


def low_rank_logits(hidden, left, right):
    """Compute H(LR): H is B×D, L is D×R, R is R×V; all dimensions positive. Return B×V logits without bias. This is a factorized output head, not a LoRA residual update."""
    raise NotImplementedError('low_rank_logits')
