import math
import copy
import itertools
from collections import Counter
from low_rank_logits import low_rank_logits
from head_metrics import head_metrics

def capacity_report(hidden, heads, labels, budget):
    """Evaluate candidate heads {name,left,right}; return results for all, and best feasible name by validation loss then parameter count then lexical name. Feasible means parameters<=budget; no fit gives null. Hidden features and validation examples are held fixed. This compares supplied checkpoints, not retrained capacity."""
    raise NotImplementedError('capacity_report')
