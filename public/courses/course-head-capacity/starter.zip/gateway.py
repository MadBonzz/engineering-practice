"""JSON request boundary. Trace this caller before editing the implementation modules."""
from capacity_report import capacity_report


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return capacity_report(**request)
