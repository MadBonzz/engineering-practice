import math
import copy
import itertools
from collections import Counter
from tile_ranges import tile_ranges

def tiled_product(a, b, tile):
    """Return A@B for nonempty rectangular M×K and K×N matrices using edge-safe tiles along all three axes. Numerical results must match dense multiplication; no padded values enter sums."""
    raise NotImplementedError('tiled_product')
