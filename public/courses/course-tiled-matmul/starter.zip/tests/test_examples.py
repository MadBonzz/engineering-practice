import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'a': [[1, 2], [3, 4]],
 'b': [[1, 0], [0, 1]],
 'bandwidth': 48,
 'bytes_per_element': 4,
 'flops_per_second': 16,
 'tile': 2}
        expected = {'bottleneck': 'balanced',
 'bytes': 48,
 'flops': 16,
 'intensity': 0.3333333333333333,
 'output': [[1.0, 2.0], [3.0, 4.0]],
 'seconds': 1.0}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'a': [[1, 2], [3, 4]],
 'b': [[1, 0], [0, 1]],
 'bandwidth': 48,
 'bytes_per_element': 4,
 'flops_per_second': 16,
 'tile': 1}
        expected = {'bottleneck': 'memory',
 'bytes': 80,
 'flops': 16,
 'intensity': 0.2,
 'output': [[1.0, 2.0], [3.0, 4.0]],
 'seconds': 1.6666666666666667}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
