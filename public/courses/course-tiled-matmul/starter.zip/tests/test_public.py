import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_partial_final_tile(self):
        args = [5, 2]
        expected = [[0, 2], [2, 4], [4, 5]]
        actual = trial('tile_ranges.tile_ranges', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_empty_partition(self):
        args = [0, 3]
        expected = []
        actual = trial('tile_ranges.tile_ranges', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_dot_product(self):
        args = [[[1, 2]], [[3], [4]], 1]
        expected = [[11.0]]
        actual = trial('tiled_product.tiled_product', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_identity(self):
        args = [[[1, 2], [3, 4]], [[1, 0], [0, 1]], 2]
        expected = [[1.0, 2.0], [3.0, 4.0]]
        actual = trial('tiled_product.tiled_product', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_balanced_roofline(self):
        args = [[[1, 2], [3, 4]], [[1, 0], [0, 1]], 2, 4, 48, 16]
        expected = {'bottleneck': 'balanced',
 'bytes': 48,
 'flops': 16,
 'intensity': 0.3333333333333333,
 'output': [[1.0, 2.0], [3.0, 4.0]],
 'seconds': 1.0}
        actual = trial('matmul_plan.matmul_plan', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_compute_bound(self):
        args = [[[2]], [[3]], 1, 4, 12, 1]
        expected = {'bottleneck': 'compute',
 'bytes': 12,
 'flops': 2,
 'intensity': 0.16666666666666666,
 'output': [[6.0]],
 'seconds': 2.0}
        actual = trial('matmul_plan.matmul_plan', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

