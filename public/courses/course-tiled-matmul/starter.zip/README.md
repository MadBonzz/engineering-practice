# Build an edge-safe tiled matrix operator

A kernel planner needs correct outputs and reproducible operation counts before hardware benchmarking. Implement tiled multiplication and a transparent traffic model.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Two compatible matrices, tile size, element byte size and positive hardware-rate assumptions.

## Output

Matrix product and analytical compute/traffic estimates.

## Constraints

Tile tails must work. Rates use bytes/second and FLOPs/second. This model excludes launch latency, cache effects, occupancy and GPU timing.

## Example 1

Input

~~~json
{
  "a": [
    [
      1,
      2
    ],
    [
      3,
      4
    ]
  ],
  "b": [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  "tile": 2,
  "bytes_per_element": 4,
  "bandwidth": 48,
  "flops_per_second": 16
}
~~~

Output

~~~json
{
  "output": [
    [
      1.0,
      2.0
    ],
    [
      3.0,
      4.0
    ]
  ],
  "flops": 16,
  "bytes": 48,
  "intensity": 0.3333333333333333,
  "seconds": 1.0,
  "bottleneck": "balanced"
}
~~~

An identity product with balanced idealized costs.

## Example 2

Input

~~~json
{
  "a": [
    [
      1,
      2
    ],
    [
      3,
      4
    ]
  ],
  "b": [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  "tile": 1,
  "bytes_per_element": 4,
  "bandwidth": 48,
  "flops_per_second": 16
}
~~~

Output

~~~json
{
  "output": [
    [
      1.0,
      2.0
    ],
    [
      3.0,
      4.0
    ]
  ],
  "flops": 16,
  "bytes": 80,
  "intensity": 0.2,
  "seconds": 1.6666666666666667,
  "bottleneck": "memory"
}
~~~

Smaller tiles reload operands more often under this model.

## Part 1 · Partition logical dimensions

Partition [0,length) into [start,end] pairs of at most tile elements. length>=0 and tile>0. End is exclusive and the final tile may be short.

tile_ranges.py · tile_ranges(length, tile) — Partition [0,length) into [start,end] pairs of at most tile elements. length>=0 and tile>0. End is exclusive and the final tile may be short.

## Part 2 · Accumulate partial products

Return A@B for nonempty rectangular M×K and K×N matrices using edge-safe tiles along all three axes. Numerical results must match dense multiplication; no padded values enter sums.

tiled_product.py · tiled_product(a, b, tile) — Return A@B for nonempty rectangular M×K and K×N matrices using edge-safe tiles along all three axes. Numerical results must match dense multiplication; no padded values enter sums.

## Part 3 · Account for movement and arithmetic

Return output, flops, bytes, intensity, seconds, bottleneck for an idealized tiled plan. For each (M,N,K) tile load its A and B once; no reuse across output tiles. Write C once after all K tiles, with no C reads. FLOPs=2*M*N*K. seconds=max(bytes/bandwidth,FLOPs/flops_per_second). Tie => 'balanced', otherwise 'memory' or 'compute'. Positive byte size and rates.

matmul_plan.py · matmul_plan(a, b, tile, bytes_per_element, bandwidth, flops_per_second) — Return output, flops, bytes, intensity, seconds, bottleneck for an idealized tiled plan. For each (M,N,K) tile load its A and B once; no reuse across output tiles. Write C once after all K tiles, with no C reads. FLOPs=2*M*N*K. seconds=max(bytes/bandwidth,FLOPs/flops_per_second). Tie => 'balanced', otherwise 'memory' or 'compute'. Positive byte size and rates.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DL Systems · hardware acceleration](https://dlsyscourse.org/slides/11-hardware-acceleration.pdf)

- [CS336 2025 · A2, benchmarking and kernels](https://github.com/stanford-cs336/assignment2-systems/blob/e495ed740080661ab084914674d3e10048778889/cs336_spring2025_assignment2_systems.pdf)

- [DL Systems · Homework 3 (original notebook)](https://github.com/dlsyscourse/hw3/blob/main/hw3.ipynb)


## Prediction and experimentation

1. Predict which traffic counts change when the tile grows.
2. Can a lower modeled time prove a real GPU speedup? List the missing measurements.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
