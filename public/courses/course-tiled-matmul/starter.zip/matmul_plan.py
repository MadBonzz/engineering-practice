import math
import copy
import itertools
from collections import Counter
from tile_ranges import tile_ranges
from tiled_product import tiled_product

def matmul_plan(a, b, tile, bytes_per_element, bandwidth, flops_per_second):
    """Return output, flops, bytes, intensity, seconds, bottleneck for an idealized tiled plan. For each (M,N,K) tile load its A and B once; no reuse across output tiles. Write C once after all K tiles, with no C reads. FLOPs=2*M*N*K. seconds=max(bytes/bandwidth,FLOPs/flops_per_second). Tie => 'balanced', otherwise 'memory' or 'compute'. Positive byte size and rates."""
    raise NotImplementedError('matmul_plan')
