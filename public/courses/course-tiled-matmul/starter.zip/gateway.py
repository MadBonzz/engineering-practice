"""JSON request boundary. Trace this caller before editing the implementation modules."""
from matmul_plan import matmul_plan


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return matmul_plan(**request)
