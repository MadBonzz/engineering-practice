import math
import copy
import itertools
from collections import Counter


def tile_ranges(length, tile):
    """Partition [0,length) into [start,end] pairs of at most tile elements. length>=0 and tile>0. End is exclusive and the final tile may be short."""
    raise NotImplementedError('tile_ranges')
