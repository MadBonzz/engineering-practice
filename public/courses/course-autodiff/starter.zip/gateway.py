"""JSON request boundary. Trace this caller before editing the implementation modules."""
from graph_report import graph_report


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return graph_report(**request)
