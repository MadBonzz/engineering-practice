import math
import copy
import itertools
from collections import Counter
from forward_graph import forward_graph

def reverse_graph(nodes, output, seed):
    """Return d(seed*nodes[output])/d(each node value), treating each node as an intermediate. Accumulate every incoming edge, including duplicate parents. Disconnected nodes have zero gradient."""
    raise NotImplementedError('reverse_graph')
