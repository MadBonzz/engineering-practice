import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_shared_square(self):
        args = [[{'op': 'input', 'value': 3},
  {'op': 'mul', 'parents': [0, 0]},
  {'op': 'add', 'parents': [1, 0]}]]
        expected = [3, 9, 12]
        actual = trial('forward_graph.forward_graph', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_disconnected_input(self):
        args = [[{'op': 'input', 'value': 0},
  {'op': 'tanh', 'parents': [0]},
  {'op': 'input', 'value': 7}]]
        expected = [0, 0.0, 7]
        actual = trial('forward_graph.forward_graph', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_branch_accumulation(self):
        args = [[{'op': 'input', 'value': 3},
  {'op': 'mul', 'parents': [0, 0]},
  {'op': 'add', 'parents': [1, 0]}],
 2,
 1]
        expected = [7.0, 1.0, 1]
        actual = trial('reverse_graph.reverse_graph', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_seed_scaling(self):
        args = [[{'op': 'input', 'value': 0},
  {'op': 'tanh', 'parents': [0]},
  {'op': 'input', 'value': 7}],
 1,
 2]
        expected = [2.0, 2, 0.0]
        actual = trial('reverse_graph.reverse_graph', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_no_roots(self):
        args = [[{'op': 'input', 'value': 3},
  {'op': 'mul', 'parents': [0, 0]},
  {'op': 'add', 'parents': [1, 0]}],
 []]
        expected = {'gradients': [0.0, 0.0, 0.0], 'values': [3, 9, 12]}
        actual = trial('graph_report.graph_report', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_one_root(self):
        args = [[{'op': 'input', 'value': 0},
  {'op': 'tanh', 'parents': [0]},
  {'op': 'input', 'value': 7}],
 [{'node': 1, 'seed': 1}]]
        expected = {'gradients': [1.0, 1.0, 0.0], 'values': [0, 0.0, 7]}
        actual = trial('graph_report.graph_report', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

