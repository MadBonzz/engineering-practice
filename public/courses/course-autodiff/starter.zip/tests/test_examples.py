import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'nodes': [{'op': 'input', 'value': 3},
           {'op': 'mul', 'parents': [0, 0]},
           {'op': 'add', 'parents': [1, 0]}],
 'outputs': [{'node': 2, 'seed': 1}]}
        expected = {'gradients': [7.0, 1.0, 1.0], 'values': [3, 9, 12]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'nodes': [{'op': 'input', 'value': 0},
           {'op': 'tanh', 'parents': [0]},
           {'op': 'input', 'value': 7}],
 'outputs': [{'node': 1, 'seed': 2}]}
        expected = {'gradients': [2.0, 2.0, 0.0], 'values': [0, 0.0, 7]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
