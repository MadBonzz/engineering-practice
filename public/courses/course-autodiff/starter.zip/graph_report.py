import math
import copy
import itertools
from collections import Counter
from forward_graph import forward_graph
from reverse_graph import reverse_graph

def graph_report(nodes, outputs):
    """Return {values, gradients}, where outputs is a list of {node,seed} and gradients is the sum of their reverse passes. Empty outputs gives all zeros; repeated roots count repeatedly."""
    raise NotImplementedError('graph_report')
