import math
import copy
import itertools
from collections import Counter


def forward_graph(nodes):
    """Evaluate a topologically ordered scalar graph. Nodes are {op:'input',value}, {op:'add'|'mul',parents:[i,j]}, or {op:'tanh',parents:[i]}; parent indices are smaller than node index. Return all values."""
    raise NotImplementedError('forward_graph')
