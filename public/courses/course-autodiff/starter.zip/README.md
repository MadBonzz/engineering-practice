# Repair a reverse-mode differentiation engine

A small differentiable simulator reuses intermediate values. Its current engine loses gradient contributions when branches meet. Complete the graph evaluator and reverse pass.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

A nonempty valid DAG and seeded output nodes.

## Output

Forward values and accumulated gradients for every node.

## Constraints

Only input, add, mul and tanh are supported; every parent precedes its child. Inputs stay unchanged.

## Example 1

Input

~~~json
{
  "nodes": [
    {
      "op": "input",
      "value": 3
    },
    {
      "op": "mul",
      "parents": [
        0,
        0
      ]
    },
    {
      "op": "add",
      "parents": [
        1,
        0
      ]
    }
  ],
  "outputs": [
    {
      "node": 2,
      "seed": 1
    }
  ]
}
~~~

Output

~~~json
{
  "values": [
    3,
    9,
    12
  ],
  "gradients": [
    7.0,
    1.0,
    1.0
  ]
}
~~~

The squared input reaches the loss along more than one edge.

## Example 2

Input

~~~json
{
  "nodes": [
    {
      "op": "input",
      "value": 0
    },
    {
      "op": "tanh",
      "parents": [
        0
      ]
    },
    {
      "op": "input",
      "value": 7
    }
  ],
  "outputs": [
    {
      "node": 1,
      "seed": 2
    }
  ]
}
~~~

Output

~~~json
{
  "values": [
    0,
    0.0,
    7
  ],
  "gradients": [
    2.0,
    2.0,
    0.0
  ]
}
~~~

A disconnected input contributes nothing.

## Part 1 · Evaluate a shared computation graph

Evaluate a topologically ordered scalar graph. Nodes are {op:'input',value}, {op:'add'|'mul',parents:[i,j]}, or {op:'tanh',parents:[i]}; parent indices are smaller than node index. Return all values.

forward_graph.py · forward_graph(nodes) — Evaluate a topologically ordered scalar graph. Nodes are {op:'input',value}, {op:'add'|'mul',parents:[i,j]}, or {op:'tanh',parents:[i]}; parent indices are smaller than node index. Return all values.

## Part 2 · Accumulate vector–Jacobian products

Return d(seed*nodes[output])/d(each node value), treating each node as an intermediate. Accumulate every incoming edge, including duplicate parents. Disconnected nodes have zero gradient.

reverse_graph.py · reverse_graph(nodes, output, seed) — Return d(seed*nodes[output])/d(each node value), treating each node as an intermediate. Accumulate every incoming edge, including duplicate parents. Disconnected nodes have zero gradient.

## Part 3 · Support multiple loss roots

Return {values, gradients}, where outputs is a list of {node,seed} and gradients is the sum of their reverse passes. Empty outputs gives all zeros; repeated roots count repeatedly.

graph_report.py · graph_report(nodes, outputs) — Return {values, gradients}, where outputs is a list of {node,seed} and gradients is the sum of their reverse passes. Empty outputs gives all zeros; repeated roots count repeatedly.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DL Systems · lectures 4–5, automatic differentiation](https://dlsyscourse.org/slides/4-automatic-differentiation.pdf)

- [DL Systems · Homework 1 (original notebook)](https://github.com/dlsyscourse/hw1/blob/main/hw1.ipynb)


## Prediction and experimentation

1. Predict the input gradient if a square uses the same input twice.
2. Add a disconnected subgraph and explain which derivatives should remain unchanged.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
