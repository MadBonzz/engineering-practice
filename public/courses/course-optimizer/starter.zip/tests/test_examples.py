import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'batches': [[{'count': 2, 'sum': [2.0]}]],
 'beta1': 0,
 'beta2': 0,
 'decay': 0.2,
 'epsilon': 1,
 'limit': 10,
 'lr': 0.1,
 'weights': [1.0]}
        expected = {'state': {'m': [1.0], 't': 1, 'v': [1.0]},
 'used_gradients': [[1.0]],
 'weights': [0.9299999999999999]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'batches': [[{'count': 1, 'sum': [2.0]}, {'count': 3, 'sum': [0.0]}]],
 'beta1': 0,
 'beta2': 0,
 'decay': 0.2,
 'epsilon': 1,
 'limit': 10,
 'lr': 0.1,
 'weights': [1.0]}
        expected = {'state': {'m': [0.5], 't': 1, 'v': [0.25]},
 'used_gradients': [[0.5]],
 'weights': [0.9466666666666667]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
