import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_global_norm(self):
        args = [[3, 4], 1]
        expected = [0.6000000000000001, 0.8]
        actual = trial('clip_gradient.clip_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_zero_vector(self):
        args = [[0, 0], 1]
        expected = [0.0, 0.0]
        actual = trial('clip_gradient.clip_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_first_step(self):
        args = [[1], [1], {'m': [0.0], 't': 0, 'v': [0.0]}, 0.1, 0.2, 0, 0, 1]
        expected = {'state': {'m': [1.0], 't': 1, 'v': [1.0]}, 'weights': [0.9299999999999999]}
        actual = trial('adam_step.adam_step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_decay_with_zero_gradient(self):
        args = [[2], [0], {'m': [0.0], 't': 0, 'v': [0.0]}, 0.1, 0.5, 0, 0, 1]
        expected = {'state': {'m': [0.0], 't': 1, 'v': [0.0]}, 'weights': [1.9]}
        actual = trial('adam_step.adam_step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_single_batch(self):
        args = [[1.0], [[{'count': 2, 'sum': [2.0]}]], 0.1, 0.2, 10, 0, 0, 1]
        expected = {'state': {'m': [1.0], 't': 1, 'v': [1.0]},
 'used_gradients': [[1.0]],
 'weights': [0.9299999999999999]}
        actual = trial('optimize.optimize', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_updates(self):
        args = [[1], [], 0.1, 0, 1, 0.9, 0.99, 1e-08]
        expected = {'state': {'m': [0.0], 't': 0, 'v': [0.0]}, 'used_gradients': [], 'weights': [1]}
        actual = trial('optimize.optimize', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

