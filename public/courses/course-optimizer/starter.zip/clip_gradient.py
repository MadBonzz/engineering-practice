import math
import copy
import itertools
from collections import Counter


def clip_gradient(gradient, limit):
    """Return a copied gradient scaled to Euclidean norm at most positive limit. A zero gradient stays zero; clip globally, not per coordinate."""
    raise NotImplementedError('clip_gradient')
