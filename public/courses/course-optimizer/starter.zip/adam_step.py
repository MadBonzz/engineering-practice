import math
import copy
import itertools
from collections import Counter
from clip_gradient import clip_gradient

def adam_step(weights, gradient, state, lr, decay, beta1, beta2, epsilon):
    """Return {weights,state} after one AdamW step. state has m,v,t (t is completed updates). Increment t; update moments; divide by 1-beta**t; apply w*(1-lr*decay)-lr*m_hat/(sqrt(v_hat)+epsilon). Inputs unchanged; beta in [0,1), epsilon>0."""
    raise NotImplementedError('adam_step')
