import math
import copy
import itertools
from collections import Counter
from clip_gradient import clip_gradient
from adam_step import adam_step

def optimize(weights, batches, lr, decay, limit, beta1, beta2, epsilon):
    """Each batch is a list of {sum: gradient_sum_vector, count: positive example_count}. Divide the sum of all vectors by total count, clip once, then perform one AdamW step. Initialize m/v/t to zero and return final weights/state and used_gradients. No batches means no update."""
    raise NotImplementedError('optimize')
