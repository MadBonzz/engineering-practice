# Resume a correct AdamW training update

A trainer must match a large batch while accumulating smaller batches, and preserve Adam state across updates. Repair the reduction, clipping and optimizer path.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Weights, gradient-sum microbatches, AdamW parameters and a global clipping limit.

## Output

Final weights, moments, update count and the clipped gradient used per update.

## Constraints

All vectors have equal positive length. Each update has at least one positive-count microbatch. Rates and decay are nonnegative.

## Example 1

Input

~~~json
{
  "weights": [
    1.0
  ],
  "batches": [
    [
      {
        "sum": [
          2.0
        ],
        "count": 2
      }
    ]
  ],
  "lr": 0.1,
  "decay": 0.2,
  "limit": 10,
  "beta1": 0,
  "beta2": 0,
  "epsilon": 1
}
~~~

Output

~~~json
{
  "weights": [
    0.9299999999999999
  ],
  "state": {
    "m": [
      1.0
    ],
    "v": [
      1.0
    ],
    "t": 1
  },
  "used_gradients": [
    [
      1.0
    ]
  ]
}
~~~

The first step includes decoupled weight decay.

## Example 2

Input

~~~json
{
  "weights": [
    1.0
  ],
  "batches": [
    [
      {
        "sum": [
          2.0
        ],
        "count": 1
      },
      {
        "sum": [
          0.0
        ],
        "count": 3
      }
    ]
  ],
  "lr": 0.1,
  "decay": 0.2,
  "limit": 10,
  "beta1": 0,
  "beta2": 0,
  "epsilon": 1
}
~~~

Output

~~~json
{
  "weights": [
    0.9466666666666667
  ],
  "state": {
    "m": [
      0.5
    ],
    "v": [
      0.25
    ],
    "t": 1
  },
  "used_gradients": [
    [
      0.5
    ]
  ]
}
~~~

Unequal microbatches are weighted by their counts.

## Part 1 · Clip a global gradient

Return a copied gradient scaled to Euclidean norm at most positive limit. A zero gradient stays zero; clip globally, not per coordinate.

clip_gradient.py · clip_gradient(gradient, limit) — Return a copied gradient scaled to Euclidean norm at most positive limit. A zero gradient stays zero; clip globally, not per coordinate.

## Part 2 · Update optimizer state

Return {weights,state} after one AdamW step. state has m,v,t (t is completed updates). Increment t; update moments; divide by 1-beta**t; apply w*(1-lr*decay)-lr*m_hat/(sqrt(v_hat)+epsilon). Inputs unchanged; beta in [0,1), epsilon>0.

adam_step.py · adam_step(weights, gradient, state, lr, decay, beta1, beta2, epsilon) — Return {weights,state} after one AdamW step. state has m,v,t (t is completed updates). Increment t; update moments; divide by 1-beta**t; apply w*(1-lr*decay)-lr*m_hat/(sqrt(v_hat)+epsilon). Inputs unchanged; beta in [0,1), epsilon>0.

## Part 3 · Combine unequal microbatches

Each batch is a list of {sum: gradient_sum_vector, count: positive example_count}. Divide the sum of all vectors by total count, clip once, then perform one AdamW step. Initialize m/v/t to zero and return final weights/state and used_gradients. No batches means no update.

optimize.py · optimize(weights, batches, lr, decay, limit, beta1, beta2, epsilon) — Each batch is a list of {sum: gradient_sum_vector, count: positive example_count}. Divide the sum of all vectors by total count, clip once, then perform one AdamW step. Initialize m/v/t to zero and return final weights/state and used_gradients. No batches means no update.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A1, AdamW and gradient clipping](https://github.com/stanford-cs336/assignment1-basics/blob/6191c1a18088ec6edce02bad4451e445193abb8b/cs336_spring2025_assignment1_basics.pdf)

- [DL Systems · optimization](https://dlsyscourse.org/lectures/)

- [DL Systems · Homework 2 (original notebook)](https://github.com/dlsyscourse/hw2/blob/main/hw2.ipynb)


## Prediction and experimentation

1. Split the same batch into unequal microbatches. Predict whether the update changes.
2. Compare zero gradient with no optimizer step. Does weight decay behave identically?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
