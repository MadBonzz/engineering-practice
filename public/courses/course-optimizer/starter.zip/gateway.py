"""JSON request boundary. Trace this caller before editing the implementation modules."""
from optimize import optimize


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return optimize(**request)
