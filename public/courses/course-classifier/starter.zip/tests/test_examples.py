import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'features': [[1]],
 'labels': [0],
 'lr': 0.2,
 'steps': 1,
 'weights': [[0, 0]]}
        expected = {'final_loss': 0.5981388693815918,
 'history': [0.6931471805599453],
 'weights': [[0.1, -0.1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'features': [[1], [-1]],
 'labels': [0, 1],
 'lr': 0.5,
 'steps': 3,
 'weights': [[0, 0]]}
        expected = {'final_loss': 0.2700164035549937,
 'history': [0.6931471805599453, 0.4740769841801067, 0.347697748169947],
 'weights': [[0.5856141703248665, -0.5856141703248665]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
