import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_equal_logits(self):
        args = [[0, 0]]
        expected = [-0.6931471805599453, -0.6931471805599453]
        actual = trial('log_probs.log_probs', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_single_class(self):
        args = [[5]]
        expected = [0.0]
        actual = trial('log_probs.log_probs', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_one_training_example(self):
        args = [[[1]], [[0, 0]], [0]]
        expected = {'gradient': [[-0.5, 0.5]], 'loss': 0.6931471805599453}
        actual = trial('classifier_gradient.classifier_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_zero_feature(self):
        args = [[[0]], [[3, -2]], [1]]
        expected = {'gradient': [[0.0, 0.0]], 'loss': 0.6931471805599453}
        actual = trial('classifier_gradient.classifier_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_frozen_learning_rate(self):
        args = [[[1]], [[0, 0]], [0], 0, 1]
        expected = {'final_loss': 0.6931471805599453,
 'history': [0.6931471805599453],
 'weights': [[0.0, 0.0]]}
        actual = trial('train_classifier.train_classifier', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_updates(self):
        args = [[[1]], [[0, 0]], [0], 0.2, 0]
        expected = {'final_loss': 0.6931471805599453, 'history': [], 'weights': [[0, 0]]}
        actual = trial('train_classifier.train_classifier', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

