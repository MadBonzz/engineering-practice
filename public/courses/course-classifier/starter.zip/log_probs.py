import math
import copy
import itertools
from collections import Counter


def log_probs(logits):
    """Return log-softmax of a nonempty finite vector. Preserve accuracy for logits near ±1000; subtracting a shared constant must not change results."""
    raise NotImplementedError('log_probs')
