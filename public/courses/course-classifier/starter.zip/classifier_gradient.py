import math
import copy
import itertools
from collections import Counter
from log_probs import log_probs

def classifier_gradient(features, weights, labels):
    """Return {loss, gradient} for mean cross-entropy: logits=XW, X is B×D, W is D×C, labels has B class IDs. B,D,C are positive. Gradient has W's shape; no bias term or regularizer."""
    raise NotImplementedError('classifier_gradient')
