# Prediction and experiment notebook

## Before running
1. Predict what a shared +1000 shift to the logits does to loss and gradients.
2. Compare lr=0.1, 1 and 5 for ten updates. Does a larger step always improve final loss?

For each comparison, write a prediction, confidence, and the mechanism you expect.

## Protocol
State the one variable changed, controls held fixed, initial state/seeds, and metric.
Implement the three parts and pass the public tests before interpreting a run.
Run `python experiment.py` locally, or use the editable JSON examples in the bench.
Edit `fixtures/experiments.json` locally to add a controlled intervention.

## Observations
Record the configuration and actual numerical result. Include failed predictions.

## Explanation and next test
Explain the discrepancy, propose a counterexample to your current explanation,
and name one limit on transferring this small experiment to a trained large model.

This notebook is saved/exported with your attempt. Coding checks grade implementation
behavior; they do not automatically assess the quality of your scientific explanation.
