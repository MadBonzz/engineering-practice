"""JSON request boundary. Trace this caller before editing the implementation modules."""
from train_classifier import train_classifier


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return train_classifier(**request)
