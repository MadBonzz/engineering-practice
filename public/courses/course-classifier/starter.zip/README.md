# Train a stable softmax classifier

A training service intermittently returns NaN and reports inconsistent gradients when batch size changes. Repair its numerical and update path.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Dense feature rows, a weight matrix, integer labels, learning rate and update count.

## Output

Model weights, pre-update losses, and final cross-entropy.

## Constraints

Valid rectangular shapes; finite inputs; no mutation. Loss is a mean across examples, never across classes.

## Example 1

Input

~~~json
{
  "features": [
    [
      1
    ]
  ],
  "weights": [
    [
      0,
      0
    ]
  ],
  "labels": [
    0
  ],
  "lr": 0.2,
  "steps": 1
}
~~~

Output

~~~json
{
  "weights": [
    [
      0.1,
      -0.1
    ]
  ],
  "history": [
    0.6931471805599453
  ],
  "final_loss": 0.5981388693815918
}
~~~

One update favors the observed label.

## Example 2

Input

~~~json
{
  "features": [
    [
      1
    ],
    [
      -1
    ]
  ],
  "weights": [
    [
      0,
      0
    ]
  ],
  "labels": [
    0,
    1
  ],
  "lr": 0.5,
  "steps": 3
}
~~~

Output

~~~json
{
  "weights": [
    [
      0.5856141703248665,
      -0.5856141703248665
    ]
  ],
  "history": [
    0.6931471805599453,
    0.4740769841801067,
    0.347697748169947
  ],
  "final_loss": 0.2700164035549937
}
~~~

Opposite inputs require opposite class evidence.

## Part 1 · Stabilize the probability boundary

Return log-softmax of a nonempty finite vector. Preserve accuracy for logits near ±1000; subtracting a shared constant must not change results.

log_probs.py · log_probs(logits) — Return log-softmax of a nonempty finite vector. Preserve accuracy for logits near ±1000; subtracting a shared constant must not change results.

## Part 2 · Backpropagate the batch loss

Return {loss, gradient} for mean cross-entropy: logits=XW, X is B×D, W is D×C, labels has B class IDs. B,D,C are positive. Gradient has W's shape; no bias term or regularizer.

classifier_gradient.py · classifier_gradient(features, weights, labels) — Return {loss, gradient} for mean cross-entropy: logits=XW, X is B×D, W is D×C, labels has B class IDs. B,D,C are positive. Gradient has W's shape; no bias term or regularizer.

## Part 3 · Integrate and diagnose learning

Run steps full-batch SGD updates at nonnegative lr. Return weights, loss history before each update, and final_loss. Copy inputs; steps may be zero.

train_classifier.py · train_classifier(features, weights, labels, lr, steps) — Run steps full-batch SGD updates at nonnegative lr. Return weights, loss history before each update, and final_loss. Copy inputs; steps may be zero.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DL Systems · softmax regression and manual backpropagation](https://dlsyscourse.org/lectures/)

- [CS336 2025 · A1, cross-entropy and training](https://github.com/stanford-cs336/assignment1-basics/blob/6191c1a18088ec6edce02bad4451e445193abb8b/cs336_spring2025_assignment1_basics.pdf)

- [DL Systems · Homework 0 (original notebook)](https://github.com/dlsyscourse/hw0/blob/main/hw0.ipynb)


## Prediction and experimentation

1. Predict what a shared +1000 shift to the logits does to loss and gradients.
2. Compare lr=0.1, 1 and 5 for ten updates. Does a larger step always improve final loss?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
