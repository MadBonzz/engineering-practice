import math
import copy
import itertools
from collections import Counter
from log_probs import log_probs
from classifier_gradient import classifier_gradient

def train_classifier(features, weights, labels, lr, steps):
    """Run steps full-batch SGD updates at nonnegative lr. Return weights, loss history before each update, and final_loss. Copy inputs; steps may be zero."""
    raise NotImplementedError('train_classifier')
