import math
import copy
import itertools
from collections import Counter
from canonical_words import canonical_words
from shingles import shingles

def curate(documents, holdout, width, threshold, min_words):
    """Process documents [{id,text}] in input order; IDs are unique. Reject too_short first (<min_words), then contaminated if Jaccard shingle similarity with ANY holdout >=threshold, then duplicate if similar to ANY previously KEPT document. Empty sets have similarity 0. Return kept IDs and rejected [{id,reason}]. 0<threshold<=1, min_words>=1. This exact small-corpus filter does not use MinHash or infer language/quality."""
    raise NotImplementedError('curate')
