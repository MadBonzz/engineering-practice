import math
import copy
import itertools
from collections import Counter


def canonical_words(text):
    """Normalize with Unicode casefold and split on whitespace. Punctuation is preserved; empty/whitespace-only text becomes []."""
    raise NotImplementedError('canonical_words')
