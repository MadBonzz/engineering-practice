"""JSON request boundary. Trace this caller before editing the implementation modules."""
from curate import curate


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return curate(**request)
