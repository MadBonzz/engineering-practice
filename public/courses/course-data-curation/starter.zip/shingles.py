import math
import copy
import itertools
from collections import Counter
from canonical_words import canonical_words

def shingles(text, width):
    """Return sorted unique word-window tuples as lists, using canonical_words. Positive width. A nonempty text shorter than width contributes its entire word tuple; empty text contributes no shingles."""
    raise NotImplementedError('shingles')
