import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'documents': [{'id': 'a', 'text': 'Red blue green'},
               {'id': 'b', 'text': 'red BLUE green'},
               {'id': 'c', 'text': 'exam answer'},
               {'id': 'd', 'text': ' '}],
 'holdout': ['Exam answer'],
 'min_words': 2,
 'threshold': 1,
 'width': 2}
        expected = {'kept': ['a'],
 'rejected': [{'id': 'b', 'reason': 'duplicate'},
              {'id': 'c', 'reason': 'contaminated'},
              {'id': 'd', 'reason': 'too_short'}]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'documents': [{'id': 'a', 'text': 'Red blue green'},
               {'id': 'b', 'text': 'red BLUE green'},
               {'id': 'c', 'text': 'exam answer'},
               {'id': 'd', 'text': ' '}],
 'holdout': [],
 'min_words': 2,
 'threshold': 1,
 'width': 2}
        expected = {'kept': ['a', 'c'],
 'rejected': [{'id': 'b', 'reason': 'duplicate'},
              {'id': 'd', 'reason': 'too_short'}]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
