import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_whitespace(self):
        args = [' A\tB  ']
        expected = ['a', 'b']
        actual = trial('canonical_words.canonical_words', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_unicode_folding(self):
        args = ['Straße']
        expected = ['strasse']
        actual = trial('canonical_words.canonical_words', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_word_windows(self):
        args = ['a b c', 2]
        expected = [['a', 'b'], ['b', 'c']]
        actual = trial('shingles.shingles', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_short_document(self):
        args = ['a', 3]
        expected = [['a']]
        actual = trial('shingles.shingles', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_admission_reasons(self):
        args = [[{'id': 'a', 'text': 'Red blue green'},
  {'id': 'b', 'text': 'red BLUE green'},
  {'id': 'c', 'text': 'exam answer'},
  {'id': 'd', 'text': ' '}],
 ['Exam answer'],
 2,
 1,
 2]
        expected = {'kept': ['a'],
 'rejected': [{'id': 'b', 'reason': 'duplicate'},
              {'id': 'c', 'reason': 'contaminated'},
              {'id': 'd', 'reason': 'too_short'}]}
        actual = trial('curate.curate', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_empty_corpus(self):
        args = [[], [], 2, 0.5, 1]
        expected = {'kept': [], 'rejected': []}
        actual = trial('curate.curate', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

