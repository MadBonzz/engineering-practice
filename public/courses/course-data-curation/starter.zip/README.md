# Deduplicate training data without leaking evaluation text

A training corpus contains duplicate records and fragments from evaluation material. Implement a small deterministic admission filter with auditable rejection reasons.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Ordered uniquely identified documents, held-out texts and filter parameters.

## Output

Kept IDs and ordered rejection reasons.

## Constraints

No data downloads. Similarity uses exact normalized shingle sets; no transitive clustering or semantic similarity. Rejected rows never become representatives.

## Example 1

Input

~~~json
{
  "documents": [
    {
      "id": "a",
      "text": "Red blue green"
    },
    {
      "id": "b",
      "text": "red BLUE green"
    },
    {
      "id": "c",
      "text": "exam answer"
    },
    {
      "id": "d",
      "text": " "
    }
  ],
  "holdout": [
    "Exam answer"
  ],
  "width": 2,
  "threshold": 1,
  "min_words": 2
}
~~~

Output

~~~json
{
  "kept": [
    "a"
  ],
  "rejected": [
    {
      "id": "b",
      "reason": "duplicate"
    },
    {
      "id": "c",
      "reason": "contaminated"
    },
    {
      "id": "d",
      "reason": "too_short"
    }
  ]
}
~~~

Duplicates and evaluation contamination have different reasons.

## Example 2

Input

~~~json
{
  "documents": [
    {
      "id": "a",
      "text": "Red blue green"
    },
    {
      "id": "b",
      "text": "red BLUE green"
    },
    {
      "id": "c",
      "text": "exam answer"
    },
    {
      "id": "d",
      "text": " "
    }
  ],
  "holdout": [],
  "width": 2,
  "threshold": 1,
  "min_words": 2
}
~~~

Output

~~~json
{
  "kept": [
    "a",
    "c"
  ],
  "rejected": [
    {
      "id": "b",
      "reason": "duplicate"
    },
    {
      "id": "d",
      "reason": "too_short"
    }
  ]
}
~~~

Removing the held-out corpus changes only contamination filtering.

## Part 1 · Canonicalize comparisons

Normalize with Unicode casefold and split on whitespace. Punctuation is preserved; empty/whitespace-only text becomes [].

canonical_words.py · canonical_words(text) — Normalize with Unicode casefold and split on whitespace. Punctuation is preserved; empty/whitespace-only text becomes [].

## Part 2 · Represent local overlap

Return sorted unique word-window tuples as lists, using canonical_words. Positive width. A nonempty text shorter than width contributes its entire word tuple; empty text contributes no shingles.

shingles.py · shingles(text, width) — Return sorted unique word-window tuples as lists, using canonical_words. Positive width. A nonempty text shorter than width contributes its entire word tuple; empty text contributes no shingles.

## Part 3 · Enforce a deterministic admission policy

Process documents [{id,text}] in input order; IDs are unique. Reject too_short first (<min_words), then contaminated if Jaccard shingle similarity with ANY holdout >=threshold, then duplicate if similar to ANY previously KEPT document. Empty sets have similarity 0. Return kept IDs and rejected [{id,reason}]. 0<threshold<=1, min_words>=1. This exact small-corpus filter does not use MinHash or infer language/quality.

curate.py · curate(documents, holdout, width, threshold, min_words) — Process documents [{id,text}] in input order; IDs are unique. Reject too_short first (<min_words), then contaminated if Jaccard shingle similarity with ANY holdout >=threshold, then duplicate if similar to ANY previously KEPT document. Empty sets have similarity 0. Return kept IDs and rejected [{id,reason}]. 0<threshold<=1, min_words>=1. This exact small-corpus filter does not use MinHash or infer language/quality.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A4, filtering and deduplication](https://github.com/stanford-cs336/assignment4-data/blob/5a5f890cd9b72733e6273a596c40b696df3aa9df/cs336_spring2025_assignment4_data.pdf)

- [Deep Learning Alchemy · assignment a6_generalization](https://deep-learning-alchemy.github.io/assets/assignments/a6_generalization.pdf)


## Prediction and experimentation

1. Predict whether input order can change the retained representative.
2. Vary the overlap threshold and explain the tradeoff between deduplication and retaining useful data.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
