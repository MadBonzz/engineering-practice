import math
import copy
import itertools
from collections import Counter


def rms_vector(vector, epsilon):
    """Return x/sqrt(mean(x^2)+epsilon), with epsilon>0 and nonempty x. This is RMS normalization without learned gain; do not subtract the mean."""
    raise NotImplementedError('rms_vector')
