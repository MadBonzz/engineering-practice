"""JSON request boundary. Trace this caller before editing the implementation modules."""
from depth_probe import depth_probe


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return depth_probe(**request)
