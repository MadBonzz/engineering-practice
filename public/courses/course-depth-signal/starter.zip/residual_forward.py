import math
import copy
import itertools
from collections import Counter
from rms_vector import rms_vector

def residual_forward(vector, matrices, residual, normalize, branch_scale, epsilon):
    """Return states INCLUDING input for equal-width square matrices W. Each block: z=RMS(x) if normalize else x; branch=tanh(Wz); x_new=(x if residual else 0)+branch_scale*branch. No final normalization; no bias. All flags shared across depth."""
    raise NotImplementedError('residual_forward')
