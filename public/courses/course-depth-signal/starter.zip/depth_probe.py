import math
import copy
import itertools
from collections import Counter
from rms_vector import rms_vector
from residual_forward import residual_forward

def depth_probe(vector, matrices, residual, normalize, branch_scale, epsilon, direction, delta):
    """Return states, rms per state, directional_derivative of final output by centered finite differences along supplied direction, and sensitivity=norm(derivative)/norm(direction). delta>0, direction nonzero; derivative divides by 2*delta. This measures input sensitivity, not weight gradients or trained-model quality."""
    raise NotImplementedError('depth_probe')
