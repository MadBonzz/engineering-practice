import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_rms_scale(self):
        args = [[3, 4], 3.5]
        expected = [0.75, 1.0]
        actual = trial('rms_vector.rms_vector', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_zero_vector(self):
        args = [[0, 0], 1]
        expected = [0.0, 0.0]
        actual = trial('rms_vector.rms_vector', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_no_blocks(self):
        args = [[1], [], True, False, 1, 1]
        expected = [[1]]
        actual = trial('residual_forward.residual_forward', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_identity_bypass(self):
        args = [[1], [[[0]]], True, False, 1, 1]
        expected = [[1], [1.0]]
        actual = trial('residual_forward.residual_forward', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_identity_sensitivity(self):
        args = [[1], [], True, False, 1, 1, [1], 0.01]
        expected = {'directional_derivative': [1.0000000000000009],
 'rms': [1.0],
 'sensitivity': 1.0000000000000009,
 'states': [[1]]}
        actual = trial('depth_probe.depth_probe', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_signal_erased(self):
        args = [[1], [[[0]]], False, False, 1, 1, [1], 0.01]
        expected = {'directional_derivative': [0.0],
 'rms': [1.0, 0.0],
 'sensitivity': 0.0,
 'states': [[1], [0.0]]}
        actual = trial('depth_probe.depth_probe', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

