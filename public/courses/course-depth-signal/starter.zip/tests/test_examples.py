import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'branch_scale': 0.5,
 'delta': 1e-05,
 'direction': [1, 0],
 'epsilon': 1e-06,
 'matrices': [[[0.5, 0], [0, 0.5]],
              [[0.5, 0], [0, 0.5]],
              [[0.5, 0], [0, 0.5]],
              [[0.5, 0], [0, 0.5]]],
 'normalize': False,
 'residual': True,
 'vector': [0.2, -0.1]}
        expected = {'directional_derivative': [2.3995303328500084, 0.0],
 'rms': [0.15811388300841897,
         0.19753078686122227,
         0.24669647659573518,
         0.30794946356493813,
         0.3841224427929574],
 'sensitivity': 2.3995303328500084,
 'states': [[0.2, -0.1],
            [0.2498339973124779, -0.12497918747893999],
            [0.3119696388574163, -0.15618337799098048],
            [0.38933559354238995, -0.19515004437832248],
            [0.4854583402842006, -0.24378330944297008]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'branch_scale': 0.5,
 'delta': 1e-05,
 'direction': [1, 0],
 'epsilon': 1e-06,
 'matrices': [[[0.5, 0], [0, 0.5]],
              [[0.5, 0], [0, 0.5]],
              [[0.5, 0], [0, 0.5]],
              [[0.5, 0], [0, 0.5]]],
 'normalize': False,
 'residual': False,
 'vector': [0.2, -0.1]}
        expected = {'directional_derivative': [0.0038648870308885352, 0.0],
 'rms': [0.15811388300841897,
         0.0394169195603112,
         0.009852497578362183,
         0.002463097337567379,
         0.0006157739116359579],
 'sensitivity': 0.0038648870308885352,
 'states': [[0.2, -0.1],
            [0.04983399731247791, -0.02497918747893999],
            [0.012455921653497607, -0.0062444721814733685],
            [0.003113940152831373, -0.0015611129726088198],
            [0.0007784844091521081, -0.00039027816389082033]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
