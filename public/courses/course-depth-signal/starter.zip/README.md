# Measure signal and sensitivity through a residual stack

An architecture experiment needs comparable diagnostics across depth. Build a tiny residual-stack probe that distinguishes signal magnitude from input sensitivity.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

A small vector, square block matrices, architecture flags and a perturbation direction.

## Output

Block states, RMS magnitudes and a directional sensitivity measurement.

## Constraints

Finite bounded inputs, width<=8, depth<=12. Use central differences exactly as specified; do not infer generalization from this untrained toy probe.

## Example 1

Input

~~~json
{
  "vector": [
    0.2,
    -0.1
  ],
  "matrices": [
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ],
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ],
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ],
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ]
  ],
  "residual": true,
  "normalize": false,
  "branch_scale": 0.5,
  "epsilon": 1e-06,
  "direction": [
    1,
    0
  ],
  "delta": 1e-05
}
~~~

Output

~~~json
{
  "states": [
    [
      0.2,
      -0.1
    ],
    [
      0.2498339973124779,
      -0.12497918747893999
    ],
    [
      0.3119696388574163,
      -0.15618337799098048
    ],
    [
      0.38933559354238995,
      -0.19515004437832248
    ],
    [
      0.4854583402842006,
      -0.24378330944297008
    ]
  ],
  "rms": [
    0.15811388300841897,
    0.19753078686122227,
    0.24669647659573518,
    0.30794946356493813,
    0.3841224427929574
  ],
  "directional_derivative": [
    2.3995303328500084,
    0.0
  ],
  "sensitivity": 2.3995303328500084
}
~~~

Measure depth with an unchanged residual bypass.

## Example 2

Input

~~~json
{
  "vector": [
    0.2,
    -0.1
  ],
  "matrices": [
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ],
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ],
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ],
    [
      [
        0.5,
        0
      ],
      [
        0,
        0.5
      ]
    ]
  ],
  "residual": false,
  "normalize": false,
  "branch_scale": 0.5,
  "epsilon": 1e-06,
  "direction": [
    1,
    0
  ],
  "delta": 1e-05
}
~~~

Output

~~~json
{
  "states": [
    [
      0.2,
      -0.1
    ],
    [
      0.04983399731247791,
      -0.02497918747893999
    ],
    [
      0.012455921653497607,
      -0.0062444721814733685
    ],
    [
      0.003113940152831373,
      -0.0015611129726088198
    ],
    [
      0.0007784844091521081,
      -0.00039027816389082033
    ]
  ],
  "rms": [
    0.15811388300841897,
    0.0394169195603112,
    0.009852497578362183,
    0.002463097337567379,
    0.0006157739116359579
  ],
  "directional_derivative": [
    0.0038648870308885352,
    0.0
  ],
  "sensitivity": 0.0038648870308885352
}
~~~

Remove only the bypass before comparing sensitivity.

## Part 1 · Normalize signal magnitude

Return x/sqrt(mean(x^2)+epsilon), with epsilon>0 and nonempty x. This is RMS normalization without learned gain; do not subtract the mean.

rms_vector.py · rms_vector(vector, epsilon) — Return x/sqrt(mean(x^2)+epsilon), with epsilon>0 and nonempty x. This is RMS normalization without learned gain; do not subtract the mean.

## Part 2 · Compose architecture variants

Return states INCLUDING input for equal-width square matrices W. Each block: z=RMS(x) if normalize else x; branch=tanh(Wz); x_new=(x if residual else 0)+branch_scale*branch. No final normalization; no bias. All flags shared across depth.

residual_forward.py · residual_forward(vector, matrices, residual, normalize, branch_scale, epsilon) — Return states INCLUDING input for equal-width square matrices W. Each block: z=RMS(x) if normalize else x; branch=tanh(Wz); x_new=(x if residual else 0)+branch_scale*branch. No final normalization; no bias. All flags shared across depth.

## Part 3 · Measure a controlled perturbation

Return states, rms per state, directional_derivative of final output by centered finite differences along supplied direction, and sensitivity=norm(derivative)/norm(direction). delta>0, direction nonzero; derivative divides by 2*delta. This measures input sensitivity, not weight gradients or trained-model quality.

depth_probe.py · depth_probe(vector, matrices, residual, normalize, branch_scale, epsilon, direction, delta) — Return states, rms per state, directional_derivative of final output by centered finite differences along supplied direction, and sensitivity=norm(derivative)/norm(direction). delta>0, direction nonzero; derivative divides by 2*delta. This measures input sensitivity, not weight gradients or trained-model quality.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Deep Learning Alchemy · assignment a4_architecture1](https://deep-learning-alchemy.github.io/assets/assignments/a4_architecture1.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-stability.html)


## Prediction and experimentation

1. Predict sensitivity when branch_scale=0, with and without the residual bypass.
2. Increase depth while holding matrices fixed. Compare normalized and unnormalized variants; explain the limits of this toy evidence.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
