"""JSON request boundary. Trace this caller before editing the implementation modules."""
from corpus_loss import corpus_loss


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return corpus_loss(**request)
