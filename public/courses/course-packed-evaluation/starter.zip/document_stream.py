import math
import copy
import itertools
from collections import Counter


def document_stream(documents, eos):
    """Concatenate token documents, appending eos to EACH document (including empty ones). Return {tokens,segments}; each token gets its source document index. EOS is reserved and absent from document contents."""
    raise NotImplementedError('document_stream')
