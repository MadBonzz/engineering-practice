import math
import copy
import itertools
from collections import Counter
from document_stream import document_stream

def pack_windows(documents, eos, pad, block):
    """Make nonoverlapping input blocks from document_stream, with targets shifted by one in the FULL stream. Pad the final block. mask[t]=1 iff a next token exists and belongs to the same document, otherwise 0. Return [{inputs,targets,mask}], retaining EOS-only blocks. block>0, eos/pad distinct reserved IDs."""
    raise NotImplementedError('pack_windows')
