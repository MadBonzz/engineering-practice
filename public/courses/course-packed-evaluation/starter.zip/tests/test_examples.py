import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'block': 3,
 'documents': [[0, 1], [1]],
 'eos': 2,
 'logits': [[[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]],
            [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]],
 'pad': 3}
        expected = {'nll': 1.3862943611198906,
 'perplexity': 4.0,
 'tokens': 3,
 'windows': [{'inputs': [0, 1, 2],
              'mask': [1, 1, 0],
              'targets': [1, 2, 1]},
             {'inputs': [1, 2, 3],
              'mask': [1, 0, 0],
              'targets': [2, 3, 3]}]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'block': 2,
 'documents': [[]],
 'eos': 2,
 'logits': [[[0, 0, 0, 0], [0, 0, 0, 0]]],
 'pad': 3}
        expected = {'nll': None,
 'perplexity': None,
 'tokens': 0,
 'windows': [{'inputs': [2, 3], 'mask': [0, 0], 'targets': [3, 3]}]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
