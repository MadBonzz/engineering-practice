import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_two_documents(self):
        args = [[[0], [1]], 2]
        expected = {'segments': [0, 0, 1, 1], 'tokens': [0, 2, 1, 2]}
        actual = trial('document_stream.document_stream', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_empty_document(self):
        args = [[[]], 2]
        expected = {'segments': [0], 'tokens': [2]}
        actual = trial('document_stream.document_stream', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_one_document(self):
        args = [[[0]], 2, 3, 2]
        expected = [{'inputs': [0, 2], 'mask': [1, 0], 'targets': [2, 3]}]
        actual = trial('pack_windows.pack_windows', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_windows(self):
        args = [[], 2, 3, 2]
        expected = []
        actual = trial('pack_windows.pack_windows', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_uniform_likelihood(self):
        args = [[[0]], 2, 3, 2, [[[0, 0, 0, 0], [0, 0, 0, 0]]]]
        expected = {'nll': 1.3862943611198906,
 'perplexity': 4.0,
 'tokens': 1,
 'windows': [{'inputs': [0, 2], 'mask': [1, 0], 'targets': [2, 3]}]}
        actual = trial('corpus_loss.corpus_loss', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_scored_tokens(self):
        args = [[], 2, 3, 2, []]
        expected = {'nll': None, 'perplexity': None, 'tokens': 0, 'windows': []}
        actual = trial('corpus_loss.corpus_loss', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

