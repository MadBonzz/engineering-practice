import math
import copy
import itertools
from collections import Counter
from document_stream import document_stream
from pack_windows import pack_windows

def corpus_loss(documents, eos, pad, block, logits):
    """Logits have one block×V matrix per packed window; V includes all token IDs. Return windows, tokens (scored target count), nll (mean negative log probability) and perplexity=exp(nll). Ignore mask=0 positions; if no targets, nll/perplexity are null. Aggregate by scored tokens, not windows. Stable log-sum-exp required."""
    raise NotImplementedError('corpus_loss')
