# Pack language-model batches and score only valid targets

An evaluator produces different perplexities when sequence length changes. Repair packing, boundary masks and token-weighted aggregation.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Tokenized documents, reserved EOS/padding IDs, block size and compatible logit blocks.

## Output

Packed batches, scored-token count, NLL and perplexity.

## Constraints

Do not score a prediction from one document into the next. EOS targets inside a document do count. Logits are finite and resulting perplexity is representable.

## Example 1

Input

~~~json
{
  "documents": [
    [
      0,
      1
    ],
    [
      1
    ]
  ],
  "eos": 2,
  "pad": 3,
  "block": 3,
  "logits": [
    [
      [
        0,
        0,
        0,
        0
      ],
      [
        0,
        0,
        0,
        0
      ],
      [
        0,
        0,
        0,
        0
      ]
    ],
    [
      [
        0,
        0,
        0,
        0
      ],
      [
        0,
        0,
        0,
        0
      ],
      [
        0,
        0,
        0,
        0
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "windows": [
    {
      "inputs": [
        0,
        1,
        2
      ],
      "targets": [
        1,
        2,
        1
      ],
      "mask": [
        1,
        1,
        0
      ]
    },
    {
      "inputs": [
        1,
        2,
        3
      ],
      "targets": [
        2,
        3,
        3
      ],
      "mask": [
        1,
        0,
        0
      ]
    }
  ],
  "tokens": 3,
  "nll": 1.3862943611198906,
  "perplexity": 4.0
}
~~~

Uniform predictions have perplexity equal to vocabulary size.

## Example 2

Input

~~~json
{
  "documents": [
    []
  ],
  "eos": 2,
  "pad": 3,
  "block": 2,
  "logits": [
    [
      [
        0,
        0,
        0,
        0
      ],
      [
        0,
        0,
        0,
        0
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "windows": [
    {
      "inputs": [
        2,
        3
      ],
      "targets": [
        3,
        3
      ],
      "mask": [
        0,
        0
      ]
    }
  ],
  "tokens": 0,
  "nll": null,
  "perplexity": null
}
~~~

An EOS-only document supplies no next-token target.

## Part 1 · Preserve document boundaries

Concatenate token documents, appending eos to EACH document (including empty ones). Return {tokens,segments}; each token gets its source document index. EOS is reserved and absent from document contents.

document_stream.py · document_stream(documents, eos) — Concatenate token documents, appending eos to EACH document (including empty ones). Return {tokens,segments}; each token gets its source document index. EOS is reserved and absent from document contents.

## Part 2 · Shift labels before blocking

Make nonoverlapping input blocks from document_stream, with targets shifted by one in the FULL stream. Pad the final block. mask[t]=1 iff a next token exists and belongs to the same document, otherwise 0. Return [{inputs,targets,mask}], retaining EOS-only blocks. block>0, eos/pad distinct reserved IDs.

pack_windows.py · pack_windows(documents, eos, pad, block) — Make nonoverlapping input blocks from document_stream, with targets shifted by one in the FULL stream. Pad the final block. mask[t]=1 iff a next token exists and belongs to the same document, otherwise 0. Return [{inputs,targets,mask}], retaining EOS-only blocks. block>0, eos/pad distinct reserved IDs.

## Part 3 · Aggregate token-level likelihood

Logits have one block×V matrix per packed window; V includes all token IDs. Return windows, tokens (scored target count), nll (mean negative log probability) and perplexity=exp(nll). Ignore mask=0 positions; if no targets, nll/perplexity are null. Aggregate by scored tokens, not windows. Stable log-sum-exp required.

corpus_loss.py · corpus_loss(documents, eos, pad, block, logits) — Logits have one block×V matrix per packed window; V includes all token IDs. Return windows, tokens (scored target count), nll (mean negative log probability) and perplexity=exp(nll). Ignore mask=0 positions; if no targets, nll/perplexity are null. Aggregate by scored tokens, not windows. Stable log-sum-exp required.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A1, batching and evaluation](https://github.com/stanford-cs336/assignment1-basics/blob/6191c1a18088ec6edce02bad4451e445193abb8b/cs336_spring2025_assignment1_basics.pdf)

- [Deep Learning Alchemy · assignment a6_generalization](https://deep-learning-alchemy.github.io/assets/assignments/a6_generalization.pdf)


## Prediction and experimentation

1. Predict whether changing only block length changes the scored-token count.
2. Compare a token-weighted loss with a mean of per-window losses on an uneven final block.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
