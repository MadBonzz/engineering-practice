"""JSON request boundary. Trace this caller before editing the implementation modules."""
from allocate_compute import allocate_compute


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return allocate_compute(**request)
