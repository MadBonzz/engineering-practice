# Choose a training plan under a compute budget

A research scheduler must choose among proposed training runs using measured small-scale trends. Build a transparent fitting and budget-selection tool.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Isolated component measurements, a loss floor, candidate model/token sizes and a FLOP budget.

## Output

Fitted coefficients/exponents and the best feasible proposal.

## Constraints

The 6ND training cost and additive loss law are explicit approximations. This exercise does not claim to recover scaling laws from arbitrary total-loss data.

## Example 1

Input

~~~json
{
  "model_points": [
    [
      1,
      4
    ],
    [
      2,
      2
    ],
    [
      4,
      1
    ]
  ],
  "data_points": [
    [
      1,
      4
    ],
    [
      2,
      2
    ],
    [
      4,
      1
    ]
  ],
  "floor": 1,
  "candidates": [
    {
      "id": "wide",
      "parameters": 4,
      "tokens": 1
    },
    {
      "id": "balanced",
      "parameters": 2,
      "tokens": 2
    }
  ],
  "budget": 24
}
~~~

Output

~~~json
{
  "model": {
    "coefficient": 4.0,
    "exponent": 1.0
  },
  "data": {
    "coefficient": 4.0,
    "exponent": 1.0
  },
  "best": {
    "id": "balanced",
    "loss": 5.0,
    "compute": 24
  }
}
~~~

Balanced model and data can beat a larger model at equal compute.

## Example 2

Input

~~~json
{
  "model_points": [
    [
      1,
      4
    ],
    [
      2,
      2
    ],
    [
      4,
      1
    ]
  ],
  "data_points": [
    [
      1,
      4
    ],
    [
      2,
      2
    ],
    [
      4,
      1
    ]
  ],
  "floor": 1,
  "candidates": [
    {
      "id": "wide",
      "parameters": 4,
      "tokens": 1
    },
    {
      "id": "balanced",
      "parameters": 2,
      "tokens": 2
    }
  ],
  "budget": 1
}
~~~

Output

~~~json
{
  "model": {
    "coefficient": 4.0,
    "exponent": 1.0
  },
  "data": {
    "coefficient": 4.0,
    "exponent": 1.0
  },
  "best": null
}
~~~

A budget can exclude every candidate.

## Part 1 · Fit isolated scaling components

Fit y=A*x^(-alpha) by ordinary least squares on natural logs. points are positive [x,y], at least two distinct x. Return {coefficient:A, exponent:alpha}. y is an already isolated positive loss component, not total loss with an unknown floor.

fit_power.py · fit_power(points) — Fit y=A*x^(-alpha) by ordinary least squares on natural logs. points are positive [x,y], at least two distinct x. Return {coefficient:A, exponent:alpha}. y is an already isolated positive loss component, not total loss with an unknown floor.

## Part 2 · Combine model and data constraints

Return floor + A*parameters^(-alpha) + B*tokens^(-beta), using coefficient/exponent fits. parameters,tokens>0; floor>=0. This is a stated additive model, not an empirical guarantee.

predicted_loss.py · predicted_loss(parameters, tokens, model, data, floor) — Return floor + A*parameters^(-alpha) + B*tokens^(-beta), using coefficient/exponent fits. parameters,tokens>0; floor>=0. This is a stated additive model, not an empirical guarantee.

## Part 3 · Compare feasible plans

Fit model/data components, evaluate candidate {id,parameters,tokens} plans with compute=6*parameters*tokens<=budget. Return fits and best {id,loss,compute}; best is null if infeasible. Choose minimum loss, then smaller compute, then lexical ID. Never select from evaluation data. Distinct IDs, positive sizes.

allocate_compute.py · allocate_compute(model_points, data_points, floor, candidates, budget) — Fit model/data components, evaluate candidate {id,parameters,tokens} plans with compute=6*parameters*tokens<=budget. Return fits and best {id,loss,compute}; best is null if infeasible. Choose minimum loss, then smaller compute, then lexical ID. Never select from evaluation data. Distinct IDs, positive sizes.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A3 and scaling lectures](https://cs336.stanford.edu/spring2025/)

- [Deep Learning Alchemy · assignment a1_basics](https://deep-learning-alchemy.github.io/assets/assignments/a1_basics.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-basics.html)


## Prediction and experimentation

1. Fit the same curve with and without its largest-scale point. What evidence would justify extrapolating?
2. Hold FLOPs fixed and compare model-heavy and data-heavy plans. Which assumption controls the winner?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
