import math
import copy
import itertools
from collections import Counter
from fit_power import fit_power
from predicted_loss import predicted_loss

def allocate_compute(model_points, data_points, floor, candidates, budget):
    """Fit model/data components, evaluate candidate {id,parameters,tokens} plans with compute=6*parameters*tokens<=budget. Return fits and best {id,loss,compute}; best is null if infeasible. Choose minimum loss, then smaller compute, then lexical ID. Never select from evaluation data. Distinct IDs, positive sizes."""
    raise NotImplementedError('allocate_compute')
