import math
import copy
import itertools
from collections import Counter
from fit_power import fit_power

def predicted_loss(parameters, tokens, model, data, floor):
    """Return floor + A*parameters^(-alpha) + B*tokens^(-beta), using coefficient/exponent fits. parameters,tokens>0; floor>=0. This is a stated additive model, not an empirical guarantee."""
    raise NotImplementedError('predicted_loss')
