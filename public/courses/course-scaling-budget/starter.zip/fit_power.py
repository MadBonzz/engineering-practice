import math
import copy
import itertools
from collections import Counter


def fit_power(points):
    """Fit y=A*x^(-alpha) by ordinary least squares on natural logs. points are positive [x,y], at least two distinct x. Return {coefficient:A, exponent:alpha}. y is an already isolated positive loss component, not total loss with an unknown floor."""
    raise NotImplementedError('fit_power')
