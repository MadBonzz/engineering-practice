import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'budget': 24,
 'candidates': [{'id': 'wide', 'parameters': 4, 'tokens': 1},
                {'id': 'balanced', 'parameters': 2, 'tokens': 2}],
 'data_points': [[1, 4], [2, 2], [4, 1]],
 'floor': 1,
 'model_points': [[1, 4], [2, 2], [4, 1]]}
        expected = {'best': {'compute': 24, 'id': 'balanced', 'loss': 5.0},
 'data': {'coefficient': 4.0, 'exponent': 1.0},
 'model': {'coefficient': 4.0, 'exponent': 1.0}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'budget': 1,
 'candidates': [{'id': 'wide', 'parameters': 4, 'tokens': 1},
                {'id': 'balanced', 'parameters': 2, 'tokens': 2}],
 'data_points': [[1, 4], [2, 2], [4, 1]],
 'floor': 1,
 'model_points': [[1, 4], [2, 2], [4, 1]]}
        expected = {'best': None,
 'data': {'coefficient': 4.0, 'exponent': 1.0},
 'model': {'coefficient': 4.0, 'exponent': 1.0}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
