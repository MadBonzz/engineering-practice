import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_inverse_scaling(self):
        args = [[[1, 4], [2, 2], [4, 1]]]
        expected = {'coefficient': 4.0, 'exponent': 1.0}
        actual = trial('fit_power.fit_power', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_flat_component(self):
        args = [[[1, 3], [2, 3]]]
        expected = {'coefficient': 3.0000000000000004, 'exponent': -0.0}
        actual = trial('fit_power.fit_power', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_balanced_resources(self):
        args = [2, 2, {'coefficient': 4, 'exponent': 1}, {'coefficient': 4, 'exponent': 1}, 1]
        expected = 5.0
        actual = trial('predicted_loss.predicted_loss', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_token_limited_plan(self):
        args = [4, 1, {'coefficient': 4, 'exponent': 1}, {'coefficient': 4, 'exponent': 1}, 1]
        expected = 6.0
        actual = trial('predicted_loss.predicted_loss', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_budget_choice(self):
        args = [[[1, 4], [2, 2], [4, 1]],
 [[1, 4], [2, 2], [4, 1]],
 1,
 [{'id': 'wide', 'parameters': 4, 'tokens': 1},
  {'id': 'balanced', 'parameters': 2, 'tokens': 2}],
 24]
        expected = {'best': {'compute': 24, 'id': 'balanced', 'loss': 5.0},
 'data': {'coefficient': 4.0, 'exponent': 1.0},
 'model': {'coefficient': 4.0, 'exponent': 1.0}}
        actual = trial('allocate_compute.allocate_compute', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_candidates(self):
        args = [[[1, 4], [2, 2], [4, 1]], [[1, 4], [2, 2], [4, 1]], 1, [], 24]
        expected = {'best': None,
 'data': {'coefficient': 4.0, 'exponent': 1.0},
 'model': {'coefficient': 4.0, 'exponent': 1.0}}
        actual = trial('allocate_compute.allocate_compute', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

