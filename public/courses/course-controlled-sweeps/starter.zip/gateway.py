"""JSON request boundary. Trace this caller before editing the implementation modules."""
from select_recipe import select_recipe


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return select_recipe(**request)
