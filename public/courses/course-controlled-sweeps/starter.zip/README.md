# Compare experiments without changing the question

A researcher has retried runs, unmatched seeds and checkpoints from different budgets. Build a comparison tool that answers a fixed experimental question without test-set selection.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Run records, a control recipe and an exact training horizon.

## Output

Matched effects, validation-selected recipe and its held-out test result.

## Constraints

Finite losses, nonnegative integer steps, integer seeds and recipe names. Records are observations, not proof of causality. No interpolation between horizons.

## Example 1

Input

~~~json
{
  "records": [
    {
      "recipe": "base",
      "seed": 1,
      "step": 10,
      "validation": 3,
      "test": 1
    },
    {
      "recipe": "base",
      "seed": 2,
      "step": 10,
      "validation": 5,
      "test": 1
    },
    {
      "recipe": "new",
      "seed": 1,
      "step": 10,
      "validation": 2,
      "test": 9
    },
    {
      "recipe": "new",
      "seed": 2,
      "step": 10,
      "validation": 4,
      "test": 9
    }
  ],
  "control": "base",
  "budget": 10
}
~~~

Output

~~~json
{
  "selected": "new",
  "seeds": [
    1,
    2
  ],
  "test": 9.0,
  "effects": {
    "base": {
      "seeds": [
        1,
        2
      ],
      "differences": [
        0,
        0
      ],
      "mean": 0.0,
      "standard_error": 0.0
    },
    "new": {
      "seeds": [
        1,
        2
      ],
      "differences": [
        -1,
        -1
      ],
      "mean": -1.0,
      "standard_error": 0.0
    }
  }
}
~~~

The validation winner has worse test loss: do not change the selection rule after seeing it.

## Example 2

Input

~~~json
{
  "records": [
    {
      "recipe": "base",
      "seed": 1,
      "step": 10,
      "validation": 3,
      "test": 1
    },
    {
      "recipe": "base",
      "seed": 2,
      "step": 10,
      "validation": 5,
      "test": 1
    },
    {
      "recipe": "new",
      "seed": 1,
      "step": 10,
      "validation": 2,
      "test": 9
    },
    {
      "recipe": "new",
      "seed": 2,
      "step": 10,
      "validation": 4,
      "test": 9
    }
  ],
  "control": "base",
  "budget": 9
}
~~~

Output

~~~json
{
  "selected": null,
  "seeds": [],
  "test": null,
  "effects": {}
}
~~~

No exact-horizon records means no comparison.

## Part 1 · Align runs at equal training budget

Records have recipe,seed,step,validation,test. Keep only exact step==budget; for repeated (recipe,seed) records at that step, the LAST record wins. Return rows sorted by recipe then integer seed. Do not select each run's best checkpoint.

final_records.py · final_records(records, budget) — Records have recipe,seed,step,validation,test. Keep only exact step==budget; for repeated (recipe,seed) records at that step, the LAST record wins. Return rows sorted by recipe then integer seed. Do not select each run's best checkpoint.

## Part 2 · Measure matched-seed effects

Use final_records and pair only seeds present in both recipes. Return seeds, candidate-minus-control validation differences, mean and standard_error. Sample SD/sqrt(n); one pair has SE=0; no pairs has mean/SE=null. Negative mean favors candidate.

paired_effect.py · paired_effect(records, control, candidate, budget) — Use final_records and pair only seeds present in both recipes. Return seeds, candidate-minus-control validation differences, mean and standard_error. Sample SD/sqrt(n); one pair has SE=0; no pairs has mean/SE=null. Negative mean favors candidate.

## Part 3 · Keep selection separate from final evaluation

Use seeds shared by ALL recipes with an exact-budget record. Rank recipes by mean validation over those seeds, then lexical recipe name. Return selected recipe, common seeds, selected mean test loss, and paired effects against control. If control absent or no common seeds, return selected=null,seeds=[],test=null,effects={}. Test values never influence selection.

select_recipe.py · select_recipe(records, control, budget) — Use seeds shared by ALL recipes with an exact-budget record. Rank recipes by mean validation over those seeds, then lexical recipe name. Return selected recipe, common seeds, selected mean test loss, and paired effects against control. If control absent or no common seeds, return selected=null,seeds=[],test=null,effects={}. Test values never influence selection.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Deep Learning Alchemy · assignment a1_basics](https://deep-learning-alchemy.github.io/assets/assignments/a1_basics.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-basics.html)

- [Deep Learning Alchemy · assignment a6_generalization](https://deep-learning-alchemy.github.io/assets/assignments/a6_generalization.pdf)

- [CS336 2025 · scaling and evaluation](https://cs336.stanford.edu/spring2025/)


## Prediction and experimentation

1. Before running, predict whether a better validation recipe must improve test loss.
2. Add one unpaired seed with an extreme loss. Which comparison should change?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
