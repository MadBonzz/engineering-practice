import math
import copy
import itertools
from collections import Counter


def final_records(records, budget):
    """Records have recipe,seed,step,validation,test. Keep only exact step==budget; for repeated (recipe,seed) records at that step, the LAST record wins. Return rows sorted by recipe then integer seed. Do not select each run's best checkpoint."""
    raise NotImplementedError('final_records')
