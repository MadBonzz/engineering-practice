import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_final_records(self):
        args = [[{'recipe': 'base', 'seed': 1, 'step': 10, 'test': 1, 'validation': 3},
  {'recipe': 'base', 'seed': 2, 'step': 10, 'test': 1, 'validation': 5},
  {'recipe': 'new', 'seed': 1, 'step': 10, 'test': 9, 'validation': 2},
  {'recipe': 'new', 'seed': 2, 'step': 10, 'test': 9, 'validation': 4}],
 10]
        expected = [{'recipe': 'base', 'seed': 1, 'step': 10, 'test': 1, 'validation': 3},
 {'recipe': 'base', 'seed': 2, 'step': 10, 'test': 1, 'validation': 5},
 {'recipe': 'new', 'seed': 1, 'step': 10, 'test': 9, 'validation': 2},
 {'recipe': 'new', 'seed': 2, 'step': 10, 'test': 9, 'validation': 4}]
        actual = trial('final_records.final_records', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_missing_horizon(self):
        args = [[{'recipe': 'base', 'seed': 1, 'step': 10, 'test': 1, 'validation': 3},
  {'recipe': 'base', 'seed': 2, 'step': 10, 'test': 1, 'validation': 5},
  {'recipe': 'new', 'seed': 1, 'step': 10, 'test': 9, 'validation': 2},
  {'recipe': 'new', 'seed': 2, 'step': 10, 'test': 9, 'validation': 4}],
 9]
        expected = []
        actual = trial('final_records.final_records', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_paired_improvement(self):
        args = [[{'recipe': 'base', 'seed': 1, 'step': 10, 'test': 1, 'validation': 3},
  {'recipe': 'base', 'seed': 2, 'step': 10, 'test': 1, 'validation': 5},
  {'recipe': 'new', 'seed': 1, 'step': 10, 'test': 9, 'validation': 2},
  {'recipe': 'new', 'seed': 2, 'step': 10, 'test': 9, 'validation': 4}],
 'base',
 'new',
 10]
        expected = {'differences': [-1, -1], 'mean': -1.0, 'seeds': [1, 2], 'standard_error': 0.0}
        actual = trial('paired_effect.paired_effect', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_pairs(self):
        args = [[{'recipe': 'base', 'seed': 1, 'step': 10, 'test': 1, 'validation': 3},
  {'recipe': 'base', 'seed': 2, 'step': 10, 'test': 1, 'validation': 5},
  {'recipe': 'new', 'seed': 1, 'step': 10, 'test': 9, 'validation': 2},
  {'recipe': 'new', 'seed': 2, 'step': 10, 'test': 9, 'validation': 4}],
 'base',
 'missing',
 10]
        expected = {'differences': [], 'mean': None, 'seeds': [], 'standard_error': None}
        actual = trial('paired_effect.paired_effect', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_validation_selection(self):
        args = [[{'recipe': 'base', 'seed': 1, 'step': 10, 'test': 1, 'validation': 3},
  {'recipe': 'base', 'seed': 2, 'step': 10, 'test': 1, 'validation': 5},
  {'recipe': 'new', 'seed': 1, 'step': 10, 'test': 9, 'validation': 2},
  {'recipe': 'new', 'seed': 2, 'step': 10, 'test': 9, 'validation': 4}],
 'base',
 10]
        expected = {'effects': {'base': {'differences': [0, 0],
                      'mean': 0.0,
                      'seeds': [1, 2],
                      'standard_error': 0.0},
             'new': {'differences': [-1, -1],
                     'mean': -1.0,
                     'seeds': [1, 2],
                     'standard_error': 0.0}},
 'seeds': [1, 2],
 'selected': 'new',
 'test': 9.0}
        actual = trial('select_recipe.select_recipe', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_experiments(self):
        args = [[], 'base', 10]
        expected = {'effects': {}, 'seeds': [], 'selected': None, 'test': None}
        actual = trial('select_recipe.select_recipe', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

