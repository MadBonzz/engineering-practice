import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'budget': 10,
 'control': 'base',
 'records': [{'recipe': 'base',
              'seed': 1,
              'step': 10,
              'test': 1,
              'validation': 3},
             {'recipe': 'base',
              'seed': 2,
              'step': 10,
              'test': 1,
              'validation': 5},
             {'recipe': 'new',
              'seed': 1,
              'step': 10,
              'test': 9,
              'validation': 2},
             {'recipe': 'new',
              'seed': 2,
              'step': 10,
              'test': 9,
              'validation': 4}]}
        expected = {'effects': {'base': {'differences': [0, 0],
                      'mean': 0.0,
                      'seeds': [1, 2],
                      'standard_error': 0.0},
             'new': {'differences': [-1, -1],
                     'mean': -1.0,
                     'seeds': [1, 2],
                     'standard_error': 0.0}},
 'seeds': [1, 2],
 'selected': 'new',
 'test': 9.0}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'budget': 9,
 'control': 'base',
 'records': [{'recipe': 'base',
              'seed': 1,
              'step': 10,
              'test': 1,
              'validation': 3},
             {'recipe': 'base',
              'seed': 2,
              'step': 10,
              'test': 1,
              'validation': 5},
             {'recipe': 'new',
              'seed': 1,
              'step': 10,
              'test': 9,
              'validation': 2},
             {'recipe': 'new',
              'seed': 2,
              'step': 10,
              'test': 9,
              'validation': 4}]}
        expected = {'effects': {}, 'seeds': [], 'selected': None, 'test': None}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
