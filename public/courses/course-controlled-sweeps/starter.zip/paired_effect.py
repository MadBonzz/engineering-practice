import math
import copy
import itertools
from collections import Counter
from final_records import final_records

def paired_effect(records, control, candidate, budget):
    """Use final_records and pair only seeds present in both recipes. Return seeds, candidate-minus-control validation differences, mean and standard_error. Sample SD/sqrt(n); one pair has SE=0; no pairs has mean/SE=null. Negative mean favors candidate."""
    raise NotImplementedError('paired_effect')
