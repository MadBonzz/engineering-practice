import math
import copy
import itertools
from collections import Counter
from final_records import final_records
from paired_effect import paired_effect

def select_recipe(records, control, budget):
    """Use seeds shared by ALL recipes with an exact-budget record. Rank recipes by mean validation over those seeds, then lexical recipe name. Return selected recipe, common seeds, selected mean test loss, and paired effects against control. If control absent or no common seeds, return selected=null,seeds=[],test=null,effects={}. Test values never influence selection."""
    raise NotImplementedError('select_recipe')
