import math
import copy
import itertools
from collections import Counter


def image_patches(image, kernel, stride, padding):
    """Single-channel cross-correlation: return flat row-major K×K patches for a rectangular image, zero-padding all sides. Output H=floor((H+2P-K)/S)+1, similarly W; K,S>0, P>=0 and outputs have positive dimensions."""
    raise NotImplementedError('image_patches')
