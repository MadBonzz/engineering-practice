import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'image': [[1, 2], [3, 4]],
 'padding': 0,
 'stride': 1,
 'upstream': [[2]],
 'weights': [[1, 0], [0, -1]]}
        expected = {'image_gradient': [[2.0, 0.0], [0.0, -2.0]],
 'output': [[-3]],
 'weight_gradient': [[2.0, 4.0], [6.0, 8.0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'image': [[2]],
 'padding': 0,
 'stride': 1,
 'upstream': [[1]],
 'weights': [[3]]}
        expected = {'image_gradient': [[3.0]], 'output': [[6]], 'weight_gradient': [[2.0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
