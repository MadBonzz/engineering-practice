import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_one_patch(self):
        args = [[[1, 2], [3, 4]], 2, 1, 0]
        expected = [[1, 2, 3, 4]]
        actual = trial('image_patches.image_patches', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_point_filter(self):
        args = [[[2]], 1, 1, 0]
        expected = [[2]]
        actual = trial('image_patches.image_patches', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_asymmetric_filter(self):
        args = [[[1, 2], [3, 4]], [[1, 0], [0, -1]], 1, 0]
        expected = [[-3]]
        actual = trial('filter_forward.filter_forward', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_pointwise(self):
        args = [[[2]], [[3]], 1, 0]
        expected = [[6]]
        actual = trial('filter_forward.filter_forward', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_both_derivatives(self):
        args = [[[1, 2], [3, 4]], [[1, 0], [0, -1]], 1, 0, [[2]]]
        expected = {'image_gradient': [[2.0, 0.0], [0.0, -2.0]],
 'output': [[-3]],
 'weight_gradient': [[2.0, 4.0], [6.0, 8.0]]}
        actual = trial('filter_backward.filter_backward', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_zero_upstream(self):
        args = [[[2]], [[3]], 1, 0, [[0]]]
        expected = {'image_gradient': [[0.0]], 'output': [[6]], 'weight_gradient': [[0.0]]}
        actual = trial('filter_backward.filter_backward', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

