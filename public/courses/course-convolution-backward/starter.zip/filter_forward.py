import math
import copy
import itertools
from collections import Counter
from image_patches import image_patches

def filter_forward(image, weights, stride, padding):
    """Return a 2-D single-channel cross-correlation using square weights, no kernel flip, no bias. Reuse image_patches; preserve output row-major order."""
    raise NotImplementedError('filter_forward')
