import math
import copy
import itertools
from collections import Counter
from image_patches import image_patches
from filter_forward import filter_forward

def filter_backward(image, weights, stride, padding, upstream):
    """Return {output, image_gradient, weight_gradient} for sum(output*upstream). Accumulate overlapping receptive fields; skip padded cells in image_gradient. Upstream has output shape."""
    raise NotImplementedError('filter_backward')
