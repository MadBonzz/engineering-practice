"""JSON request boundary. Trace this caller before editing the implementation modules."""
from filter_backward import filter_backward


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return filter_backward(**request)
