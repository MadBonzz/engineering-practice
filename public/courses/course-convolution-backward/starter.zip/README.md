# Connect an image filter to backpropagation

An image pipeline already evaluates filters but cannot train them. Implement receptive-field extraction and the backward transport needed by the optimizer.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

A rectangular one-channel image, square filter, stride, padding and output derivative.

## Output

Forward image and gradients with respect to the original image and filter.

## Constraints

Dimensions satisfy the output formula; gradients are sums, not averages. Inputs remain unchanged.

## Example 1

Input

~~~json
{
  "image": [
    [
      1,
      2
    ],
    [
      3,
      4
    ]
  ],
  "weights": [
    [
      1,
      0
    ],
    [
      0,
      -1
    ]
  ],
  "stride": 1,
  "padding": 0,
  "upstream": [
    [
      2
    ]
  ]
}
~~~

Output

~~~json
{
  "output": [
    [
      -3
    ]
  ],
  "image_gradient": [
    [
      2.0,
      0.0
    ],
    [
      0.0,
      -2.0
    ]
  ],
  "weight_gradient": [
    [
      2.0,
      4.0
    ],
    [
      6.0,
      8.0
    ]
  ]
}
~~~

A single receptive field exposes both derivatives.

## Example 2

Input

~~~json
{
  "image": [
    [
      2
    ]
  ],
  "weights": [
    [
      3
    ]
  ],
  "stride": 1,
  "padding": 0,
  "upstream": [
    [
      1
    ]
  ]
}
~~~

Output

~~~json
{
  "output": [
    [
      6
    ]
  ],
  "image_gradient": [
    [
      3.0
    ]
  ],
  "weight_gradient": [
    [
      2.0
    ]
  ]
}
~~~

A point filter is a multiplication.

## Part 1 · Lower receptive fields

Single-channel cross-correlation: return flat row-major K×K patches for a rectangular image, zero-padding all sides. Output H=floor((H+2P-K)/S)+1, similarly W; K,S>0, P>=0 and outputs have positive dimensions.

image_patches.py · image_patches(image, kernel, stride, padding) — Single-channel cross-correlation: return flat row-major K×K patches for a rectangular image, zero-padding all sides. Output H=floor((H+2P-K)/S)+1, similarly W; K,S>0, P>=0 and outputs have positive dimensions.

## Part 2 · Apply a shared filter

Return a 2-D single-channel cross-correlation using square weights, no kernel flip, no bias. Reuse image_patches; preserve output row-major order.

filter_forward.py · filter_forward(image, weights, stride, padding) — Return a 2-D single-channel cross-correlation using square weights, no kernel flip, no bias. Reuse image_patches; preserve output row-major order.

## Part 3 · Accumulate both derivatives

Return {output, image_gradient, weight_gradient} for sum(output*upstream). Accumulate overlapping receptive fields; skip padded cells in image_gradient. Upstream has output shape.

filter_backward.py · filter_backward(image, weights, stride, padding, upstream) — Return {output, image_gradient, weight_gradient} for sum(output*upstream). Accumulate overlapping receptive fields; skip padded cells in image_gradient. Upstream has output shape.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DL Systems · convolution implementation](https://dlsyscourse.org/lectures/)

- [DL Systems · Homework 4 (original notebook)](https://github.com/dlsyscourse/hw4/blob/main/hw4.ipynb)


## Prediction and experimentation

1. Predict the input-gradient pattern for an all-ones kernel and upstream image.
2. Change stride from one to two. Which input pixels stop receiving gradient?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
