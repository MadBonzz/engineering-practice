import math
import copy
import itertools
from collections import Counter
from tiny_predict import tiny_predict
from tiny_gradient import tiny_gradient

def learning_curve(train_x, train_y, validation_x, validation_y, weights, lr, steps, decay, freeze_hidden):
    """Full-batch SGD on tiny_gradient; add decay*w to EACH trainable parameter's gradient. Freeze hidden weights completely when requested, including decay. Report initial and post-update train/validation HALF-MSE (excluding regularization), final weights, and unique_examples=len(train_x), exposures=len(train_x)*steps. Validation never affects updates. Positive-sized train/validation sets; lr/decay>=0, steps>=0."""
    raise NotImplementedError('learning_curve')
