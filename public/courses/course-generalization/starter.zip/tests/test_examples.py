import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'decay': 0,
 'freeze_hidden': False,
 'lr': 0.2,
 'steps': 4,
 'train_x': [[-1], [1]],
 'train_y': [-1, 1],
 'validation_x': [[-0.5], [0.5]],
 'validation_y': [-0.5, 0.5],
 'weights': {'hidden': [[1]], 'readout': [1]}}
        expected = {'exposures': 8,
 'train': [0.028418673237222088,
           0.020435599507919375,
           0.014599708872711645,
           0.010375173668067953,
           0.007341149998679099],
 'unique_examples': 2,
 'validation': [0.0007175548870314165,
                8.423128061935962e-05,
                3.800223402417856e-05,
                0.0003771813712991883,
                0.0009485664776793488],
 'weights': {'hidden': [[1.0637855813781707]],
             'readout': [1.1165291041434482]}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'decay': 0,
 'freeze_hidden': True,
 'lr': 0.2,
 'steps': 4,
 'train_x': [[-1], [1]],
 'train_y': [-1, 1],
 'validation_x': [[-0.5], [0.5]],
 'validation_y': [-0.5, 0.5],
 'weights': {'hidden': [[1]], 'readout': [1]}}
        expected = {'exposures': 8,
 'train': [0.028418673237222088,
           0.02220768487692641,
           0.017354127107767608,
           0.013561329302968566,
           0.010597459112837614],
 'unique_examples': 2,
 'validation': [0.0007175548870314165,
                0.00022264000946261252,
                1.963876614582634e-05,
                2.3436770219935466e-05,
                0.00016999438374831066],
 'weights': {'hidden': [[1]], 'readout': [1.1218773771612174]}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
