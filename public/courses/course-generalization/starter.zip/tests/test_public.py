import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_zero_input(self):
        args = [[[0]], {'hidden': [[1]], 'readout': [1]}]
        expected = [0.0]
        actual = trial('tiny_predict.tiny_predict', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_zero_hidden_weight(self):
        args = [[[1]], {'hidden': [[0]], 'readout': [2]}]
        expected = [0.0]
        actual = trial('tiny_predict.tiny_predict', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_hidden_derivative_at_zero(self):
        args = [[[1]], [1], {'hidden': [[0]], 'readout': [2]}]
        expected = {'hidden': [[-2.0]], 'loss': 0.5, 'readout': [0.0]}
        actual = trial('tiny_gradient.tiny_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_feature_signal(self):
        args = [[[0]], [1], {'hidden': [[1]], 'readout': [1]}]
        expected = {'hidden': [[0.0]], 'loss': 0.5, 'readout': [0.0]}
        actual = trial('tiny_gradient.tiny_gradient', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_training_curve(self):
        args = [[[-1], [1]],
 [-1, 1],
 [[-0.5], [0.5]],
 [-0.5, 0.5],
 {'hidden': [[1]], 'readout': [1]},
 0.2,
 4,
 0,
 False]
        expected = {'exposures': 8,
 'train': [0.028418673237222088,
           0.020435599507919375,
           0.014599708872711645,
           0.010375173668067953,
           0.007341149998679099],
 'unique_examples': 2,
 'validation': [0.0007175548870314165,
                8.423128061935962e-05,
                3.800223402417856e-05,
                0.0003771813712991883,
                0.0009485664776793488],
 'weights': {'hidden': [[1.0637855813781707]], 'readout': [1.1165291041434482]}}
        actual = trial('learning_curve.learning_curve', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_trainable_signal(self):
        args = [[[0]], [1], [[0]], [2], {'hidden': [[1]], 'readout': [1]}, 0.1, 1, 0, False]
        expected = {'exposures': 1,
 'train': [0.5, 0.5],
 'unique_examples': 1,
 'validation': [2.0, 2.0],
 'weights': {'hidden': [[1.0]], 'readout': [1.0]}}
        actual = trial('learning_curve.learning_curve', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

