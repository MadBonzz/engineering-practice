"""JSON request boundary. Trace this caller before editing the implementation modules."""
from learning_curve import learning_curve


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return learning_curve(**request)
