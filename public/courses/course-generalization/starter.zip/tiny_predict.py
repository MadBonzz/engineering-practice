import math
import copy
import itertools
from collections import Counter


def tiny_predict(inputs, weights):
    """One-hidden-layer regressor without biases: hidden=tanh(Wx), output=v·hidden. weights={hidden: H×D, readout:H}; inputs B×D. Return scalar predictions per row."""
    raise NotImplementedError('tiny_predict')
