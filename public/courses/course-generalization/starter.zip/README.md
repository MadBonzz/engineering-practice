# Run a tiny training and transfer-learning experiment

A small-data study needs a complete, inspectable training loop to compare feature learning, frozen-feature transfer and regularization. Implement the model and its experimental harness.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Disjoint training/validation arrays, initial weights and an SGD recipe.

## Output

Learning curves, final weights and data-exposure accounting.

## Constraints

The toy regression task uses no biases or stochastic batching. Repeated passes increase exposure, not unique data. All numerical outputs remain finite; no claim that a toy trend transfers to language or DNA models.

## Example 1

Input

~~~json
{
  "train_x": [
    [
      -1
    ],
    [
      1
    ]
  ],
  "train_y": [
    -1,
    1
  ],
  "validation_x": [
    [
      -0.5
    ],
    [
      0.5
    ]
  ],
  "validation_y": [
    -0.5,
    0.5
  ],
  "weights": {
    "hidden": [
      [
        1
      ]
    ],
    "readout": [
      1
    ]
  },
  "lr": 0.2,
  "steps": 4,
  "decay": 0,
  "freeze_hidden": false
}
~~~

Output

~~~json
{
  "weights": {
    "hidden": [
      [
        1.0637855813781707
      ]
    ],
    "readout": [
      1.1165291041434482
    ]
  },
  "train": [
    0.028418673237222088,
    0.020435599507919375,
    0.014599708872711645,
    0.010375173668067953,
    0.007341149998679099
  ],
  "validation": [
    0.0007175548870314165,
    8.423128061935962e-05,
    3.800223402417856e-05,
    0.0003771813712991883,
    0.0009485664776793488
  ],
  "unique_examples": 2,
  "exposures": 8
}
~~~

Training and validation losses are measured separately.

## Example 2

Input

~~~json
{
  "train_x": [
    [
      -1
    ],
    [
      1
    ]
  ],
  "train_y": [
    -1,
    1
  ],
  "validation_x": [
    [
      -0.5
    ],
    [
      0.5
    ]
  ],
  "validation_y": [
    -0.5,
    0.5
  ],
  "weights": {
    "hidden": [
      [
        1
      ]
    ],
    "readout": [
      1
    ]
  },
  "lr": 0.2,
  "steps": 4,
  "decay": 0,
  "freeze_hidden": true
}
~~~

Output

~~~json
{
  "weights": {
    "hidden": [
      [
        1
      ]
    ],
    "readout": [
      1.1218773771612174
    ]
  },
  "train": [
    0.028418673237222088,
    0.02220768487692641,
    0.017354127107767608,
    0.013561329302968566,
    0.010597459112837614
  ],
  "validation": [
    0.0007175548870314165,
    0.00022264000946261252,
    1.963876614582634e-05,
    2.3436770219935466e-05,
    0.00016999438374831066
  ],
  "unique_examples": 2,
  "exposures": 8
}
~~~

Only the readout learns from fixed features.

## Part 1 · Trace a nonlinear predictor

One-hidden-layer regressor without biases: hidden=tanh(Wx), output=v·hidden. weights={hidden: H×D, readout:H}; inputs B×D. Return scalar predictions per row.

tiny_predict.py · tiny_predict(inputs, weights) — One-hidden-layer regressor without biases: hidden=tanh(Wx), output=v·hidden. weights={hidden: H×D, readout:H}; inputs B×D. Return scalar predictions per row.

## Part 2 · Differentiate both parameter families

Return {loss,hidden,readout}: loss=mean((prediction-target)^2)/2 and its gradients. All examples equally weighted; B>0. Differentiate tanh and both layers; input weights must remain unchanged.

tiny_gradient.py · tiny_gradient(inputs, targets, weights) — Return {loss,hidden,readout}: loss=mean((prediction-target)^2)/2 and its gradients. All examples equally weighted; B>0. Differentiate tanh and both layers; input weights must remain unchanged.

## Part 3 · Separate fitting, validation and frozen features

Full-batch SGD on tiny_gradient; add decay*w to EACH trainable parameter's gradient. Freeze hidden weights completely when requested, including decay. Report initial and post-update train/validation HALF-MSE (excluding regularization), final weights, and unique_examples=len(train_x), exposures=len(train_x)*steps. Validation never affects updates. Positive-sized train/validation sets; lr/decay>=0, steps>=0.

learning_curve.py · learning_curve(train_x, train_y, validation_x, validation_y, weights, lr, steps, decay, freeze_hidden) — Full-batch SGD on tiny_gradient; add decay*w to EACH trainable parameter's gradient. Freeze hidden weights completely when requested, including decay. Report initial and post-update train/validation HALF-MSE (excluding regularization), final weights, and unique_examples=len(train_x), exposures=len(train_x)*steps. Validation never affects updates. Positive-sized train/validation sets; lr/decay>=0, steps>=0.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Deep Learning Alchemy · assignment a6_generalization](https://deep-learning-alchemy.github.io/assets/assignments/a6_generalization.pdf)

- [Deep Learning Alchemy · assignment a2_hyperparameter_scaling](https://deep-learning-alchemy.github.io/assets/assignments/a2_hyperparameter_scaling.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-hyperparameter-scaling.html)

- [DL Systems · Homework 0 (original notebook)](https://github.com/dlsyscourse/hw0/blob/main/hw0.ipynb)


## Prediction and experimentation

1. Predict whether changing only validation labels can change trained weights.
2. Compare frozen features, full fine-tuning and decay with identical initial weights. Then change the number of passes without adding unique examples.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
