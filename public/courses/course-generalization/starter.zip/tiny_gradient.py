import math
import copy
import itertools
from collections import Counter
from tiny_predict import tiny_predict

def tiny_gradient(inputs, targets, weights):
    """Return {loss,hidden,readout}: loss=mean((prediction-target)^2)/2 and its gradients. All examples equally weighted; B>0. Differentiate tanh and both layers; input weights must remain unchanged."""
    raise NotImplementedError('tiny_gradient')
