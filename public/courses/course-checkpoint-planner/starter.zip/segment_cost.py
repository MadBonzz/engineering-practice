import math
import copy
import itertools
from collections import Counter


def segment_cost(activation_bytes, start, end):
    """For a chain with activation sizes a[0..L], a checkpoint segment [start,end] replays layers start..end-1. Return sum(a[start+1:end+1]), the replay tape bytes. 0<=start<end<=L."""
    raise NotImplementedError('segment_cost')
