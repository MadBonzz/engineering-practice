import math
import copy
import itertools
from collections import Counter
from segment_cost import segment_cost
from checkpoint_cost import checkpoint_cost

def choose_checkpoints(activation_bytes, budget):
    """Enumerate all checkpoint subsets for 1<=L<=10. Among plans with modeled peak<=budget, choose the fewest persistent bytes, then smaller peak, then lexicographically smallest boundaries. Return {boundaries,cost}, or null if none fits. Positive activation sizes and nonnegative budget."""
    raise NotImplementedError('choose_checkpoints')
