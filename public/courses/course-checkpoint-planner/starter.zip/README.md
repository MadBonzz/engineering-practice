# Fit an activation replay plan into a memory budget

A trainer has a chain of layers with uneven activation sizes. Build a planner that explicitly accounts for saved boundaries and replay storage.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Activation byte sizes for input and layer outputs, plus a memory budget.

## Output

A feasible checkpoint plan and its accounting, or null.

## Constraints

Use exactly the stated conservative liveness model. This is not a claim about PyTorch allocator peaks. L<=10 makes exhaustive search acceptable.

## Example 1

Input

~~~json
{
  "activation_bytes": [
    2,
    2,
    2,
    2,
    2
  ],
  "budget": 12
}
~~~

Output

~~~json
{
  "boundaries": [
    0,
    4
  ],
  "cost": {
    "persistent": 4,
    "scratch": 8,
    "peak": 12,
    "recomputed": 4
  }
}
~~~

The plan chooses a feasible persistent/replay tradeoff.

## Example 2

Input

~~~json
{
  "activation_bytes": [
    2,
    2,
    2,
    2,
    2
  ],
  "budget": 10
}
~~~

Output

~~~json
{
  "boundaries": [
    0,
    2,
    4
  ],
  "cost": {
    "persistent": 6,
    "scratch": 4,
    "peak": 10,
    "recomputed": 4
  }
}
~~~

A tighter budget can require an interior checkpoint.

## Part 1 · Account for a replay tape

For a chain with activation sizes a[0..L], a checkpoint segment [start,end] replays layers start..end-1. Return sum(a[start+1:end+1]), the replay tape bytes. 0<=start<end<=L.

segment_cost.py · segment_cost(activation_bytes, start, end) — For a chain with activation sizes a[0..L], a checkpoint segment [start,end] replays layers start..end-1. Return sum(a[start+1:end+1]), the replay tape bytes. 0<=start<end<=L.

## Part 2 · Measure simultaneous live state

Boundaries are strictly increasing, start at 0 and end at L. Persistent bytes=sum(a[b] for boundaries). Scratch is the largest segment replay tape. Return persistent,scratch,peak=persistent+scratch,recomputed=L. This conservative model counts boundary outputs in replay scratch too; parameter/gradient memory is excluded.

checkpoint_cost.py · checkpoint_cost(activation_bytes, boundaries) — Boundaries are strictly increasing, start at 0 and end at L. Persistent bytes=sum(a[b] for boundaries). Scratch is the largest segment replay tape. Return persistent,scratch,peak=persistent+scratch,recomputed=L. This conservative model counts boundary outputs in replay scratch too; parameter/gradient memory is excluded.

## Part 3 · Search feasible checkpoint plans

Enumerate all checkpoint subsets for 1<=L<=10. Among plans with modeled peak<=budget, choose the fewest persistent bytes, then smaller peak, then lexicographically smallest boundaries. Return {boundaries,cost}, or null if none fits. Positive activation sizes and nonnegative budget.

choose_checkpoints.py · choose_checkpoints(activation_bytes, budget) — Enumerate all checkpoint subsets for 1<=L<=10. Among plans with modeled peak<=budget, choose the fewest persistent bytes, then smaller peak, then lexicographically smallest boundaries. Return {boundaries,cost}, or null if none fits. Positive activation sizes and nonnegative budget.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A2, memory profiling and distributed training](https://github.com/stanford-cs336/assignment2-systems/blob/e495ed740080661ab084914674d3e10048778889/cs336_spring2025_assignment2_systems.pdf)

- [DL Systems · training large models](https://dlsyscourse.org/slides/15-training-large-models.pdf)


## Prediction and experimentation

1. Predict whether checkpointing every layer always minimizes peak memory in this model.
2. Compare uniform and alternating large/small activations under the same budget.

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
