import math
import copy
import itertools
from collections import Counter
from segment_cost import segment_cost

def checkpoint_cost(activation_bytes, boundaries):
    """Boundaries are strictly increasing, start at 0 and end at L. Persistent bytes=sum(a[b] for boundaries). Scratch is the largest segment replay tape. Return persistent,scratch,peak=persistent+scratch,recomputed=L. This conservative model counts boundary outputs in replay scratch too; parameter/gradient memory is excluded."""
    raise NotImplementedError('checkpoint_cost')
