import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_full_replay(self):
        args = [[2, 3, 5], 0, 2]
        expected = 8
        actual = trial('segment_cost.segment_cost', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_last_layer(self):
        args = [[2, 3, 5], 1, 2]
        expected = 5
        actual = trial('segment_cost.segment_cost', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_one_segment(self):
        args = [[2, 2, 2], [0, 2]]
        expected = {'peak': 8, 'persistent': 4, 'recomputed': 2, 'scratch': 4}
        actual = trial('checkpoint_cost.checkpoint_cost', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_every_boundary(self):
        args = [[2, 2, 2], [0, 1, 2]]
        expected = {'peak': 8, 'persistent': 6, 'recomputed': 2, 'scratch': 2}
        actual = trial('checkpoint_cost.checkpoint_cost', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_fewest_persistent_bytes(self):
        args = [[2, 2, 2], 8]
        expected = {'boundaries': [0, 2],
 'cost': {'peak': 8, 'persistent': 4, 'recomputed': 2, 'scratch': 4}}
        actual = trial('choose_checkpoints.choose_checkpoints', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_fit(self):
        args = [[2, 2, 2], 7]
        expected = None
        actual = trial('choose_checkpoints.choose_checkpoints', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

