import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'activation_bytes': [2, 2, 2, 2, 2], 'budget': 12}
        expected = {'boundaries': [0, 4],
 'cost': {'peak': 12, 'persistent': 4, 'recomputed': 4, 'scratch': 8}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'activation_bytes': [2, 2, 2, 2, 2], 'budget': 10}
        expected = {'boundaries': [0, 2, 4],
 'cost': {'peak': 10, 'persistent': 6, 'recomputed': 4, 'scratch': 4}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
