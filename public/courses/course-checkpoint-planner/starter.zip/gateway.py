"""JSON request boundary. Trace this caller before editing the implementation modules."""
from choose_checkpoints import choose_checkpoints


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return choose_checkpoints(**request)
