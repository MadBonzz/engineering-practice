import math
import copy
import itertools
from collections import Counter
from view_offsets import view_offsets
from gather_view import gather_view

def view_vjp(storage, shape, strides, offset, upstream):
    """Return {values, storage_gradient}. upstream has product(shape) entries in logical order. Scatter-add into a zero gradient of length len(storage), including aliased/broadcast entries."""
    raise NotImplementedError('view_vjp')
