import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_transpose_offsets(self):
        args = [[2, 2], [1, 2], 0]
        expected = [0, 2, 1, 3]
        actual = trial('view_offsets.view_offsets', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_reverse_offsets(self):
        args = [[3], [-1], 2]
        expected = [2, 1, 0]
        actual = trial('view_offsets.view_offsets', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_transpose_gather(self):
        args = [[10, 20, 30, 40], [2, 2], [1, 2], 0]
        expected = [10, 30, 20, 40]
        actual = trial('gather_view.gather_view', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_scalar_broadcast(self):
        args = [[4, 5], [3], [0], 1]
        expected = [5, 5, 5]
        actual = trial('gather_view.gather_view', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_broadcast_accumulation(self):
        args = [[2], [3], [0], 0, [1, 2, 3]]
        expected = {'storage_gradient': [6.0], 'values': [2, 2, 2]}
        actual = trial('view_vjp.view_vjp', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_reverse_vjp(self):
        args = [[1, 2], [2], [-1], 1, [3, 4]]
        expected = {'storage_gradient': [4.0, 3.0], 'values': [2, 1]}
        actual = trial('view_vjp.view_vjp', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

