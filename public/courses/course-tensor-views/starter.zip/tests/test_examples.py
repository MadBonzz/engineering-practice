import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'offset': 0,
 'shape': [2, 2],
 'storage': [1, 2, 3, 4],
 'strides': [1, 2],
 'upstream': [1, 2, 3, 4]}
        expected = {'storage_gradient': [1.0, 3.0, 2.0, 4.0], 'values': [1, 3, 2, 4]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'offset': 0,
 'shape': [2, 2],
 'storage': [7, 8],
 'strides': [0, 1],
 'upstream': [1, 2, 3, 4]}
        expected = {'storage_gradient': [4.0, 6.0], 'values': [7, 8, 7, 8]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
