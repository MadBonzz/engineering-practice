# Implement tensor views and their backward scatter

A tensor backend must expose transpose, slicing and broadcasting without copying storage. Implement the view boundary and its gradient transport.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

A flat storage buffer, shape, strides, base offset and upstream derivative.

## Output

Logical view values and a gradient over the original storage.

## Constraints

All shapes/strides have equal rank, and all accessed indices are valid. Zero-sized dimensions are legal; inputs are immutable.

## Example 1

Input

~~~json
{
  "storage": [
    1,
    2,
    3,
    4
  ],
  "shape": [
    2,
    2
  ],
  "strides": [
    1,
    2
  ],
  "offset": 0,
  "upstream": [
    1,
    2,
    3,
    4
  ]
}
~~~

Output

~~~json
{
  "values": [
    1,
    3,
    2,
    4
  ],
  "storage_gradient": [
    1.0,
    3.0,
    2.0,
    4.0
  ]
}
~~~

A transpose changes the placement of the gradient.

## Example 2

Input

~~~json
{
  "storage": [
    7,
    8
  ],
  "shape": [
    2,
    2
  ],
  "strides": [
    0,
    1
  ],
  "offset": 0,
  "upstream": [
    1,
    2,
    3,
    4
  ]
}
~~~

Output

~~~json
{
  "values": [
    7,
    8,
    7,
    8
  ],
  "storage_gradient": [
    4.0,
    6.0
  ]
}
~~~

Broadcasting sums contributions across rows.

## Part 1 · Interpret shape and strides

Return storage indices in logical row-major order for a strided view. Rank is 1–4; dimensions are nonnegative; strides may be zero or negative. All addressed storage indices are valid. Scalar views are out of scope.

view_offsets.py · view_offsets(shape, strides, offset) — Return storage indices in logical row-major order for a strided view. Rank is 1–4; dimensions are nonnegative; strides may be zero or negative. All addressed storage indices are valid. Scalar views are out of scope.

## Part 2 · Read transposed and broadcast views

Return flat logical values using the view's offsets. Broadcasting may reuse one storage element; do not infer strides from shape.

gather_view.py · gather_view(storage, shape, strides, offset) — Return flat logical values using the view's offsets. Broadcasting may reuse one storage element; do not infer strides from shape.

## Part 3 · Backpropagate through aliasing

Return {values, storage_gradient}. upstream has product(shape) entries in logical order. Scatter-add into a zero gradient of length len(storage), including aliased/broadcast entries.

view_vjp.py · view_vjp(storage, shape, strides, offset, upstream) — Return {values, storage_gradient}. upstream has product(shape) entries in logical order. Scatter-add into a zero gradient of length len(storage), including aliased/broadcast entries.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DL Systems · hardware acceleration and NDArray implementation](https://dlsyscourse.org/lectures/)

- [CS336 2025 · tensors and resource accounting](https://cs336.stanford.edu/spring2025/)

- [DL Systems · Homework 3 (original notebook)](https://github.com/dlsyscourse/hw3/blob/main/hw3.ipynb)


## Prediction and experimentation

1. Predict why a broadcast read can require a reduction in backward.
2. Compare contiguous and transposed views with identical storage. Which values and gradients change order?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
