import math
import copy
import itertools
from collections import Counter


def view_offsets(shape, strides, offset):
    """Return storage indices in logical row-major order for a strided view. Rank is 1–4; dimensions are nonnegative; strides may be zero or negative. All addressed storage indices are valid. Scalar views are out of scope."""
    raise NotImplementedError('view_offsets')
