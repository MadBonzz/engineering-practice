import math
import copy
import itertools
from collections import Counter
from view_offsets import view_offsets

def gather_view(storage, shape, strides, offset):
    """Return flat logical values using the view's offsets. Broadcasting may reuse one storage element; do not infer strides from shape."""
    raise NotImplementedError('gather_view')
