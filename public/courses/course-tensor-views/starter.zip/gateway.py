"""JSON request boundary. Trace this caller before editing the implementation modules."""
from view_vjp import view_vjp


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return view_vjp(**request)
