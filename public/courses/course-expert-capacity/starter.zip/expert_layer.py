import math
import copy
import itertools
from collections import Counter
from route_topk import route_topk
from capacity_dispatch import capacity_dispatch

def expert_layer(inputs, scores, experts, k, capacity):
    """Each expert is a D×D linear matrix; inputs is T×D, scores T×E. Dispatch and sum weight*(expert@input) for admitted assignments only. Return outputs, loads, dropped and utilization=admitted/(E*capacity), or 0 for zero capacity. No residual, expert bias or post-drop renormalization."""
    raise NotImplementedError('expert_layer')
