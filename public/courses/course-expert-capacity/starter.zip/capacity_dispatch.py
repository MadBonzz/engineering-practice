import math
import copy
import itertools
from collections import Counter
from route_topk import route_topk

def capacity_dispatch(scores, k, capacity):
    """Route with route_topk, then process tokens in input order and each token's experts in selected order. Each expert admits at most capacity assignments. Return assignments [{token,expert,weight}], loads and dropped count. Dropped probability mass is NOT renormalized. capacity>=0."""
    raise NotImplementedError('capacity_dispatch')
