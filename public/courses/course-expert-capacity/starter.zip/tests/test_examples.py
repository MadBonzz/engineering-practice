import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'capacity': 2,
 'experts': [[[1]], [[2]]],
 'inputs': [[1], [2], [3]],
 'k': 2,
 'scores': [[0, 0], [0, 0], [0, 0]]}
        expected = {'dropped': 2,
 'loads': [2, 2],
 'outputs': [[1.5], [3.0], [0.0]],
 'utilization': 1.0}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'capacity': 3,
 'experts': [[[1]], [[2]]],
 'inputs': [[1], [2], [3]],
 'k': 2,
 'scores': [[0, 0], [0, 0], [0, 0]]}
        expected = {'dropped': 0,
 'loads': [3, 3],
 'outputs': [[1.5], [3.0], [4.5]],
 'utilization': 1.0}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
