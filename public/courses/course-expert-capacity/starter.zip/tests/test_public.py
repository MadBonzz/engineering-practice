import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_tie_selection(self):
        args = [[[0, 0]], 1]
        expected = [{'experts': [0], 'weights': [1.0]}]
        actual = trial('route_topk.route_topk', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_equal_routes(self):
        args = [[[0, 0]], 2]
        expected = [{'experts': [0, 1], 'weights': [0.5, 0.5]}]
        actual = trial('route_topk.route_topk', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_one_expert_fills(self):
        args = [[[0, 0], [0, 0]], 1, 1]
        expected = {'assignments': [{'expert': 0, 'token': 0, 'weight': 1.0}],
 'dropped': 1,
 'loads': [1, 0]}
        actual = trial('capacity_dispatch.capacity_dispatch', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_zero_capacity(self):
        args = [[[0, 0]], 2, 0]
        expected = {'assignments': [], 'dropped': 2, 'loads': [0, 0]}
        actual = trial('capacity_dispatch.capacity_dispatch', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_overflow_token(self):
        args = [[[1], [2], [3]], [[0, 0], [0, 0], [0, 0]], [[[1]], [[2]]], 2, 2]
        expected = {'dropped': 2, 'loads': [2, 2], 'outputs': [[1.5], [3.0], [0.0]], 'utilization': 1.0}
        actual = trial('expert_layer.expert_layer', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_weighted_experts(self):
        args = [[[2]], [[0, 0]], [[[1]], [[3]]], 2, 1]
        expected = {'dropped': 0, 'loads': [1, 1], 'outputs': [[4.0]], 'utilization': 1.0}
        actual = trial('expert_layer.expert_layer', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

