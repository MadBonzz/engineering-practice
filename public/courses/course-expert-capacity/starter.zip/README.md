# Dispatch sparse experts without losing capacity accounting

A sparse model’s router is balanced on average but drops work in individual batches. Implement deterministic top-k routing, capacity admission and observable expert execution.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Token vectors, router scores, linear experts, top-k and per-expert capacity.

## Output

Expert outputs, admission counts, dropped assignments and utilization.

## Constraints

At least one token/expert; consistent positive width. This task models dispatch, not training a router or distributed all-to-all performance.

## Example 1

Input

~~~json
{
  "inputs": [
    [
      1
    ],
    [
      2
    ],
    [
      3
    ]
  ],
  "scores": [
    [
      0,
      0
    ],
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ],
  "experts": [
    [
      [
        1
      ]
    ],
    [
      [
        2
      ]
    ]
  ],
  "k": 2,
  "capacity": 2
}
~~~

Output

~~~json
{
  "outputs": [
    [
      1.5
    ],
    [
      3.0
    ],
    [
      0.0
    ]
  ],
  "loads": [
    2,
    2
  ],
  "dropped": 2,
  "utilization": 1.0
}
~~~

The last token loses both assignments when capacity is exhausted.

## Example 2

Input

~~~json
{
  "inputs": [
    [
      1
    ],
    [
      2
    ],
    [
      3
    ]
  ],
  "scores": [
    [
      0,
      0
    ],
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ],
  "experts": [
    [
      [
        1
      ]
    ],
    [
      [
        2
      ]
    ]
  ],
  "k": 2,
  "capacity": 3
}
~~~

Output

~~~json
{
  "outputs": [
    [
      1.5
    ],
    [
      3.0
    ],
    [
      4.5
    ]
  ],
  "loads": [
    3,
    3
  ],
  "dropped": 0,
  "utilization": 1.0
}
~~~

More capacity preserves all routed mass.

## Part 1 · Select and normalize sparse routes

For each token's finite expert-logit row select k highest scores (ties lower expert ID), then softmax only over the selected experts. Return [{experts,weights}] per token in descending-score order. 1<=k<=expert_count.

route_topk.py · route_topk(scores, k) — For each token's finite expert-logit row select k highest scores (ties lower expert ID), then softmax only over the selected experts. Return [{experts,weights}] per token in descending-score order. 1<=k<=expert_count.

## Part 2 · Enforce expert admission limits

Route with route_topk, then process tokens in input order and each token's experts in selected order. Each expert admits at most capacity assignments. Return assignments [{token,expert,weight}], loads and dropped count. Dropped probability mass is NOT renormalized. capacity>=0.

capacity_dispatch.py · capacity_dispatch(scores, k, capacity) — Route with route_topk, then process tokens in input order and each token's experts in selected order. Each expert admits at most capacity assignments. Return assignments [{token,expert,weight}], loads and dropped count. Dropped probability mass is NOT renormalized. capacity>=0.

## Part 3 · Combine admitted expert outputs

Each expert is a D×D linear matrix; inputs is T×D, scores T×E. Dispatch and sum weight*(expert@input) for admitted assignments only. Return outputs, loads, dropped and utilization=admitted/(E*capacity), or 0 for zero capacity. No residual, expert bias or post-drop renormalization.

expert_layer.py · expert_layer(inputs, scores, experts, k, capacity) — Each expert is a D×D linear matrix; inputs is T×D, scores T×E. Dispatch and sum weight*(expert@input) for admitted assignments only. Return outputs, loads, dropped and utilization=admitted/(E*capacity), or 0 for zero capacity. No residual, expert bias or post-drop renormalization.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Deep Learning Alchemy · assignment a5_capacity](https://deep-learning-alchemy.github.io/assets/assignments/a5_capacity.pdf)

- [Deep Learning Alchemy · prediction quiz](https://deep-learning-alchemy.github.io/quiz-capacity.html)

- [CS336 2025 · mixture-of-experts lecture](https://cs336.stanford.edu/spring2025/)


## Prediction and experimentation

1. Predict load and drops for tied router scores under top-one versus top-two routing.
2. Raise capacity without changing weights. Which token outputs can change, and why?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
