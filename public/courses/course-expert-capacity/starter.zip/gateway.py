"""JSON request boundary. Trace this caller before editing the implementation modules."""
from expert_layer import expert_layer


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return expert_layer(**request)
