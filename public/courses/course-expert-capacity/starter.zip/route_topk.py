import math
import copy
import itertools
from collections import Counter


def route_topk(scores, k):
    """For each token's finite expert-logit row select k highest scores (ties lower expert ID), then softmax only over the selected experts. Return [{experts,weights}] per token in descending-score order. 1<=k<=expert_count."""
    raise NotImplementedError('route_topk')
