# Make training and evaluation state agree

A model behaves differently after export because its normalization buffers and dropout mode are mishandled. Build a reproducible training/evaluation session.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Batch records, initial running mean/variance, momentum and epsilon.

## Output

Normalized and optionally dropped values plus the final state.

## Constraints

No random generator is needed: uniform draws are supplied. Batch sizes may vary. Valid nonempty feature rows; do not mutate state.

## Example 1

Input

~~~json
{
  "batches": [
    {
      "rows": [
        [
          1
        ],
        [
          3
        ]
      ],
      "training": true,
      "keep": 1.0,
      "uniform": [
        [
          0
        ],
        [
          0.5
        ]
      ]
    }
  ],
  "state": {
    "mean": [
      0.0
    ],
    "variance": [
      1.0
    ]
  },
  "momentum": 0.5,
  "epsilon": 3
}
~~~

Output

~~~json
{
  "outputs": [
    [
      [
        -0.5
      ],
      [
        0.5
      ]
    ]
  ],
  "state": {
    "mean": [
      1.0
    ],
    "variance": [
      1.0
    ]
  }
}
~~~

Statistics are updated during training.

## Example 2

Input

~~~json
{
  "batches": [
    {
      "rows": [
        [
          1
        ],
        [
          3
        ]
      ],
      "training": true,
      "keep": 1.0,
      "uniform": [
        [
          0
        ],
        [
          0.5
        ]
      ]
    },
    {
      "rows": [
        [
          1
        ],
        [
          3
        ]
      ],
      "training": false,
      "keep": 0.2,
      "uniform": [
        [
          0
        ],
        [
          0.5
        ]
      ]
    }
  ],
  "state": {
    "mean": [
      0.0
    ],
    "variance": [
      1.0
    ]
  },
  "momentum": 0.5,
  "epsilon": 3
}
~~~

Output

~~~json
{
  "outputs": [
    [
      [
        -0.5
      ],
      [
        0.5
      ]
    ],
    [
      [
        0.0
      ],
      [
        1.0
      ]
    ]
  ],
  "state": {
    "mean": [
      1.0
    ],
    "variance": [
      1.0
    ]
  }
}
~~~

Evaluation reads the accumulated state.

## Part 1 · Measure per-feature statistics

Return [column_means, population_variances] for nonempty B×D rows. Divide variance by B (not B-1), including B=1.

batch_stats.py · batch_stats(rows) — Return [column_means, population_variances] for nonempty B×D rows. Divide variance by B (not B-1), including B=1.

## Part 2 · Separate batch and running statistics

Return {values,state}. state has mean/variance vectors. Training uses current batch statistics and new_state=(1-momentum)*old+momentum*batch; eval uses old state unchanged. Normalize (x-mean)/sqrt(variance+epsilon). 0<=momentum<=1, epsilon>0; no affine gain/bias.

normalize_batch.py · normalize_batch(rows, state, training, momentum, epsilon) — Return {values,state}. state has mean/variance vectors. Training uses current batch statistics and new_state=(1-momentum)*old+momentum*batch; eval uses old state unchanged. Normalize (x-mean)/sqrt(variance+epsilon). 0<=momentum<=1, epsilon>0; no affine gain/bias.

## Part 3 · Compose state and stochastic layers

Process batches containing rows, training, keep and uniform. Normalize then inverted-dropout: in training keep a coordinate iff uniform<keep, scaling by 1/keep. In eval ignore uniform and dropout. keep is in (0,1]; uniform has rows' shape. Return outputs per batch and final running state.

norm_session.py · norm_session(batches, state, momentum, epsilon) — Process batches containing rows, training, keep and uniform. Normalize then inverted-dropout: in training keep a coordinate iff uniform<keep, scaling by 1/keep. In eval ignore uniform and dropout. keep is in (0,1]; uniform has rows' shape. Return outputs per batch and final running state.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DL Systems · normalization and regularization](https://dlsyscourse.org/slides/norm_reg.pdf)

- [DL Systems · Homework 2 (original notebook)](https://github.com/dlsyscourse/hw2/blob/main/hw2.ipynb)


## Prediction and experimentation

1. Predict the result when an evaluation example is placed beside a different example.
2. Hold draws fixed and compare keep=1 and keep=0.5. Why does train-mode output differ from eval-mode output?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
