import math
import copy
import itertools
from collections import Counter
from batch_stats import batch_stats
from normalize_batch import normalize_batch

def norm_session(batches, state, momentum, epsilon):
    """Process batches containing rows, training, keep and uniform. Normalize then inverted-dropout: in training keep a coordinate iff uniform<keep, scaling by 1/keep. In eval ignore uniform and dropout. keep is in (0,1]; uniform has rows' shape. Return outputs per batch and final running state."""
    raise NotImplementedError('norm_session')
