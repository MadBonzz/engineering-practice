"""JSON request boundary. Trace this caller before editing the implementation modules."""
from norm_session import norm_session


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return norm_session(**request)
