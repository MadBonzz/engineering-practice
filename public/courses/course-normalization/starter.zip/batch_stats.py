import math
import copy
import itertools
from collections import Counter


def batch_stats(rows):
    """Return [column_means, population_variances] for nonempty B×D rows. Divide variance by B (not B-1), including B=1."""
    raise NotImplementedError('batch_stats')
