import math
import copy
import itertools
from collections import Counter
from batch_stats import batch_stats

def normalize_batch(rows, state, training, momentum, epsilon):
    """Return {values,state}. state has mean/variance vectors. Training uses current batch statistics and new_state=(1-momentum)*old+momentum*batch; eval uses old state unchanged. Normalize (x-mean)/sqrt(variance+epsilon). 0<=momentum<=1, epsilon>0; no affine gain/bias."""
    raise NotImplementedError('normalize_batch')
