import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_one_feature(self):
        args = [[[1], [3]]]
        expected = [[2.0], [1.0]]
        actual = trial('batch_stats.batch_stats', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_singleton(self):
        args = [[[2, 4]]]
        expected = [[2.0, 4.0], [0.0, 0.0]]
        actual = trial('batch_stats.batch_stats', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_training_state_update(self):
        args = [[[1], [3]], {'mean': [0.0], 'variance': [1.0]}, True, 0.5, 3]
        expected = {'state': {'mean': [1.0], 'variance': [1.0]}, 'values': [[-0.5], [0.5]]}
        actual = trial('normalize_batch.normalize_batch', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_evaluation(self):
        args = [[[2]], {'mean': [0.0], 'variance': [1.0]}, False, 0.5, 3]
        expected = {'state': {'mean': [0.0], 'variance': [1.0]}, 'values': [[1.0]]}
        actual = trial('normalize_batch.normalize_batch', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_empty_session(self):
        args = [[], {'mean': [0.0], 'variance': [1.0]}, 0.5, 1]
        expected = {'outputs': [], 'state': {'mean': [0.0], 'variance': [1.0]}}
        actual = trial('norm_session.norm_session', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_no_dropout(self):
        args = [[{'keep': 1.0, 'rows': [[1], [3]], 'training': True, 'uniform': [[0], [0.5]]}],
 {'mean': [0.0], 'variance': [1.0]},
 1,
 3]
        expected = {'outputs': [[[-0.5], [0.5]]], 'state': {'mean': [2.0], 'variance': [1.0]}}
        actual = trial('norm_session.norm_session', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

