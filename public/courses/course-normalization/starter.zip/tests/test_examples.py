import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'batches': [{'keep': 1.0,
              'rows': [[1], [3]],
              'training': True,
              'uniform': [[0], [0.5]]}],
 'epsilon': 3,
 'momentum': 0.5,
 'state': {'mean': [0.0], 'variance': [1.0]}}
        expected = {'outputs': [[[-0.5], [0.5]]], 'state': {'mean': [1.0], 'variance': [1.0]}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'batches': [{'keep': 1.0,
              'rows': [[1], [3]],
              'training': True,
              'uniform': [[0], [0.5]]},
             {'keep': 0.2,
              'rows': [[1], [3]],
              'training': False,
              'uniform': [[0], [0.5]]}],
 'epsilon': 3,
 'momentum': 0.5,
 'state': {'mean': [0.0], 'variance': [1.0]}}
        expected = {'outputs': [[[-0.5], [0.5]], [[0.0], [1.0]]],
 'state': {'mean': [1.0], 'variance': [1.0]}}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
