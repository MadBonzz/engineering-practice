# Prediction and experiment notebook

## Before running
1. Predict the result when an evaluation example is placed beside a different example.
2. Hold draws fixed and compare keep=1 and keep=0.5. Why does train-mode output differ from eval-mode output?

For each comparison, write a prediction, confidence, and the mechanism you expect.

## Protocol
State the one variable changed, controls held fixed, initial state/seeds, and metric.
Implement the three parts and pass the public tests before interpreting a run.
Run `python experiment.py` locally, or use the editable JSON examples in the bench.
Edit `fixtures/experiments.json` locally to add a controlled intervention.

## Observations
Record the configuration and actual numerical result. Include failed predictions.

## Explanation and next test
Explain the discrepancy, propose a counterexample to your current explanation,
and name one limit on transferring this small experiment to a trained large model.

This notebook is saved/exported with your attempt. Coding checks grade implementation
behavior; they do not automatically assess the quality of your scientific explanation.
