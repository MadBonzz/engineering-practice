"""JSON request boundary. Trace this caller before editing the implementation modules."""
from policy_report import policy_report


def handle(request):
    """Evaluate an independent request; caller-owned input must remain unchanged."""
    return policy_report(**request)
