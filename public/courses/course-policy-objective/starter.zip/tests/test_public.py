import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_centered_group(self):
        args = [[[0, 2]], 1]
        expected = [[-0.5, 0.5]]
        actual = trial('group_advantages.group_advantages', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_equal_rewards(self):
        args = [[[3, 3], [1]], 1]
        expected = [[0.0, 0.0], [0.0]]
        actual = trial('group_advantages.group_advantages', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_positive_advantage(self):
        args = [[0.6931471805599453], [0], 1, [1], 0.2]
        expected = {'clipped_fraction': 1.0, 'objective': 1.2}
        actual = trial('clipped_objective.clipped_objective', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_negative_advantage(self):
        args = [[0.6931471805599453], [0], -1, [1], 0.2]
        expected = {'clipped_fraction': 1.0, 'objective': -2.0}
        actual = trial('clipped_objective.clipped_objective', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_integrated_objective(self):
        args = [[[0, 2]],
 [[{'mask': [1], 'new_logp': [0], 'old_logp': [0]},
   {'mask': [1], 'new_logp': [0.6931471805599453], 'old_logp': [0]}]],
 1,
 0.2]
        expected = {'advantages': [[-0.5, 0.5]],
 'details': [[{'clipped_fraction': 0.0, 'objective': -0.5},
              {'clipped_fraction': 1.0, 'objective': 0.6}]],
 'loss': -0.04999999999999999}
        actual = trial('policy_report.policy_report', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_2_empty_batch(self):
        args = [[], [], 1, 0.2]
        expected = {'advantages': [], 'details': [], 'loss': 0.0}
        actual = trial('policy_report.policy_report', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

