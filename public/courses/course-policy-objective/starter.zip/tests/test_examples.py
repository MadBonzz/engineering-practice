import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'clip': 0.2,
 'epsilon': 1,
 'rewards': [[0, 2]],
 'rollouts': [[{'mask': [1], 'new_logp': [0], 'old_logp': [0]},
               {'mask': [1],
                'new_logp': [0.6931471805599453],
                'old_logp': [0]}]]}
        expected = {'advantages': [[-0.5, 0.5]],
 'details': [[{'clipped_fraction': 0.0, 'objective': -0.5},
              {'clipped_fraction': 1.0, 'objective': 0.6}]],
 'loss': -0.04999999999999999}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'clip': 0.2,
 'epsilon': 1,
 'rewards': [[2, 0]],
 'rollouts': [[{'mask': [1], 'new_logp': [0], 'old_logp': [0]},
               {'mask': [1],
                'new_logp': [0.6931471805599453],
                'old_logp': [0]}]]}
        expected = {'advantages': [[0.5, -0.5]],
 'details': [[{'clipped_fraction': 0.0, 'objective': 0.5},
              {'clipped_fraction': 1.0, 'objective': -1.0}]],
 'loss': 0.25}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
