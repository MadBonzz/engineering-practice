import math
import copy
import itertools
from collections import Counter
from group_advantages import group_advantages

def clipped_objective(new_logp, old_logp, advantage, mask, clip):
    """For one rollout return {objective,clipped_fraction}. Per valid token use min(exp(new-old)*A, clamp(exp(new-old),1-clip,1+clip)*A), averaged over mask=1 tokens. clipped_fraction counts ratios outside the interval regardless of advantage. Empty valid set gives zeros. 0<clip<1; finite log-ratios in [-50,50]."""
    raise NotImplementedError('clipped_objective')
