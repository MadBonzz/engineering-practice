# Audit a group-relative policy update

A reasoning-model trainer reuses sampled responses across updates. Implement an auditable group-relative objective with response masking and sign-correct clipping.

## Implementation scope

A small, deterministic implementation using standard-library Python. No GPU, paid service or dataset download is needed. The workload checks behavior, not wall-clock speed.

## Input

Reward groups, old/current token log probabilities, masks, normalization epsilon and clipping width.

## Output

Group advantages, rollout objective diagnostics and a scalar loss.

## Constraints

This is an objective calculation, not a model trainer. It excludes KL, reward parsing and optimizer updates; no claims about achieving reasoning improvements.

## Example 1

Input

~~~json
{
  "rewards": [
    [
      0,
      2
    ]
  ],
  "rollouts": [
    [
      {
        "new_logp": [
          0
        ],
        "old_logp": [
          0
        ],
        "mask": [
          1
        ]
      },
      {
        "new_logp": [
          0.6931471805599453
        ],
        "old_logp": [
          0
        ],
        "mask": [
          1
        ]
      }
    ]
  ],
  "epsilon": 1,
  "clip": 0.2
}
~~~

Output

~~~json
{
  "advantages": [
    [
      -0.5,
      0.5
    ]
  ],
  "details": [
    [
      {
        "objective": -0.5,
        "clipped_fraction": 0.0
      },
      {
        "objective": 0.6,
        "clipped_fraction": 1.0
      }
    ]
  ],
  "loss": -0.04999999999999999
}
~~~

A positive-advantage ratio can hit the clipping ceiling.

## Example 2

Input

~~~json
{
  "rewards": [
    [
      2,
      0
    ]
  ],
  "rollouts": [
    [
      {
        "new_logp": [
          0
        ],
        "old_logp": [
          0
        ],
        "mask": [
          1
        ]
      },
      {
        "new_logp": [
          0.6931471805599453
        ],
        "old_logp": [
          0
        ],
        "mask": [
          1
        ]
      }
    ]
  ],
  "epsilon": 1,
  "clip": 0.2
}
~~~

Output

~~~json
{
  "advantages": [
    [
      0.5,
      -0.5
    ]
  ],
  "details": [
    [
      {
        "objective": 0.5,
        "clipped_fraction": 0.0
      },
      {
        "objective": -1.0,
        "clipped_fraction": 1.0
      }
    ]
  ],
  "loss": 0.25
}
~~~

Reversing reward order reverses the learning signal.

## Part 1 · Normalize within each prompt

Each inner reward list is one prompt's nonempty rollout group. Return (r-group_mean)/(population_std+epsilon) per group. epsilon>0; equal rewards yield zeros. Groups may have different sizes.

group_advantages.py · group_advantages(rewards, epsilon) — Each inner reward list is one prompt's nonempty rollout group. Return (r-group_mean)/(population_std+epsilon) per group. epsilon>0; equal rewards yield zeros. Groups may have different sizes.

## Part 2 · Apply sign-sensitive clipping

For one rollout return {objective,clipped_fraction}. Per valid token use min(exp(new-old)*A, clamp(exp(new-old),1-clip,1+clip)*A), averaged over mask=1 tokens. clipped_fraction counts ratios outside the interval regardless of advantage. Empty valid set gives zeros. 0<clip<1; finite log-ratios in [-50,50].

clipped_objective.py · clipped_objective(new_logp, old_logp, advantage, mask, clip) — For one rollout return {objective,clipped_fraction}. Per valid token use min(exp(new-old)*A, clamp(exp(new-old),1-clip,1+clip)*A), averaged over mask=1 tokens. clipped_fraction counts ratios outside the interval regardless of advantage. Empty valid set gives zeros. 0<clip<1; finite log-ratios in [-50,50].

## Part 3 · Aggregate rollout objectives

rollouts mirrors rewards' group structure; each rollout has new_logp,old_logp,mask. Compute group advantages and per-rollout objectives. Return advantages, details, loss=-mean(objective over ALL rollouts, including empty masks). This deliberately uses equal rollout weighting, not global-token weighting; no KL term.

policy_report.py · policy_report(rewards, rollouts, epsilon, clip) — rollouts mirrors rewards' group structure; each rollout has new_logp,old_logp,mask. Compute group advantages and per-rollout objectives. Return advantages, details, loss=-mean(objective over ALL rollouts, including empty masks). This deliberately uses equal rollout weighting, not global-token weighting; no KL term.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [CS336 2025 · A5, GRPO and masked reductions](https://github.com/stanford-cs336/assignment5-alignment/blob/master/cs336_spring2025_assignment5_alignment.pdf)

- [Deep Learning Alchemy · assignment a7_exotic_rl](https://deep-learning-alchemy.github.io/assets/assignments/a7_exotic_rl.pdf)


## Prediction and experimentation

1. Predict which clipping bound matters when advantage is negative.
2. Compare equal-rollout and equal-token reductions when response lengths differ. What behavior does each favor?

Open REFLECTION.md before running a comparison. Save a prediction, the controlled
change, the measured result, and your explanation. `python experiment.py` runs the
provided small experiments after implementation. These are original practice tasks
inspired by the linked courses, not reproductions of their assignments or quizzes.

## Files and validation

Implement the named functions in the three part modules. You may also edit
`tests/test_mine.py` and `REFLECTION.md`. The gateway, workload protocol, supplied
fixtures and public tests define the integration boundary. Inputs must not be mutated.
Inputs satisfy the documented preconditions; unspecified malformed inputs are not graded.
Numerical comparisons allow relative error 1e-7 or absolute error 1e-8.

Run all public tests: `python -m unittest discover -s tests`
Run one part: `python -m unittest discover -s tests -p test_public.py -k Part1`
Run examples: `python run_lab.py fixtures/example_1.json`
Exporting the attempt includes your code, notebook and experiment fixtures.
Private grading also exercises boundaries and cross-part behavior. A passing score
checks implementation correctness, not a claim that the toy model predicts real training.
