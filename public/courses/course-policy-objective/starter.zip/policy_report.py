import math
import copy
import itertools
from collections import Counter
from group_advantages import group_advantages
from clipped_objective import clipped_objective

def policy_report(rewards, rollouts, epsilon, clip):
    """rollouts mirrors rewards' group structure; each rollout has new_logp,old_logp,mask. Compute group advantages and per-rollout objectives. Return advantages, details, loss=-mean(objective over ALL rollouts, including empty masks). This deliberately uses equal rollout weighting, not global-token weighting; no KL term."""
    raise NotImplementedError('policy_report')
