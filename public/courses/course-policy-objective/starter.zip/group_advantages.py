import math
import copy
import itertools
from collections import Counter


def group_advantages(rewards, epsilon):
    """Each inner reward list is one prompt's nonempty rollout group. Return (r-group_mean)/(population_std+epsilon) per group. epsilon>0; equal rewards yield zeros. Groups may have different sizes."""
    raise NotImplementedError('group_advantages')
