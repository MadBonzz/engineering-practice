def project_state(state, vector):
    """Multiply a Dv × Dk matrix by a Dk vector, returning Dv dot products."""
    raise NotImplementedError('project_state')
