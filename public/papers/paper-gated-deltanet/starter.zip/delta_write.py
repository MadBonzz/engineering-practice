from state_read import project_state


def write(state, key, value, alpha, beta):
    """Return alpha*S + beta*(value - (alpha*S)@key) outer key with Dv rows and Dk columns."""
    raise NotImplementedError('write')
