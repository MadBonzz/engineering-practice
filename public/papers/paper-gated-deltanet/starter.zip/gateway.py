from token_mixer import mix


def handle(request):
    return mix(request["state"],request["events"])
