import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_rectangular_state_and_signed_query(self):
        args = [[[1, 0, 2], [3, -1, 1]], [2, 1, -1]]
        expected = [0, 4]
        actual = trial('state_read.project_state', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_oblique_unit_key_and_partial_correction(self):
        args = [[[2, 3]], [0.6, 0.8], [1], 0.5, 0.25]
        expected = [[0.88, 1.3399999999999999]]
        actual = trial('delta_write.write', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_independent_write_and_read_directions(self):
        args = [[[0, 0]],
 [{'alpha': 1, 'beta': 1, 'k': [1, 0], 'q': [0, 1], 'v': [3]},
  {'alpha': 1, 'beta': 1, 'k': [0, 1], 'q': [1, 0], 'v': [7]}]]
        expected = {'outputs': [[0], [3]], 'state': [[3, 7]]}
        actual = trial('token_mixer.mix', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

