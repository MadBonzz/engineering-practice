import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'events': [{'alpha': 0.5,
             'beta': 0.5,
             'k': [0, 1],
             'q': [0, 1],
             'v': [5, -1]}],
 'state': [[1, 2], [3, 4]]}
        expected = {'outputs': [[3, 0.5]], 'state': [[0.5, 3], [1.5, 0.5]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'events': [{'alpha': 0.25,
             'beta': 0,
             'k': [0, 1],
             'q': [1, 0],
             'v': [99]}],
 'state': [[4, -2]]}
        expected = {'outputs': [[1]], 'state': [[1, -0.5]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
