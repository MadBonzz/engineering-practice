from delta_write import write
from state_read import project_state


def mix(state, events):
    """Advance projected events in order and return {outputs, state} with one post-update read per event."""
    raise NotImplementedError('mix')
