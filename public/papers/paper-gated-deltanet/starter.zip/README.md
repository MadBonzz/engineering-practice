# Gated DeltaNet · implement the recurrent token mixer

A streaming language-model worker runs a token mixer with a fixed-size matrix state. Implement the gated delta recurrence and its readout. The worker must be able to checkpoint the matrix and continue with new projected tokens.

## Implementation scope

Implements the sequential matrix-state mixer of Gated DeltaNet for one head. The exercise starts with projected, normalized keys and precomputed gates. Short convolutions, normalization layers, multihead projections and the parallel training kernel are outside this recurrence.

## Input

state is a Dv × Dk matrix from the previous chunk. Each event has a query q and unit key k of width Dk, a value v of width Dv, retention alpha and write strength beta. q, k, v and activated gates are supplied by an upstream projection.

## Output

Return outputs as one Dv-dimensional vector per event and state as the final Dv × Dk matrix. Reading happens after the current write.

## Constraints

Use the value-by-key orientation of equation 10. First D = alpha S. Then p = D k and S' = D + beta (v−p) kᵀ. Emit S' q. Alpha and beta lie in [0,1]. Use the decayed matrix for the prediction, and allocate a fresh state so a caller can retain checkpoints.

## Example 1

Input

~~~json
{
  "state": [
    [
      1,
      2
    ],
    [
      3,
      4
    ]
  ],
  "events": [
    {
      "q": [
        0,
        1
      ],
      "k": [
        0,
        1
      ],
      "v": [
        5,
        -1
      ],
      "alpha": 0.5,
      "beta": 0.5
    }
  ]
}
~~~

Output

~~~json
{
  "outputs": [
    [
      3,
      0.5
    ]
  ],
  "state": [
    [
      0.5,
      3
    ],
    [
      1.5,
      0.5
    ]
  ]
}
~~~

After decay, the second column is [1,2]. Half the error to [5,−1] is [2,−1.5]. Add this correction only to the second column, then read that column.

## Example 2

Input

~~~json
{
  "state": [
    [
      4,
      -2
    ]
  ],
  "events": [
    {
      "q": [
        1,
        0
      ],
      "k": [
        0,
        1
      ],
      "v": [
        99
      ],
      "alpha": 0.25,
      "beta": 0
    }
  ]
}
~~~

Output

~~~json
{
  "outputs": [
    [
      1
    ]
  ],
  "state": [
    [
      1,
      -0.5
    ]
  ]
}
~~~

The gate retains one quarter of the old state. A zero write strength discards the proposed correction, and reading column one returns 1.

## Part 1 · Read the matrix-valued recurrent state

Return S·x. Rows correspond to value coordinates and columns to key coordinates. Use the same operation for a prediction from k and an output from q.

state_read.py · project_state(state, vector) — Multiply a Dv × Dk matrix by a Dk vector, returning Dv dot products.

## Part 2 · Correct a decayed prediction

Decay the entire state and predict the value aligned with the current key. Form the outer product of the prediction error and the key, scale by beta, and add it to the decayed state.

delta_write.py · write(state, key, value, alpha, beta) — Return alpha*S + beta*(value - (alpha*S)@key) outer key with Dv rows and Dk columns.

## Part 3 · Stream post-write outputs

Run write once per token and read the updated state along the supplied query. Keep the final matrix so a later request can continue exactly at the boundary.

token_mixer.py · mix(state, events) — Advance projected events in order and return {outputs, state} with one post-update read per event.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Yang, Kautz and Hatamizadeh · Gated Delta Networks, §3.1](https://arxiv.org/html/2412.06464v3)
