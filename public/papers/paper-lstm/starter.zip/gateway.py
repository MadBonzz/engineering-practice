from padded_scan import scan


def handle(request):
    return scan(request["h0"],request["c0"],request["recurrent"],request["drives"],request["active"])
