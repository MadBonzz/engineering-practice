from packed_gates import unpack
from cell_state import advance


def scan(h0, c0, recurrent, drives, active):
    """Run active drives, hold both states on padding, return {trace,h,c} including holds in trace."""
    raise NotImplementedError('scan')
