# LSTM · carry hidden and cell state through padded streams

Complete an LSTM inference worker that can pause for padding and later resume from exactly the state it last emitted. A user needs both the visible trace and the internal cell state for a continuation.

## Implementation scope

Implements a single-layer, forget-gated LSTM forward scan from preprojected inputs. The original LSTM introduced the cell and multiplicative gates. The later forget-gate paper supplies the retention mechanism used here.

## Input

h0 and c0 each have H components. recurrent is a shared 4H × H matrix. Each drive is the precomputed input projection plus bias, a vector of length 4H in input, forget, candidate, output order. active is a Boolean per drive.

## Output

Return trace with one hidden vector per drive (including held steps), and final hidden h and cell c. Return the incoming state when there are no drives.

## Constraints

For active drives compute pre = drive + recurrent × previous_h, split it into four contiguous blocks of width H, then use sigmoid on i, f, o and tanh on g. Apply c' = f ⊙ c + i ⊙ g and h' = o ⊙ tanh(c'). A false mask holds both states and emits a copy of h. No peepholes or projection layer.

## Example 1

Input

~~~json
{
  "h0": [
    0
  ],
  "c0": [
    1
  ],
  "recurrent": [
    [
      0.0
    ],
    [
      0.0
    ],
    [
      0.0
    ],
    [
      0.0
    ]
  ],
  "drives": [
    [
      0,
      0,
      0,
      0
    ],
    [
      4,
      4,
      4,
      4
    ]
  ],
  "active": [
    true,
    false
  ]
}
~~~

Output

~~~json
{
  "trace": [
    [
      0.23105857863000487
    ],
    [
      0.23105857863000487
    ]
  ],
  "h": [
    0.23105857863000487
  ],
  "c": [
    0.5
  ]
}
~~~

The active step sets every sigmoid gate to 0.5 and the candidate to zero. The cell decays from 1 to 0.5 and h becomes 0.5 tanh(0.5). Padding repeats that result.

## Example 2

Input

~~~json
{
  "h0": [
    0.2,
    -0.3
  ],
  "c0": [
    1,
    -2
  ],
  "recurrent": [
    [
      0.2,
      -0.1
    ],
    [
      0,
      1
    ],
    [
      1,
      0.5
    ],
    [
      -0.7,
      0
    ],
    [
      0.25,
      0.5
    ],
    [
      -1,
      0.3
    ],
    [
      1,
      0
    ],
    [
      0,
      -1
    ]
  ],
  "drives": [],
  "active": []
}
~~~

Output

~~~json
{
  "trace": [],
  "h": [
    0.2,
    -0.3
  ],
  "c": [
    1,
    -2
  ]
}
~~~

An empty continuation returns both incoming state vectors intact.

## Part 1 · Decode a fused gate projection

Add each row's recurrent contribution to its drive. Split contiguous blocks and apply each block's activation.

packed_gates.py · unpack(drive, recurrent, previous_h) — Return four length-H vectors [i,f,g,o] after adding recurrent × previous_h to the 4H drive.

## Part 2 · Update memory and expose a hidden vector

Update the cell coordinatewise using the write and forget gates. Gate the tanh of the new cell to produce h.

cell_state.py · advance(previous_c, gates) — Given length-H c and activated [i,f,g,o], return [new_h, new_c] without changing either input.

## Part 3 · Resume correctly across padding

Run both kernels in sequence on active steps. Holding a padded step must preserve h and c even when drive values are large.

padded_scan.py · scan(h0, c0, recurrent, drives, active) — Run active drives, hold both states on padding, return {trace,h,c} including holds in trace.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Hochreiter and Schmidhuber · Long Short-Term Memory](https://pubmed.ncbi.nlm.nih.gov/9377276/)

- [Gers, Schmidhuber and Cummins · Learning to Forget](https://pubmed.ncbi.nlm.nih.gov/11032042/)
