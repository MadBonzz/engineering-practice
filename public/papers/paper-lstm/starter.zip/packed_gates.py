from math import tanh
from numerics import dot, sigmoid


def unpack(drive, recurrent, previous_h):
    """Return four length-H vectors [i,f,g,o] after adding recurrent × previous_h to the 4H drive."""
    raise NotImplementedError('unpack')
