import math


def sigmoid(x):
    if x >= 0:
        return 1 / (1 + math.exp(-x))
    e = math.exp(x)
    return e / (1 + e)


def softplus(x):
    return max(x, 0) + math.log1p(math.exp(-abs(x)))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))
