import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_off_diagonal_recurrent_weights_mix_hidden_features(self):
        args = [[0, 0, 0, 0, 0, 0, 0, 0],
 [[0.2, -0.1], [0, 1], [1, 0.5], [-0.7, 0], [0.25, 0.5], [-1, 0.3], [1, 0], [0, -1]],
 [1, -0.5]]
        expected = [[0.5621765008857981, 0.37754066879814546],
 [0.679178699175393, 0.33181222783183395],
 [0.0, -0.8177540779702877],
 [0.7310585786300049, 0.6224593312018546]]
        actual = trial('packed_gates.unpack', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_retain_replace_and_close_the_output_gate(self):
        args = [[3, -1], [[0, 1], [1, 0], [0.5, -0.25], [1, 0]]]
        expected = [[0.9950547536867305, -0.0], [3.0, -0.25]]
        actual = trial('cell_state.advance', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_distinguish_a_held_step_from_an_all_zero_drive(self):
        args = [[1], [2], [[0.0], [0.0], [0.0], [0.0]], [[0, 0, 0, 0], [0, 0, 0, 0]], [False, True]]
        expected = {'c': [1.0], 'h': [0.3807970779778824], 'trace': [[1], [0.3807970779778824]]}
        actual = trial('padded_scan.scan', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

