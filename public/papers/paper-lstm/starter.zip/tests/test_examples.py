import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'active': [True, False],
 'c0': [1],
 'drives': [[0, 0, 0, 0], [4, 4, 4, 4]],
 'h0': [0],
 'recurrent': [[0.0], [0.0], [0.0], [0.0]]}
        expected = {'c': [0.5],
 'h': [0.23105857863000487],
 'trace': [[0.23105857863000487], [0.23105857863000487]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'active': [],
 'c0': [1, -2],
 'drives': [],
 'h0': [0.2, -0.3],
 'recurrent': [[0.2, -0.1],
               [0, 1],
               [1, 0.5],
               [-0.7, 0],
               [0.25, 0.5],
               [-1, 0.3],
               [1, 0],
               [0, -1]]}
        expected = {'c': [1, -2], 'h': [0.2, -0.3], 'trace': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
