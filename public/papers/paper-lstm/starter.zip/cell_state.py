from math import tanh


def advance(previous_c, gates):
    """Given length-H c and activated [i,f,g,o], return [new_h, new_c] without changing either input."""
    raise NotImplementedError('advance')
