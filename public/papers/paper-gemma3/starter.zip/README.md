# Gemma 3 · stream a mixed-window attention layer

A text-serving worker must advance a single Gemma 3 attention layer token by token. Five local layers are followed by one global layer. Implement the retention policy and grouped-query read, then verify that head sharing and cache eviction preserve the layer’s causal contexts.

## Implementation scope

The text decoder’s 5-local/1-global topology, chronological KV eviction and grouped-query attention. This is one layer given projected queries, keys and values. The full multimodal encoder, surrounding residual/MLP stack and training are outside the lab.

## Input

layer is zero-based and window includes the current token. Each packet supplies projected q [Hq,d], k [Hkv,d] and v [Hkv,dv] for one arriving token. Q/K normalization and rotary position have already been applied upstream. The first packet starts a fresh sequence.

## Output

Return mode ('local' or 'global'), contexts [T,Hq,dv], and retained, the cache length immediately after each packet. Empty input returns empty histories.

## Constraints

Layers with layer % 6 == 5 use global attention. All others retain the most recent window packets in chronological order. Hq is a positive multiple of Hkv. Contiguous groups of Hq/Hkv query heads share a KV head. Scores use q·k/sqrt(d).

## Example 1

Input

~~~json
{
  "layer": 4,
  "window": 2,
  "packets": [
    {
      "q": [
        [
          0
        ],
        [
          0
        ]
      ],
      "k": [
        [
          0
        ]
      ],
      "v": [
        [
          1
        ]
      ]
    },
    {
      "q": [
        [
          0
        ],
        [
          0
        ]
      ],
      "k": [
        [
          0
        ]
      ],
      "v": [
        [
          3
        ]
      ]
    },
    {
      "q": [
        [
          0
        ],
        [
          0
        ]
      ],
      "k": [
        [
          0
        ]
      ],
      "v": [
        [
          11
        ]
      ]
    }
  ]
}
~~~

Output

~~~json
{
  "mode": "local",
  "contexts": [
    [
      [
        1
      ],
      [
        1
      ]
    ],
    [
      [
        2
      ],
      [
        2
      ]
    ],
    [
      [
        7
      ],
      [
        7
      ]
    ]
  ],
  "retained": [
    1,
    2,
    2
  ]
}
~~~

Identical zero queries average the retained values. At the third arrival the local window holds only 3 and 11, giving 7.

## Example 2

Input

~~~json
{
  "layer": 5,
  "window": 1,
  "packets": [
    {
      "q": [
        [
          0
        ],
        [
          0
        ]
      ],
      "k": [
        [
          0
        ]
      ],
      "v": [
        [
          2
        ]
      ]
    },
    {
      "q": [
        [
          0
        ],
        [
          0
        ]
      ],
      "k": [
        [
          0
        ]
      ],
      "v": [
        [
          10
        ]
      ]
    }
  ]
}
~~~

Output

~~~json
{
  "mode": "global",
  "contexts": [
    [
      [
        2
      ],
      [
        2
      ]
    ],
    [
      [
        6
      ],
      [
        6
      ]
    ]
  ],
  "retained": [
    1,
    2
  ]
}
~~~

The sixth layer retains both values despite a local window setting of one. Its second output averages 2 and 10.

## Part 1 · Enforce the layer’s memory policy

Make local cache memory bounded across arrivals while keeping all previous keys and values at global layers.

retention.py · append_packet(entries, keys, values, layer, window) — Return a new chronological list of [keys,values] entries after this token. Global layers retain all, local layers only the newest window. Do not mutate entries.

## Part 2 · Read shared KV heads

Implement a separate scaled softmax over retained token positions for each query head. A contiguous group shares keys and values but can produce different contexts.

grouped_read.py · read(queries, entries) — Return one value-width context per query head. Each cache entry is [K,V], each indexed by KV head. Consecutive equal-sized groups of query heads share one KV head.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Gemma Team · Gemma 3 Technical Report, section 2](https://arxiv.org/html/2503.19786v1)
