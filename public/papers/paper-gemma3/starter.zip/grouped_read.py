import math
from tiny_ops import dot, softmax, mix


def read(queries, entries):
    """Return one value-width context per query head. Each cache entry is [K,V], each indexed by KV head. Consecutive equal-sized groups of query heads share one KV head."""
    raise NotImplementedError('read')
