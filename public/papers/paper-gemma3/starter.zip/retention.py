def append_packet(entries, keys, values, layer, window):
    """Return a new chronological list of [keys,values] entries after this token. Global layers retain all, local layers only the newest window. Do not mutate entries."""
    raise NotImplementedError('append_packet')
