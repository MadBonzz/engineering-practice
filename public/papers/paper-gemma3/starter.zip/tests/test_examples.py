import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'layer': 4,
 'packets': [{'k': [[0]], 'q': [[0], [0]], 'v': [[1]]},
             {'k': [[0]], 'q': [[0], [0]], 'v': [[3]]},
             {'k': [[0]], 'q': [[0], [0]], 'v': [[11]]}],
 'window': 2}
        expected = {'contexts': [[[1], [1]], [[2], [2]], [[7], [7]]],
 'mode': 'local',
 'retained': [1, 2, 2]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'layer': 5,
 'packets': [{'k': [[0]], 'q': [[0], [0]], 'v': [[2]]},
             {'k': [[0]], 'q': [[0], [0]], 'v': [[10]]}],
 'window': 1}
        expected = {'contexts': [[[2], [2]], [[6], [6]]],
 'mode': 'global',
 'retained': [1, 2]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
