import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_trim_oldest_entry(self):
        args = [[[[[0]], [[1]]], [[[1]], [[2]]]], [[3]], [[4]], 1, 2]
        expected = [[[[1]], [[2]]], [[[3]], [[4]]]]
        actual = trial('retention.append_packet', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_contiguous_head_groups_and_different_queries(self):
        args = [[[0], [1], [0], [-1]], [[[[1], [0]], [[3], [7]]], [[[0], [2]], [[2], [9]]]]]
        expected = [[2.5], [2.7310585786300052], [8.0], [7.238405844044234]]
        actual = trial('grouped_read.read', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

