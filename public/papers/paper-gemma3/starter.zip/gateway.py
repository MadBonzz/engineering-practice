from retention import append_packet
from grouped_read import read


def handle(request):
    layer,window=request["layer"],request["window"]
    history,retained,contexts=[],[],[]
    for p in request["packets"]:
        history=append_packet(history,p["k"],p["v"],layer,window)
        retained.append(len(history))
        contexts.append(read(p["q"],history))
    return {"mode":"global" if layer%6==5 else "local","contexts":contexts,"retained":retained}
