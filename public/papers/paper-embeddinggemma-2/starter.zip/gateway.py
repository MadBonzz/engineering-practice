from student_step import step
def handle(request):
    return step(request["students"],request["teachers"],request["dims"],request["lr"])
