# EmbeddingGemma 2 · Distill nested embedding widths

A training worker must align a student's multimodal representations with frozen teacher vectors at several output widths. Implement direct embedding matching and backpropagate through each prefix's normalization. Use the gradients for one update of the supplied student outputs.

## Implementation scope

Implements the direct distillation and Matryoshka prefix mechanisms of the EmbeddingGemma 2 report for a batch of paired vectors. The exercise uses equal prefix weights and optimizes student vectors directly. Modality encoders, negative sampling and retrieval are outside the lab.

## Input

students and teachers are equally sized nonempty batches of raw vectors. A teacher vector may be wider than its student counterpart. dims is a nonempty list of distinct positive prefix widths valid for both. lr is a nonnegative step size.

## Output

Return loss as the mean squared Euclidean distance between normalized student/teacher prefixes, averaging over examples and widths but summing over coordinates. Return students after one simultaneous gradient descent step on this loss.

## Constraints

Normalize each truncated prefix independently. Every selected prefix has positive norm. A coordinate outside a given prefix receives zero gradient from that term. Treat teachers as constants and evaluate all terms at the original students.

## Example 1

Input

~~~json
{
  "students": [
    [
      1,
      0
    ]
  ],
  "teachers": [
    [
      0,
      1,
      9
    ]
  ],
  "dims": [
    2
  ],
  "lr": 0.5
}
~~~

Output

~~~json
{
  "loss": 2,
  "students": [
    [
      1,
      1
    ]
  ]
}
~~~

The normalized vectors are orthogonal, so their squared distance is 2. Removing the radial component yields gradient [0,-2]. A half-step adds 1 to the second coordinate.

## Example 2

Input

~~~json
{
  "students": [
    [
      1,
      0
    ]
  ],
  "teachers": [
    [
      1,
      1
    ]
  ],
  "dims": [
    1,
    2
  ],
  "lr": 1
}
~~~

Output

~~~json
{
  "loss": 0.2928932188134525,
  "students": [
    [
      1,
      0.7071067811865476
    ]
  ]
}
~~~

The width-one vectors agree. At width two the distance is 2−√2. Averaging the two losses and gradients gives loss 1−1/√2 and moves the second coordinate by 1/√2.

## Part 1 · Differentiate embedding matching

Truncate then normalize both vectors. Compute the distance and the gradient with respect to the unnormalized student prefix.

prefix_distill.py · match(student, teacher, k) — Return [loss,grad] for one width-k prefix pair. For u=x/||x|| and t=y/||y||, loss=sum((u-t)^2) and grad=2*((u-t)-u*dot(u,u-t))/||x||. Return a k-vector gradient.

## Part 2 · Train at overlapping widths

Accumulate overlapping prefix gradients in the full-width student, average over batch and widths, then make one simultaneous update.

student_step.py · step(students, teachers, dims, lr) — Return {loss,students}. Average prefix losses over batch and dims, sum contributions to shared student coordinates, and update all raw vectors once with learning rate lr.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Google DeepMind · EmbeddingGemma 2 technical report, §2.4 and equation 6](https://arxiv.org/abs/2610.37364)

- [Google · EmbeddingGemma 2 model card](https://ai.google.dev/gemma/docs/embeddinggemma/model_card_2)
