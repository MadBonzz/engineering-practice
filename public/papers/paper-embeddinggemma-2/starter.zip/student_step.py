from prefix_distill import match

def step(students, teachers, dims, lr):
    """Return {loss,students}. Average prefix losses over batch and dims, sum contributions to shared student coordinates, and update all raw vectors once with learning rate lr."""
    raise NotImplementedError('step')
