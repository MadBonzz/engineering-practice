import math

def match(student, teacher, k):
    """Return [loss,grad] for one width-k prefix pair. For u=x/||x|| and t=y/||y||, loss=sum((u-t)^2) and grad=2*((u-t)-u*dot(u,u-t))/||x||. Return a k-vector gradient."""
    raise NotImplementedError('match')
