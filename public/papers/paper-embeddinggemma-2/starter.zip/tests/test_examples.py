import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'dims': [2], 'lr': 0.5, 'students': [[1, 0]], 'teachers': [[0, 1, 9]]}
        expected = {'loss': 2, 'students': [[1, 1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'dims': [1, 2], 'lr': 1, 'students': [[1, 0]], 'teachers': [[1, 1]]}
        expected = {'loss': 0.2928932188134525, 'students': [[1, 0.7071067811865476]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
