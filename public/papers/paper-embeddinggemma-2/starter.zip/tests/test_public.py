import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_tangent_space_normalization_derivative(self):
        args = [[2, 0], [-2, 1, 8], 2]
        expected = [3.7888543819998315, [0.0, -0.4472135954999579]]
        actual = trial('prefix_distill.match', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_batch_gradient_scaling(self):
        args = [[[1, 0], [2, 1]], [[1, 2], [1, -2]], [2], 0.2]
        expected = {'loss': 1.5527864045000421,
 'students': [[1.0, 0.17888543819998318], [2.04, 0.9199999999999999]]}
        actual = trial('student_step.step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

