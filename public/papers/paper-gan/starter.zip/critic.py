from layers import sigmoid


def discriminator_step(real, fake, discriminator, lr):
    """Return updated [slope,bias] for mean real BCE plus mean fake BCE."""
    raise NotImplementedError('discriminator_step')
