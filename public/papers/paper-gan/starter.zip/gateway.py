from layers import synthesize
from critic import discriminator_step
from producer import generator_step


def handle(request):
    g, d = request["generator"], request["discriminator"]
    for batch in request["rounds"]:
        noise = batch["noise"]
        d = discriminator_step(batch["real"], synthesize(noise, g), d, request["lr_d"])
        g = generator_step(noise, g, d, request["lr_g"])
    return {"generator":g,"discriminator":d,"samples":synthesize(request["probe"],g)}
