# GAN · alternate discriminator and generator updates

A one-dimensional data generator is frozen whenever the discriminator trains. Implement both optimizers so a complete round moves the generator toward examples the newly updated discriminator would call real.

## Implementation scope

Run the complete alternating, non-saturating GAN training loop on one-dimensional affine models. Fixed noise batches expose update order, class weighting and saturation without requiring image data.

## Input

generator and discriminator are [slope,bias] pairs. Each entry in rounds holds a nonempty real batch and a nonempty noise batch. lr_d and lr_g are independent learning rates. probe lists noise values for a final synthesis.

## Output

Return both final parameter pairs and samples generated from probe after all rounds. An empty list of rounds returns the original model predictions.

## Constraints

G(z)=g*z+c and D(v)=sigmoid(d*v+b). Minimize the sum of mean binary cross-entropies for real and fake batches in the discriminator step. Use −mean(log D(G(z))) for the generator step. Reuse that round’s noise and the updated discriminator. Gradients within either step are simultaneous.

## Example 1

Input

~~~json
{
  "generator": [
    0,
    0
  ],
  "discriminator": [
    0,
    0
  ],
  "lr_d": 1,
  "lr_g": 1,
  "rounds": [
    {
      "real": [
        2
      ],
      "noise": [
        0
      ]
    }
  ],
  "probe": [
    -1,
    2
  ]
}
~~~

Output

~~~json
{
  "generator": [
    0,
    0.5
  ],
  "discriminator": [
    1,
    0
  ],
  "samples": [
    0.5,
    0.5
  ]
}
~~~

The discriminator starts at probability 0.5 and learns slope 1. With that new slope the generator bias moves to 0.5. Noise zero gives the generator slope no gradient.

## Example 2

Input

~~~json
{
  "generator": [
    2,
    -1
  ],
  "discriminator": [
    0,
    0
  ],
  "lr_d": 1,
  "lr_g": 1,
  "rounds": [
    {
      "real": [
        1,
        1
      ],
      "noise": [
        1
      ]
    }
  ],
  "probe": [
    0,
    3
  ]
}
~~~

Output

~~~json
{
  "generator": [
    2,
    -1
  ],
  "discriminator": [
    0,
    0
  ],
  "samples": [
    -1,
    5
  ]
}
~~~

Every real and fake sample equals 1. The population-mean discriminator gradients cancel, so the zero discriminator slope leaves the generator unchanged.

## Part 1 · Separate the discriminator's two populations

Compute the discriminator gradient for real labels 1 and fake labels 0. Average each population separately before summing the two gradients.

critic.py · discriminator_step(real, fake, discriminator, lr) — Return updated [slope,bias] for mean real BCE plus mean fake BCE.

## Part 2 · Backpropagate through a frozen discriminator

Differentiate the non-saturating generator loss through the fixed discriminator slope. Return new generator parameters only.

producer.py · generator_step(noise, generator, discriminator, lr) — Return updated [slope,bias] under the mean non-saturating generator loss.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Goodfellow et al. · Generative Adversarial Networks](https://arxiv.org/abs/1406.2661)
