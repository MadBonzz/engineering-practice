import math


def sigmoid(value):
    if value >= 0:
        return 1.0 / (1.0 + math.exp(-value))
    e = math.exp(value)
    return e / (1.0 + e)


def synthesize(noise, generator):
    return [generator[0]*z + generator[1] for z in noise]
