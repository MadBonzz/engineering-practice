from layers import sigmoid


def generator_step(noise, generator, discriminator, lr):
    """Return updated [slope,bias] under the mean non-saturating generator loss."""
    raise NotImplementedError('generator_step')
