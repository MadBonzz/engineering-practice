import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_unequal_population_sizes(self):
        args = [[1, -2], [0], [0.3, -0.1], 0.2]
        expected = [0.21137904583511896, -0.08316878501864321]
        actual = trial('critic.discriminator_step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_non_saturating_gradient_sign(self):
        args = [[1, -3], [0.2, 1], [-0.7, 0.4], 0.3]
        expected = [0.2841941254657759, 0.886779027206896]
        actual = trial('producer.generator_step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

