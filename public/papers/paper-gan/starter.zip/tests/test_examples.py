import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'discriminator': [0, 0],
 'generator': [0, 0],
 'lr_d': 1,
 'lr_g': 1,
 'probe': [-1, 2],
 'rounds': [{'noise': [0], 'real': [2]}]}
        expected = {'discriminator': [1, 0], 'generator': [0, 0.5], 'samples': [0.5, 0.5]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'discriminator': [0, 0],
 'generator': [2, -1],
 'lr_d': 1,
 'lr_g': 1,
 'probe': [0, 3],
 'rounds': [{'noise': [1], 'real': [1, 1]}]}
        expected = {'discriminator': [0, 0], 'generator': [2, -1], 'samples': [-1, 5]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
