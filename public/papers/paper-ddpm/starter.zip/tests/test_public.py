import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_multiply_independent_retention_fractions(self):
        args = [[0.1, 0.2, 0.3]]
        expected = [1.0, 0.9, 0.7200000000000001, 0.504]
        actual = trial('noise_path.products', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_final_step_suppresses_sampling_noise(self):
        args = [[1, -2], [0.5, 0], [9, -1], 0.2, 1, 0.8]
        expected = [0.8680339887498948, -2.23606797749979]
        actual = trial('reverse_path.reverse_step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

