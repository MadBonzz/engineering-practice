import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'betas': [0.75],
 'clean': [2],
 'denoiser': [[2, 0]],
 'epsilon': [0],
 'mode': 'loss',
 't': 1}
        expected = {'mse': 4, 'noisy': [1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'betas': [0.75, 0.75],
 'denoiser': [[0, 0], [0, 0]],
 'draws': [[999], [1]],
 'mode': 'sample',
 'terminal': [0]}
        expected = {'sample': [1.5491933384829668],
 'trajectory': [[0.7745966692414834], [1.5491933384829668]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
