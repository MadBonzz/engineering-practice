def predict(state, coefficients):
    """A tiny time-conditioned affine noise model for the exercise."""
    weight, bias = coefficients
    return [weight*x+bias for x in state]
