from noise_path import products, corrupt
from noise_net import predict
from reverse_path import reverse_step


def handle(request):
    betas, net = request["betas"], request["denoiser"]
    bars = products(betas)
    if request["mode"] == "loss":
        t, noise = request["t"], request["epsilon"]
        noisy = corrupt(request["clean"], noise, bars[t])
        predicted = predict(noisy,net[t-1])
        return {"noisy":noisy,"mse":sum((a-b)**2 for a,b in zip(noise,predicted))/len(noise)}
    state = request["terminal"][:]
    trajectory = []
    for t in range(len(betas),0,-1):
        eps = predict(state, net[t-1])
        state = reverse_step(state, eps, request["draws"][t-1], betas[t-1], bars[t-1], bars[t])
        trajectory.append(state)
    return {"trajectory":trajectory,"sample":state}
