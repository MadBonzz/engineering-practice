# DDPM · corrupt a signal and run its reverse chain

A diffusion experiment uses different noise schedules for training and sampling. Build both sides from a single schedule so the loss probe and the reverse sampler agree on what timestep t means.

## Implementation scope

Implement DDPM’s closed-form corruption, epsilon-prediction loss path, and full ancestral sampler using the posterior variance choice. A supplied per-timestep affine denoiser replaces the learned image U-Net. Noise draws are explicit fixtures.

## Input

betas lists T step variances and denoiser has T [weight,bias] pairs, indexed from t=1. In loss mode supply the clean vector, epsilon vector and t. In sample mode supply terminal x_T and draws[t−1] for each reverse step.

## Output

Loss mode returns noisy x_t and the mean squared error between the predicted and supplied noise. Sample mode returns the trajectory [x_(T−1), …, x_0] and final sample. Each state is a vector.

## Constraints

T ≥ 1 and every beta lies strictly between zero and one. Use alpha_t=1−beta_t and bar_t=product(alpha_1…alpha_t), with bar_0=1. The reverse step uses posterior variance beta_t(1−bar_(t−1))/(1−bar_t). All vectors are nonempty and equally sized.

## Example 1

Input

~~~json
{
  "mode": "loss",
  "betas": [
    0.75
  ],
  "denoiser": [
    [
      2,
      0
    ]
  ],
  "t": 1,
  "clean": [
    2
  ],
  "epsilon": [
    0
  ]
}
~~~

Output

~~~json
{
  "noisy": [
    1
  ],
  "mse": 4
}
~~~

The signal amplitude is sqrt(0.25) = 0.5. The denoiser predicts 2 on the resulting state of 1, so the squared error relative to zero is 4.

## Example 2

Input

~~~json
{
  "mode": "sample",
  "betas": [
    0.75,
    0.75
  ],
  "denoiser": [
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ],
  "terminal": [
    0
  ],
  "draws": [
    [
      999
    ],
    [
      1
    ]
  ]
}
~~~

Output

~~~json
{
  "trajectory": [
    [
      0.7745966692414834
    ],
    [
      1.5491933384829668
    ]
  ],
  "sample": [
    1.5491933384829668
  ]
}
~~~

At t=2 the posterior variance is 0.75 × 0.75 / 0.9375 = 0.6. At t=1 the reverse mean doubles the state and the draw 999 has zero weight.

## Part 1 · Construct the training-time noisy observation

Build the cumulative signal schedule with an explicit t=0 sentinel. Form x_t = sqrt(bar_t)x_0 + sqrt(1−bar_t)ε.

noise_path.py · products(betas) — Return length T+1 with alpha_bar[0]=1 and cumulative (1-beta) thereafter.

noise_path.py · corrupt(clean, epsilon, alpha_bar) — Return a noisy sample from clean and epsilon vectors at one signal fraction.

## Part 2 · Propagate the reverse posterior

Compute (x_t − beta_t·epsilon_hat/sqrt(1−bar_t))/sqrt(1−beta_t) plus the supplied draw times the posterior standard deviation. The final step adds zero noise.

reverse_path.py · reverse_step(current, predicted_noise, noise, beta, previous_bar, current_bar) — Return one DDPM posterior-variance step. Inputs are aligned vectors.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Ho et al. · Denoising Diffusion Probabilistic Models](https://arxiv.org/abs/2006.11239)
