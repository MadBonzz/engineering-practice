import math


def products(betas):
    """Return length T+1 with alpha_bar[0]=1 and cumulative (1-beta) thereafter."""
    raise NotImplementedError('products')


def corrupt(clean, epsilon, alpha_bar):
    """Return a noisy sample from clean and epsilon vectors at one signal fraction."""
    raise NotImplementedError('corrupt')
