import math


def reverse_step(current, predicted_noise, noise, beta, previous_bar, current_bar):
    """Return one DDPM posterior-variance step. Inputs are aligned vectors."""
    raise NotImplementedError('reverse_step')
