import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_order_and_preactivation(self):
        args = [[[[1, -2]], [[-1, 3]]], [2, -1]]
        expected = [[[1, -2]], [[-1, 3]], [[2, -3]]]
        actual = trial('feature_bank.append_feature', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_signed_transition(self):
        args = [[[[1, -2], [3, 4]], [[0, 1], [2, 0]]], [-1, 2]]
        expected = [[-0.5]]
        actual = trial('transition.compress_pool', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

