import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'compression': [1, 1, -0.5],
 'growth': [[2], [0, 1]],
 'image': [[1, -2], [3, 0]]}
        expected = {'pooled': [[2]], 'widths': [1, 2, 3]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'compression': [2], 'growth': [], 'image': [[-1, 2, 100], [1, -1, 100]]}
        expected = {'pooled': [[1.5]], 'widths': [1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
