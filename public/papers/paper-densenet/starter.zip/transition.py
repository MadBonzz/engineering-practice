def compress_pool(bank, weights):
    """Mix C rectified channels into one plane and average complete 2×2 tiles with stride 2."""
    raise NotImplementedError('compress_pool')
