# DenseNet · Grow and compress a feature bank

A mobile encoder repeatedly creates one new feature channel and retains every earlier channel for reuse. Wire a dense block into a transition layer. The transition must see features in exactly the same channel order as the exported weights.

## Implementation scope

Implement the channel-growth invariant of a DenseNet block and its compression/downsampling transition. Each growth filter uses only its center spatial tap with growth rate one. Batch normalization is identity, with a single starting plane and a single transition output.

## Input

image is the initial H×W plane. growth contains one vector per layer, with 1+i weights at zero-based layer i. compression has one weight for each channel in the final bank.

## Output

Return widths, the initial and successive channel counts, and pooled, the compressed one-channel feature map after 2×2 average pooling.

## Constraints

H and W are at least 2. Each layer forms a pointwise weighted sum over ReLU of every existing channel and appends the signed result. The transition applies the same preactivation rule before mixing. Pooling uses stride 2 and ignores incomplete border windows.

## Example 1

Input

~~~json
{
  "image": [
    [
      1,
      -2
    ],
    [
      3,
      0
    ]
  ],
  "growth": [
    [
      2
    ],
    [
      0,
      1
    ]
  ],
  "compression": [
    1,
    1,
    -0.5
  ]
}
~~~

Output

~~~json
{
  "widths": [
    1,
    2,
    3
  ],
  "pooled": [
    [
      2
    ]
  ]
}
~~~

On positive input x the two new features each equal 2x. The transition yields x + 2x − x = 2x. Its four pixels are 2, 0, 6, 0, which average to 2.

## Example 2

Input

~~~json
{
  "image": [
    [
      -1,
      2,
      100
    ],
    [
      1,
      -1,
      100
    ]
  ],
  "growth": [],
  "compression": [
    2
  ]
}
~~~

Output

~~~json
{
  "widths": [
    1
  ],
  "pooled": [
    [
      1.5
    ]
  ]
}
~~~

An empty block still has the original input. The transition sees 0, 2, 1, 0 in its only full tile and doubles their mean. The last column is discarded.

## Part 1 · Append without discarding history

Build the next feature from all previous channels in oldest-first order. Preserve those channels and append the new plane.

feature_bank.py · append_feature(bank, weights) — Return a new C+1 channel bank, appending sum_c weights[c] * ReLU(bank[c]) at every pixel.

## Part 2 · Compress at the transition

Use an independent 1×1 preactivated projection across the whole bank. Average each complete, non-overlapping 2×2 tile.

transition.py · compress_pool(bank, weights) — Mix C rectified channels into one plane and average complete 2×2 tiles with stride 2.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Huang et al. · Densely Connected Convolutional Networks](https://arxiv.org/abs/1608.06993)
