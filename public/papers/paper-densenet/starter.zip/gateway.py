from feature_bank import append_feature
from transition import compress_pool

def handle(request):
    bank = [request["image"]]
    widths = [len(bank)]
    for kernel in request["growth"]:
        bank = append_feature(bank,kernel)
        widths.append(len(bank))
    return {"widths":widths,"pooled":compress_pool(bank,request["compression"])}
