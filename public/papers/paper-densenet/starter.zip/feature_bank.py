def append_feature(bank, weights):
    """Return a new C+1 channel bank, appending sum_c weights[c] * ReLU(bank[c]) at every pixel."""
    raise NotImplementedError('append_feature')
