def expand(low, kernel):
    """Map H×W to 2H×2W by stamping the 2×2 kernel times each low-resolution pixel."""
    raise NotImplementedError('expand')
