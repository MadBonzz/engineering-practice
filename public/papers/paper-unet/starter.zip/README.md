# U-Net · Align a decoder with a cropped skip

A tile segmenter combines a coarse context feature with a fine encoder feature. Implement the expanding path and stitch the encoder skip to the correct coordinates. A one-pixel offset changes which objects are marked foreground.

## Implementation scope

This one-level U-Net uses a provided cropped/pooling encoder, a learned up-convolution, a center-cropped skip, and a one-channel segmentation head. It isolates skip alignment and fusion from the original multi-level learned convolution stacks.

## Input

image is an H×W scalar encoder feature grid. The supplied contracting stage retains this skip, removes one border pixel on each side and max-pools the center. upsample_kernel is a 2×2 learned kernel. blend gives [up_weight, skip_weight] for the pointwise head, and bias is scalar.

## Output

Return logits and mask at the decoder resolution. mask contains 1 exactly where the corresponding fused logit is strictly positive.

## Constraints

H and W are at least 4. Pool complete 2×2 windows. Stride-2 transpose convolution stamps its 2×2 kernel once per low-resolution sample with no overlap or padding. Center-crop the skip. If the excess size is odd, discard the extra pixel on the bottom or right.

## Example 1

Input

~~~json
{
  "image": [
    [
      0,
      0,
      0,
      0
    ],
    [
      0,
      1,
      2,
      0
    ],
    [
      0,
      3,
      4,
      0
    ],
    [
      0,
      0,
      0,
      0
    ]
  ],
  "upsample_kernel": [
    [
      1,
      0
    ],
    [
      -1,
      1
    ]
  ],
  "blend": [
    1,
    -1
  ],
  "bias": 0
}
~~~

Output

~~~json
{
  "logits": [
    [
      3,
      -2
    ],
    [
      -7,
      0
    ]
  ],
  "mask": [
    [
      1,
      0
    ],
    [
      0,
      0
    ]
  ]
}
~~~

Pooling [1,2;3,4] yields 4. The up-convolution stamps [[4,0],[-4,4]]. Subtracting the aligned skip gives the four logits. A zero is background.

## Example 2

Input

~~~json
{
  "image": [
    [
      1,
      1,
      1,
      1,
      1
    ],
    [
      1,
      1,
      1,
      1,
      1
    ],
    [
      1,
      1,
      1,
      1,
      1
    ],
    [
      1,
      1,
      1,
      1,
      1
    ],
    [
      1,
      1,
      1,
      1,
      1
    ]
  ],
  "upsample_kernel": [
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ],
  "blend": [
    0,
    2
  ],
  "bias": -1
}
~~~

Output

~~~json
{
  "logits": [
    [
      1,
      1
    ],
    [
      1,
      1
    ]
  ],
  "mask": [
    [
      1,
      1
    ],
    [
      1,
      1
    ]
  ]
}
~~~

With zero decoder weights the retained skip supplies the entire prediction. Its unit values become logits of 1 after projection and bias.

## Part 1 · Restore the spatial lattice

Implement a scalar 2×2 stride-2 transposed convolution. Every bottleneck sample writes its own four output locations.

upconv.py · expand(low, kernel) — Map H×W to 2H×2W by stamping the 2×2 kernel times each low-resolution pixel.

## Part 2 · Align and join the skip

Center-crop the skip and use the two ordered feature channels as inputs to the segmentation head. Return signed pre-threshold logits.

skip_join.py · center_crop(skip, height, width) — Extract height×width from the center. Floor the top and left offsets.

skip_join.py · fuse(up, skip, weights, bias) — Crop skip to match up; apply weights[0]*up + weights[1]*cropped_skip + bias per pixel.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Ronneberger et al. · U-Net: Convolutional Networks for Biomedical Image Segmentation](https://arxiv.org/abs/1505.04597)
