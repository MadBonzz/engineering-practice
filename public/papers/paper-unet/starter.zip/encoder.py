def contract(skip):
    """Produce the pooled bottleneck from the valid interior of a supplied encoder feature."""
    core=[row[1:-1] for row in skip[1:-1]]
    return [[max(core[r+i][c+j] for i in range(2) for j in range(2))
             for c in range(0,len(core[0])-1,2)] for r in range(0,len(core)-1,2)]
