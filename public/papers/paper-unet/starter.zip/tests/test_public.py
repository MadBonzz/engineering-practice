import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_adjacent_tiles_and_kernel_orientation(self):
        args = [[[2, -1]], [[1, 2], [3, 4]]]
        expected = [[2, 4, -1, -2], [6, 8, -3, -4]]
        actual = trial('upconv.expand', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_unequal_odd_crop_offsets(self):
        args = [[[0, 1, 2, 3, 4, 5],
  [10, 11, 12, 13, 14, 15],
  [20, 21, 22, 23, 24, 25],
  [30, 31, 32, 33, 34, 35],
  [40, 41, 42, 43, 44, 45]],
 2,
 3]
        expected = [[11, 12, 13], [21, 22, 23]]
        actual = trial('skip_join.center_crop', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

