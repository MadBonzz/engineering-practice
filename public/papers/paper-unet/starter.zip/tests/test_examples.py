import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'bias': 0,
 'blend': [1, -1],
 'image': [[0, 0, 0, 0], [0, 1, 2, 0], [0, 3, 4, 0], [0, 0, 0, 0]],
 'upsample_kernel': [[1, 0], [-1, 1]]}
        expected = {'logits': [[3, -2], [-7, 0]], 'mask': [[1, 0], [0, 0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'bias': -1,
 'blend': [0, 2],
 'image': [[1, 1, 1, 1, 1],
           [1, 1, 1, 1, 1],
           [1, 1, 1, 1, 1],
           [1, 1, 1, 1, 1],
           [1, 1, 1, 1, 1]],
 'upsample_kernel': [[0, 0], [0, 0]]}
        expected = {'logits': [[1, 1], [1, 1]], 'mask': [[1, 1], [1, 1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
