def center_crop(skip, height, width):
    """Extract height×width from the center. Floor the top and left offsets."""
    raise NotImplementedError('center_crop')

def fuse(up, skip, weights, bias):
    """Crop skip to match up; apply weights[0]*up + weights[1]*cropped_skip + bias per pixel."""
    raise NotImplementedError('fuse')
