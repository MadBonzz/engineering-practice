from encoder import contract
from upconv import expand
from skip_join import fuse

def handle(request):
    skip=request["image"]
    up=expand(contract(skip),request["upsample_kernel"])
    logits=fuse(up,skip,request["blend"],request["bias"])
    return {"logits":logits,"mask":[[int(v>0) for v in row] for row in logits]}
