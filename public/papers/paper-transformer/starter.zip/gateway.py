from translation import encode, decode


def handle(request):
    memory = encode(request["source"])
    hidden = decode(request["prefix"],memory)
    return {"memory":memory,"logits":[[a,b,0] for a,b in hidden]}
