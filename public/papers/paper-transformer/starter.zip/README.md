# Transformer · translate with encoder–decoder attention

An encoder has read a source sentence. A teacher-forced decoder receives a target prefix. Implement one encoder and decoder layer so that every target position can consult the entire source while seeing only its own target history. Return the decoder’s vocabulary scores for all positions.

## Implementation scope

One post-norm encoder and decoder layer with bidirectional encoder attention, causal target attention and cross-attention. The supplied width-two checkpoint accepts positioned embeddings. Tokenization, multiple heads, stacked layers and training are outside this exercise.

## Input

source and prefix are lists of two-number vectors, already positioned token embeddings. The source contains at least one row. The target prefix may be empty.

## Output

Return memory, the encoded source rows, and logits, one three-score vector per target row. The fixed vocabulary head maps [a,b] to [a,b,0].

## Constraints

Use one head with identity Q, K, V and output projections. Scale scores by sqrt(2). This fixture uses post-residual population layer normalization with epsilon zero and maps constant rows to zeros. The supplied feed-forward branch maps [a,b] to [max(0,a+b)/4, max(0,a-b)/4].

## Example 1

Input

~~~json
{
  "source": [
    [
      2,
      0
    ]
  ],
  "prefix": [
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "memory": [
    [
      1,
      -1
    ]
  ],
  "logits": [
    [
      1,
      -1,
      0
    ]
  ]
}
~~~

With one source token, attention copies it. The encoder’s normalized state is [1,-1]. The zero target acquires that state through cross-attention.

## Example 2

Input

~~~json
{
  "source": [
    [
      0,
      2
    ]
  ],
  "prefix": []
}
~~~

Output

~~~json
{
  "memory": [
    [
      -1,
      1
    ]
  ],
  "logits": []
}
~~~

An empty target still encodes the source, but requests no decoder score.

## Part 1 · Implement scaled attention

Use the permitted key indices before normalizing each score row. Values may have a different width from keys.

attention.py · attend(queries, keys, values, causal) — Map T width-d queries and S matching keys/values to T context vectors. When causal is true, row i can see indices 0 through i inclusive.

## Part 2 · Connect the translation layers

Build both residual streams. Encoder memory remains available to every decoder step. Make logits invariant to changing a later prefix row.

translation.py · encode(source) — Encode S width-two rows. Apply full self-attention, add-and-normalize, then the supplied feed-forward add-and-normalize.

translation.py · decode(prefix, memory) — Decode T width-two rows. Apply causal self-attention then cross-attention to S memory rows, each followed by add-and-normalize. Finish with the supplied feed-forward sublayer.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Vaswani et al. · Attention Is All You Need](https://arxiv.org/abs/1706.03762)
