import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_causal_rows_have_different_visible_counts(self):
        args = [[[0, 0], [0, 0]], [[1, 0], [0, 1]], [[2], [8]], True]
        expected = [[2.0], [5.0]]
        actual = trial('attention.attend', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_mixed_source_context(self):
        args = [[[1, 0], [0, 3], [1, 1]]]
        expected = [[1.0, -1.0], [-1.0, 1.0], [-1.0, 1.0]]
        actual = trial('translation.encode', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

