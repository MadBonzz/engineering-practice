import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'prefix': [[0, 0]], 'source': [[2, 0]]}
        expected = {'logits': [[1, -1, 0]], 'memory': [[1, -1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'prefix': [], 'source': [[0, 2]]}
        expected = {'logits': [], 'memory': [[-1, 1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
