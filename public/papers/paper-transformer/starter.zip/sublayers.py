from tiny_ops import plus, layer_norm


def combine(rows, updates):
    return [layer_norm(plus(row,update),0) for row,update in zip(rows,updates)]


def finish(rows):
    updates = [[max(0,a+b)/4,max(0,a-b)/4] for a,b in rows]
    return combine(rows,updates)
