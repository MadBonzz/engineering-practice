from tiny_ops import dot, mix, softmax
import math


def attend(queries, keys, values, causal):
    """Map T width-d queries and S matching keys/values to T context vectors. When causal is true, row i can see indices 0 through i inclusive."""
    raise NotImplementedError('attend')
