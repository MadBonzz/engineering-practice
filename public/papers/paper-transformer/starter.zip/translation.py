from attention import attend
from sublayers import combine, finish


def encode(source):
    """Encode S width-two rows. Apply full self-attention, add-and-normalize, then the supplied feed-forward add-and-normalize."""
    raise NotImplementedError('encode')


def decode(prefix, memory):
    """Decode T width-two rows. Apply causal self-attention then cross-attention to S memory rows, each followed by add-and-normalize. Finish with the supplied feed-forward sublayer."""
    raise NotImplementedError('decode')
