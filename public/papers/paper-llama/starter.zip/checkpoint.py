import math

GATE = [[1.0,0.0]]
UP = [[0.0,1.0]]
DOWN = [[1.0],[-1.0]]


def rms(row):
    scale=math.sqrt(sum(v*v for v in row)/len(row)+1e-6)
    return [v/scale for v in row]
