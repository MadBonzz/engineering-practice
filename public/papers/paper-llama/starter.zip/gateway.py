from checkpoint import rms
from decoder import forward


def handle(request):
    rows = forward(request["states"], request["offset"])
    return {"logits":[[a,b,a-b] for a,b in map(rms,rows)]}
