import math
from tiny_ops import dot,mix,softmax,plus
from checkpoint import GATE,UP,DOWN,rms
from rotary import rotate
from feedforward import swiglu


def forward(states, offset):
    """Run one width-two block on T×2 embeddings. Add causal attention of RMS-normalized states, then add SwiGLU of the new RMS-normalized residual. Return T×2 raw residual states."""
    raise NotImplementedError('forward')
