import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'offset': 0, 'states': [[1, 0]]}
        expected = {'logits': [[1.414213319732186, 0, 1.414213319732186]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'offset': 7, 'states': [[0, 0]]}
        expected = {'logits': [[0, 0, 0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
