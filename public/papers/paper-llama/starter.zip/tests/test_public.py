import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_head_pair_frequencies(self):
        args = [[1, 2, -1, 3], 4, 10000]
        expected = [0.8599613697522445, -2.064089737035152, -1.1191681092208805, 2.9576109857962996]
        actual = trial('rotary.rotate', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_different_expansion_and_model_widths(self):
        args = [[2, -1],
 [[2, 1], [0, 1], [1, -3]],
 [[1, 2], [1, 0], [0, 1]],
 [[1, -2, 0], [0, 1, 3]]]
        expected = [1.0757656854799804, -15.437490078875719]
        actual = trial('feedforward.swiglu', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_only_previous_values_are_visible(self):
        args = [[[2, 0], [0, 3]], 5]
        expected = [[3.414213208819837, 0.0], [0.12030110572542682, 4.293912285986199]]
        actual = trial('decoder.forward', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

