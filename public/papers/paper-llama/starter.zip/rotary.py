import math


def rotate(x, position, base):
    """Rotate each adjacent pair of an even-width vector x. Angle for pair j is position / base**(2*j/len(x)). Return the rotated vector."""
    raise NotImplementedError('rotate')
