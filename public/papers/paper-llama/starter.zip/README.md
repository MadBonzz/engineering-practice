# LLaMA · assemble a rotary decoder block

Score a short sequence using a width-two LLaMA-style decoder. Implement rotary queries and keys, a gated feed-forward branch, and the two pre-normalized residual updates. A fixed readout exposes the effect of your block on each next-token score.

## Implementation scope

One LLaMA-1-style single-head block with RoPE, RMSNorm and SwiGLU. A small fixture replaces the learned projection matrices and vocabulary. It runs a causal forward pass without a tokenizer or pretrained weights.

## Input

states contains T width-two token embeddings in sequence order and offset gives the absolute integer position of the first row. All rows attend within this request. The supplied checkpoint gives the gate, up, and down projections.

## Output

Return logits, a T×3 list. The fixed readout maps a final RMS-normalized [a,b] to [a,b,a−b]. Empty input yields an empty list.

## Constraints

Normalize x as x/sqrt(mean(x²)+1e−6) with unit gains and no centering. Q, K and V are the normalized states. Apply adjacent-pair RoPE to Q and K only, with base 10000. Use causal softmax scaled by sqrt(width), identity attention output projection, and a separate RMS normalization before the MLP.

## Example 1

Input

~~~json
{
  "states": [
    [
      1,
      0
    ]
  ],
  "offset": 0
}
~~~

Output

~~~json
{
  "logits": [
    [
      1.414213319732186,
      0,
      1.414213319732186
    ]
  ]
}
~~~

With one position, attention copies the normalized value. The zero second coordinate switches off the fixture’s up projection. Final RMSNorm yields about 1.41421332 for both the first and third logits.

## Example 2

Input

~~~json
{
  "states": [
    [
      0,
      0
    ]
  ],
  "offset": 7
}
~~~

Output

~~~json
{
  "logits": [
    [
      0,
      0,
      0
    ]
  ]
}
~~~

The zero vector stays zero under rotation and through both bias-free branches.

## Part 1 · Rotate position-sensitive vectors

Preserve each pair’s norm and use a different frequency for each pair in a wider head.

rotary.py · rotate(x, position, base) — Rotate each adjacent pair of an even-width vector x. Angle for pair j is position / base**(2*j/len(x)). Return the rotated vector.

## Part 2 · Implement a gated MLP

Project an input twice to hidden width, apply SiLU on the gate, multiply elementwise by the up projection, then project back to model width.

feedforward.py · swiglu(x, gate, up, down) — With gate and up shaped H×D and down shaped D×H, return down @ (SiLU(gate @ x) multiplied elementwise by up @ x).

## Part 3 · Wire both residual branches

Add attention to the original input and add the MLP to that updated state. The two branch inputs each use RMSNorm.

decoder.py · forward(states, offset) — Run one width-two block on T×2 embeddings. Add causal attention of RMS-normalized states, then add SwiGLU of the new RMS-normalized residual. Return T×2 raw residual states.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Touvron et al. · LLaMA](https://arxiv.org/abs/2302.13971)
