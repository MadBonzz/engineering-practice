import math
from tiny_ops import linear


def swiglu(x, gate, up, down):
    """With gate and up shaped H×D and down shaped D×H, return down @ (SiLU(gate @ x) multiplied elementwise by up @ x)."""
    raise NotImplementedError('swiglu')
