import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_unequal_hidden_width_and_signed_output(self):
        args = [[2, -1], {'in': [[1, 0], [0, 1], [1, 1]], 'out': [[-1, 3, 0], [1, 0, 2]]}]
        expected = [-2.0, 4.0]
        actual = trial('shared_cell.network', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_hold_the_answer_during_latent_iterations(self):
        args = [[1], [2], [3], 2, {'in': [[1]], 'out': [[1]]}]
        expected = [[11], [9]]
        actual = trial('recursion.cycle', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_evaluate_halt_only_after_all_inner_cycles(self):
        args = [[1], [0], [0], 1, 2, 3, {'in': [[1]], 'out': [[1]]}, [0, 1]]
        expected = {'answer': [4], 'latent': [3], 'predictions': [0]}
        actual = trial('reasoner.infer', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

