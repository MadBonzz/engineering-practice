import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'cell': {'in': [[1, 0], [0, 1]], 'out': [[1, 0], [0, 1]]},
 'cycles': 1,
 'halt': [0.5, 0, -2],
 'max_steps': 3,
 'n': 2,
 'x': [1, 0],
 'y': [0, 1],
 'z': [0, 0]}
        expected = {'answer': [10, 11], 'latent': [8, 8], 'predictions': [1, 1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'cell': {'in': [[1]], 'out': [[1]]},
 'cycles': 1,
 'halt': [1, 0],
 'max_steps': 2,
 'n': 1,
 'x': [-1],
 'y': [0],
 'z': [0]}
        expected = {'answer': [0], 'latent': [0], 'predictions': [0, 0]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
