# Tiny Recursive Model · refine latent and answer states

A reasoning service can spend several cheap iterations improving a tentative answer before emitting it. Implement its shared two-layer cell, its two update rates and a halting controller. A trace of predictions should reveal exactly when a new answer became available.

## Implementation scope

Reproduce TRM’s inference-time latent/answer update schedule with a shared two-layer dense cell, an identity class head and a linear halt head. Use small numeric vectors in place of puzzle embeddings. Deep supervision and training-time gradient truncation are outside this inference lab.

## Input

x, y and z are equal-width vectors representing input, initial answer and initial latent. cell.in maps model width to hidden width and cell.out maps back. n sets inner latent updates, cycles sets complete cycles per prediction, and max_steps bounds the number of predictions. halt contains one coefficient per answer dimension plus a final bias.

## Output

Return final answer and latent vectors, and predictions containing the argmax class for each completed outer step. Ties use the lowest class index.

## Constraints

All iteration counts are positive. Define F(v)=W_out·ReLU(W_in·v). Within each cycle keep y fixed for n updates z←F(x+y+z), then update y←F(y+z) exactly once. Reuse the same F each time. After cycles such cycles compute the class and halt if dot(halt_weights,y)+bias > 0. Continue from the current states.

## Example 1

Input

~~~json
{
  "x": [
    1,
    0
  ],
  "y": [
    0,
    1
  ],
  "z": [
    0,
    0
  ],
  "n": 2,
  "cycles": 1,
  "max_steps": 3,
  "cell": {
    "in": [
      [
        1,
        0
      ],
      [
        0,
        1
      ]
    ],
    "out": [
      [
        1,
        0
      ],
      [
        0,
        1
      ]
    ]
  },
  "halt": [
    0.5,
    0,
    -2
  ]
}
~~~

Output

~~~json
{
  "answer": [
    10,
    11
  ],
  "latent": [
    8,
    8
  ],
  "predictions": [
    1,
    1
  ]
}
~~~

The first cycle visits z=[1,1] and [2,2], and produces y=[2,3]. Its halt logit is −1. The next cycle produces y=[10,11] and a positive halt logit of 3.

## Example 2

Input

~~~json
{
  "x": [
    -1
  ],
  "y": [
    0
  ],
  "z": [
    0
  ],
  "n": 1,
  "cycles": 1,
  "max_steps": 2,
  "cell": {
    "in": [
      [
        1
      ]
    ],
    "out": [
      [
        1
      ]
    ]
  },
  "halt": [
    1,
    0
  ]
}
~~~

Output

~~~json
{
  "answer": [
    0
  ],
  "latent": [
    0
  ],
  "predictions": [
    0,
    0
  ]
}
~~~

ReLU zeros the negative input, leaving the answer unchanged and the halt logit exactly zero. The step budget is exhausted.

## Part 1 · Build the reusable network

Accept rectangular matrices and return one output per row of W_out. Apply ReLU only between the two products.

shared_cell.py · network(values, weights) — Compute W_out · ReLU(W_in · values) using row-major matrices without biases.

## Part 2 · Separate reasoning from answer refinement

Advance z exactly n times before updating y. Return the new pair without mutating input vectors.

recursion.py · cycle(x, y, z, n, weights) — Return [new_answer, new_latent] after n latent updates and one answer update.

## Part 3 · Control inference compute

Run the prescribed cycles, decode one class, then test halting. Return both final states and every emitted class.

reasoner.py · infer(x, y, z, n, cycles, max_steps, weights, halt) — Return last states and one prediction per outer step, stopping for q>0.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Jolicoeur-Martineau · Less is More: Recursive Reasoning with Tiny Networks](https://arxiv.org/abs/2510.04871)
