def network(values, weights):
    """Compute W_out · ReLU(W_in · values) using row-major matrices without biases."""
    raise NotImplementedError('network')
