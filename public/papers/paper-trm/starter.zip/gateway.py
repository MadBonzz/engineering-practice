from reasoner import infer


def handle(request):
    return infer(request["x"],request["y"],request["z"],request["n"],request["cycles"],
                 request["max_steps"],request["cell"],request["halt"])
