from recursion import cycle


def infer(x, y, z, n, cycles, max_steps, weights, halt):
    """Return last states and one prediction per outer step, stopping for q>0."""
    raise NotImplementedError('infer')
