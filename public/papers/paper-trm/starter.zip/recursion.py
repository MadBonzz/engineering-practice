from shared_cell import network


def cycle(x, y, z, n, weights):
    """Return [new_answer, new_latent] after n latent updates and one answer update."""
    raise NotImplementedError('cycle')
