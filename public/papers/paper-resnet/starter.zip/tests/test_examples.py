import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'gain': -2, 'image': [[2, 1, 3]], 'shortcut': None, 'stride': 1}
        expected = {'features': [[0, 1, 0]], 'mean': 0.3333333333333333}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'gain': 0, 'image': [[-2, 9], [7, 5]], 'shortcut': -3, 'stride': 2}
        expected = {'features': [[6]], 'mean': 6}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
