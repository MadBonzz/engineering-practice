import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_left_tap_is_adjacent_to_the_strided_anchor(self):
        args = [[[1, 5, 2, 8]], 2, 2]
        expected = [[2, 0]]
        actual = trial('residual_path.residual', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_signed_identity(self):
        args = [[[-2, 4], [3, -5]], 1, None]
        expected = [[-2, 4], [3, -5]]
        actual = trial('shortcuts.shortcut_plane', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_residual_suppresses_a_positive_shortcut(self):
        args = [[[3, 2, 4]], 1, -1, None]
        expected = [[0, 2, 2]]
        actual = trial('stage.block', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

