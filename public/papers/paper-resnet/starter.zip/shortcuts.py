def shortcut_plane(image, stride, scale):
    """Return the H×W identity when scale is None, else a strided 1×1 scalar projection."""
    raise NotImplementedError('shortcut_plane')
