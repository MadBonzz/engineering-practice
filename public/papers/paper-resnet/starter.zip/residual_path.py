def residual(image, stride, gain):
    """Return gain × ReLU(center − left) at each strided anchor, shape ceil(H/s)×ceil(W/s)."""
    raise NotImplementedError('residual')
