from residual_path import residual
from shortcuts import shortcut_plane

def block(image, stride, gain, scale):
    """Compute ReLU(shortcut + learned branch) pointwise on the two aligned output planes."""
    raise NotImplementedError('block')
