# ResNet · Route identity and projected shortcuts

A small vision runtime exports a residual stage for two spatial resolutions. Implement both paths of the stage so a stride change samples the same input coordinates on each path. A negative residual can suppress an otherwise strong detector.

## Implementation scope

This is a single post-activation ResNet-v1 basic block on one input channel, followed by global average readout. The first 3×3 filter uses the center and left taps, the second uses its center tap, and batch normalization is folded to identity. Full ResNet stacks many wider blocks before a learned classifier.

## Input

image is a nonempty rectangular H×W feature plane. stride is 1 or 2. gain scales the second convolution. shortcut is null for identity or a scalar weight for a learned 1×1 projection.

## Output

Return features, the residual stage's output plane, and mean, its global spatial average.

## Constraints

Sample anchor pixels at row and column multiples of stride. Treat an out-of-bounds left neighbor as zero. Output shape is ceil(H/stride) × ceil(W/stride). Identity is requested only at stride 1.

## Example 1

Input

~~~json
{
  "image": [
    [
      2,
      1,
      3
    ]
  ],
  "stride": 1,
  "gain": -2,
  "shortcut": null
}
~~~

Output

~~~json
{
  "features": [
    [
      0,
      1,
      0
    ]
  ],
  "mean": 0.3333333333333333
}
~~~

The horizontal difference detector produces [2, 0, 2] after its ReLU. The second convolution scales it by −2. Adding the original pixels before applying the final ReLU gives [0, 1, 0].

## Example 2

Input

~~~json
{
  "image": [
    [
      -2,
      9
    ],
    [
      7,
      5
    ]
  ],
  "stride": 2,
  "gain": 0,
  "shortcut": -3
}
~~~

Output

~~~json
{
  "features": [
    [
      6
    ]
  ],
  "mean": 6
}
~~~

The sampled input is −2. A zero learned branch leaves the projected shortcut, which contributes 6 before the output ReLU.

## Part 1 · Run the learned branch

Emulate two convolutions with a ReLU between them. The first computes center minus left at each anchor. The second multiplies by gain.

residual_path.py · residual(image, stride, gain) — Return gain × ReLU(center − left) at each strided anchor, shape ceil(H/s)×ceil(W/s).

## Part 2 · Align the shortcut

Project the original input with the same stride as the residual branch when a scalar scale is supplied. Preserve signed activations.

shortcuts.py · shortcut_plane(image, stride, scale) — Return the H×W identity when scale is None, else a strided 1×1 scalar projection.

## Part 3 · Fuse the branches

Add the learned and shortcut outputs at matching coordinates, then clamp the sum at zero.

stage.py · block(image, stride, gain, scale) — Compute ReLU(shortcut + learned branch) pointwise on the two aligned output planes.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [He et al. · Deep Residual Learning for Image Recognition](https://arxiv.org/abs/1512.03385)
