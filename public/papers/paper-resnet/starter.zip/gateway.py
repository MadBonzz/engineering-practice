from stage import block

def handle(request):
    out = block(request["image"],request["stride"],request["gain"],request["shortcut"])
    total = sum(map(sum,out))
    return {"features":out,"mean":total/(len(out)*len(out[0]))}
