import math

def prepare(head, pos, eps):
    """For one [D] head, divide by sqrt(mean(head squared)+eps), rotate its first pair by pos radians with x'=x*cos-y*sin and y'=x*sin+y*cos, and return all D coordinates."""
    raise NotImplementedError('prepare')
