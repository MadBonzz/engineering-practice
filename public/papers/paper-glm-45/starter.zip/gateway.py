from group_cache import decode
def handle(request):
    return decode(request["tokens"],request["eps"])
