import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_scaled_tail_bypasses_rotation(self):
        args = [[3, 4, 5, 6], 2, 0.1]
        expected = [-1.0512202481084687, 0.2287867945799687, 1.075828707279838, 1.2909944487358056]
        actual = trial('head_geometry.prepare', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_different_queries_share_k_v(self):
        args = [[[1, 0], [0, 1]], [[[1, 0]], [[0, 1]]], [[[2, 3]], [[3, 2]]]]
        expected = [[2.330238450673343, 2.669761549326657], [2.669761549326657, 2.330238450673343]]
        actual = trial('group_cache.attend', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

