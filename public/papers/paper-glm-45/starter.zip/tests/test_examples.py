import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'eps': 1,
 'tokens': [{'k': [[0, 1]], 'q': [[1, 0], [0, 1]], 'v': [[4, 2]]},
            {'k': [[1, 0]], 'q': [[0, 0], [0, 0]], 'v': [[2, 6]]}]}
        expected = {'cache_slots': 2, 'heads': [[[4, 2], [4, 2]], [[3, 4], [3, 4]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'eps': 0.01,
 'tokens': [{'k': [[1, 0], [0, 1]],
             'q': [[0, 0], [0, 0], [0, 0], [0, 0]],
             'v': [[2, 1], [9, -1]]}]}
        expected = {'cache_slots': 2, 'heads': [[[2, 1], [2, 1], [9, -1], [9, -1]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
