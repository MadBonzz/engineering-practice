# GLM-4.5 · Decode with normalized grouped queries

A GLM-4.5 inference worker needs a causal grouped-query attention path. Process preprojected tokens one at a time. Normalize Q and K, rotate a prefix at the token's absolute position, and share each new cached key/value pair across a contiguous group of query heads.

## Implementation scope

Implements the paper's GQA, query/key normalization, and partial rotary position encoding for a toy head width. QKV projections are supplied. Expert layers, learned normalization gain, language head and full pretraining are outside the lab.

## Input

tokens is a nonempty sequence. Each token contains q of shape [H,D] and k and v of shape [G,D]. eps is a positive RMS-normalization constant. H and G can differ and H is divisible by G.

## Output

Return heads with shape [time,H,D] in input order and cache_slots counting stored key/value pairs as time × G. Each head's context is in its original value space.

## Constraints

D is at least 2. Normalize every query and key independently across all D coordinates with default unit gain. Rotate only coordinates 0 and 1 by position radians, starting at zero. Values pass through unchanged. Attention uses 1/sqrt(D) and includes the current token.

## Example 1

Input

~~~json
{
  "eps": 1,
  "tokens": [
    {
      "q": [
        [
          1,
          0
        ],
        [
          0,
          1
        ]
      ],
      "k": [
        [
          0,
          1
        ]
      ],
      "v": [
        [
          4,
          2
        ]
      ]
    },
    {
      "q": [
        [
          0,
          0
        ],
        [
          0,
          0
        ]
      ],
      "k": [
        [
          1,
          0
        ]
      ],
      "v": [
        [
          2,
          6
        ]
      ]
    }
  ]
}
~~~

Output

~~~json
{
  "heads": [
    [
      [
        4,
        2
      ],
      [
        4,
        2
      ]
    ],
    [
      [
        3,
        4
      ],
      [
        3,
        4
      ]
    ]
  ],
  "cache_slots": 2
}
~~~

Both heads see the only value at position zero. The zero queries at position one assign equal weight to [4,2] and [2,6]. Two positions occupy two shared key/value slots.

## Example 2

Input

~~~json
{
  "eps": 0.01,
  "tokens": [
    {
      "q": [
        [
          0,
          0
        ],
        [
          0,
          0
        ],
        [
          0,
          0
        ],
        [
          0,
          0
        ]
      ],
      "k": [
        [
          1,
          0
        ],
        [
          0,
          1
        ]
      ],
      "v": [
        [
          2,
          1
        ],
        [
          9,
          -1
        ]
      ]
    }
  ]
}
~~~

Output

~~~json
{
  "heads": [
    [
      [
        2,
        1
      ],
      [
        2,
        1
      ],
      [
        9,
        -1
      ],
      [
        9,
        -1
      ]
    ]
  ],
  "cache_slots": 2
}
~~~

Two query heads share each key/value head. With one token, each gets its group's value with probability one.

## Part 1 · Prepare each attention head

Apply full-width RMS scaling followed by the two-coordinate rotation at the absolute position.

head_geometry.py · prepare(head, pos, eps) — For one [D] head, divide by sqrt(mean(head squared)+eps), rotate its first pair by pos radians with x'=x*cos-y*sin and y'=x*sin+y*cos, and return all D coordinates.

## Part 2 · Share cache entries and decode

Implement causal softmax reads for contiguous query groups and drive them from an incrementally growing cache.

group_cache.py · attend(queries, keys, values) — Map prepared queries [H,D] and cached keys/values [T,G,D] to contexts [H,D]. Head h uses group h//(H/G). Apply stable softmax over time to scaled dot products.

group_cache.py · decode(tokens, eps) — For nonempty tokens carrying q[H,D], k/v[G,D], append a single prepared key and raw value per group per position. Return {heads: [T,H,D], cache_slots: T*G}.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Z.ai · GLM-4.5 technical report, §2.1](https://arxiv.org/abs/2508.06471)

- [Z.ai · GLM-4.5 model configuration](https://huggingface.co/zai-org/GLM-4.5/blob/main/config.json)
