import math
from head_geometry import prepare

def attend(queries, keys, values):
    """Map prepared queries [H,D] and cached keys/values [T,G,D] to contexts [H,D]. Head h uses group h//(H/G). Apply stable softmax over time to scaled dot products."""
    raise NotImplementedError('attend')

def decode(tokens, eps):
    """For nonempty tokens carrying q[H,D], k/v[G,D], append a single prepared key and raw value per group per position. Return {heads: [T,H,D], cache_slots: T*G}."""
    raise NotImplementedError('decode')
