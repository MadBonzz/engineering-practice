import math

def attend(tokens):
    """Map N×2 tokens to N×2 softmax-weighted sums using identity Q/K/V, dot products divided by sqrt(2)."""
    raise NotImplementedError('attend')
