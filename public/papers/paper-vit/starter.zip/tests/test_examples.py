import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'cls': [0, 0],
 'image': [[-1]],
 'patch': 1,
 'positions': [[0, 0], [0, 0]],
 'projection': [[1], [-1]]}
        expected = {'cls_state': [-0.4999997500001875, 0.4999997500001875],
 'logits': [-0.9999980000040001, 0.9999980000040001],
 'patch_count': 1}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'cls': [3, 3],
 'image': [[1, 2], [3, 4]],
 'patch': 2,
 'positions': [[0, 0], [1, 1]],
 'projection': [[1, 0, 0, 0], [1, 0, 0, 0]]}
        expected = {'cls_state': [3, 3], 'logits': [0, 0], 'patch_count': 1}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
