import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_raster_order_on_rectangular_patch_grid(self):
        args = [[[1, 2, 3, 4], [5, 6, 7, 8]],
 2,
 [[0, 1, 0, 0], [0, 0, 1, 0]],
 [1, 2],
 [[1, 1], [0, 1], [1, 0]]]
        expected = [[2, 3], [2, 6], [5, 7]]
        actual = trial('patch_tokens.tokenize', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_zero_query_averages_all_values(self):
        args = [[[0, 0], [2, -1], [-2, 3]]]
        expected = [[0.0, 0.6666666666666666],
 [1.942573132697333, -0.9708853707275191],
 [-1.9997935128898452, 2.9996917118951636]]
        actual = trial('attention_core.attend', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_two_successive_residual_paths(self):
        args = [[[1, -1], [2, 2]]]
        expected = [[2.8044289042406394, -2.8044289042406394], [3.4999977500041877, 0.5000022499958123]]
        actual = trial('image_encoder.encode', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

