# Vision Transformer · Assemble a patch-token classifier

Ship a tiny image classifier whose first token reads evidence from non-overlapping patches. Implement the patch sequence, attention and residual encoder, then send the final class token to a two-label head. A transposed patch or a misplaced class position changes every later computation.

## Implementation scope

This is an end-to-end miniature ViT inference path. It uses width 2, a single pre-normalized block and head, grayscale patches, fixed example weights, and a ReLU MLP in place of the original wider GELU MLP. It retains learned-position addition, the class token and both residual paths.

## Input

image is a grayscale H×W plane divisible by patch size p. projection is 2×p², cls is the learned length-2 class token, and positions supplies one length-2 learned embedding for every token, including cls.

## Output

Return patch_count, the final pre-head cls_state vector after both residual additions, and logits from the supplied head applied to the last normalized class vector.

## Constraints

Enumerate patches and pixels inside each patch in row-major order. The one-head encoder uses full attention including self-attention. Q, K and V use identity projections. Divide scores by sqrt(2). Use supplied row normalization, fixed ReLU MLP and class head. Inputs may be rectangular.

## Example 1

Input

~~~json
{
  "image": [
    [
      -1
    ]
  ],
  "patch": 1,
  "projection": [
    [
      1
    ],
    [
      -1
    ]
  ],
  "cls": [
    0,
    0
  ],
  "positions": [
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "patch_count": 1,
  "cls_state": [
    -0.4999997500001875,
    0.4999997500001875
  ],
  "logits": [
    -0.9999980000040001,
    0.9999980000040001
  ]
}
~~~

The class query is zero, so it averages its zero value and the normalized patch [−a,a], with a=1/√1.000001. Its MLP update vanishes because the first normalized coordinate is negative. Final layer normalization rescales [−a/2,a/2] to the two logits.

## Example 2

Input

~~~json
{
  "image": [
    [
      1,
      2
    ],
    [
      3,
      4
    ]
  ],
  "patch": 2,
  "projection": [
    [
      1,
      0,
      0,
      0
    ],
    [
      1,
      0,
      0,
      0
    ]
  ],
  "cls": [
    3,
    3
  ],
  "positions": [
    [
      0,
      0
    ],
    [
      1,
      1
    ]
  ]
}
~~~

Output

~~~json
{
  "patch_count": 1,
  "cls_state": [
    3,
    3
  ],
  "logits": [
    0,
    0
  ]
}
~~~

Both the class and patch vectors are constant across their two coordinates. Normalization maps both to zero. Both residual updates are zero, leaving the class state at [3,3] and its final normalized logits at zero.

## Part 1 · Start from image patches

Make one projected embedding per non-overlapping patch, prepend cls and add position vectors elementwise. Use projection rows as output features.

patch_tokens.py · tokenize(image, size, projection, cls, positions) — Return [CLS, patch_1,...] after adding positions. Each patch row-major vector maps to dimension 2.

## Part 2 · Run full token attention

Compute a row-normalized attention distribution per query, including the class token. Implement a numerically stable softmax.

attention_core.py · attend(tokens) — Map N×2 tokens to N×2 softmax-weighted sums using identity Q/K/V, dot products divided by sqrt(2).

## Part 3 · Assemble the encoder and readout

Call the supplied norm and mlp on individual rows. Normalize before the attention branch, then add its update to the original tokens. Repeat pre-normalization and residual addition for the MLP branch.

image_encoder.py · encode(tokens) — Return N×2 hidden states with z=x+attention(LN(x)), then y=z+MLP(LN(z)) rowwise.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Dosovitskiy et al. · An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale](https://arxiv.org/abs/2010.11929)
