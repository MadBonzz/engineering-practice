from attention_core import attend
from fixed_weights import norm, mlp

def encode(tokens):
    """Return N×2 hidden states with z=x+attention(LN(x)), then y=z+MLP(LN(z)) rowwise."""
    raise NotImplementedError('encode')
