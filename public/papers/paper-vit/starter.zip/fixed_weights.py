from math import sqrt

def norm(row):
    """Unit gain, zero offset layer norm over two coordinates using population variance and eps=1e-6."""
    mean=sum(row)/2
    scale=sqrt(sum((x-mean)**2 for x in row)/2 + 1e-6)
    return [(x-mean)/scale for x in row]

def mlp(row):
    """Fixed one-unit hidden ReLU followed by the output vector [1, -1]."""
    activation=max(0,row[0])
    return [activation,-activation]

def head(row):
    """Two class logits. The supplied projection is the 2×2 identity."""
    return list(row)
