from patch_tokens import tokenize
from image_encoder import encode
from fixed_weights import head,norm

def handle(request):
    tokens=tokenize(request["image"],request["patch"],request["projection"],request["cls"],request["positions"])
    state=encode(tokens)[0]
    return {"patch_count":len(tokens)-1,"cls_state":state,"logits":head(norm(state))}
