def tokenize(image, size, projection, cls, positions):
    """Return [CLS, patch_1,...] after adding positions. Each patch row-major vector maps to dimension 2."""
    raise NotImplementedError('tokenize')
