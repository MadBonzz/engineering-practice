from latent_read import context
from expert_router import route
from experts import expert


def decode(request):
    """Append each token’s compact KV record, read its context, update its residual, and dispatch shared plus weighted routed experts. Return hidden and expert_ids in arrival order."""
    raise NotImplementedError('decode')
