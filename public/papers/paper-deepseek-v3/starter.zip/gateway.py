from worker_step import decode


def handle(request):
    return decode(request)
