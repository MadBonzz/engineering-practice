# DeepSeek-V3 · decode from latent KV into sparse experts

A decoder worker keeps compressed attention history and a separate position key. After each attention read, route the token across a shared expert and selected routed experts. The load-balancing correction may change which expert runs without changing the weights used to mix its output.

## Implementation scope

A one-head, rank-one MLA decode and DeepSeekMoE inference path. Position components and router logits come from upstream projections. This single-group lab omits group/device limits, balance-bias training, FP8 and multi-token prediction.

## Input

Each token contains a scalar residual state, a scalar KV latent, a pre-rotated scalar pos_key, a query [content,position] and E router_logits. bias has E correction terms. experts contains E triples [gate,up,down] and shared contains one triple. top_k and scale control routing.

## Output

Return hidden, one scalar final residual per token, and expert_ids, one list of selected expert IDs per token in rank order.

## Constraints

In this checkpoint a latent c reconstructs content key c and value 2c. Attend over accumulated entries with score (q_content*c + q_pos*pos_key)/sqrt(2). Add that context to state to form h. Select experts by sigmoid(logit)+bias with smaller ID breaking ties. Normalize raw selected sigmoid affinities to sum to scale. Add to h both the shared expert and the weighted routed experts. Each triple computes down × SiLU(gate × h) × (up × h). Inputs have finite magnitudes below 30.

## Example 1

Input

~~~json
{
  "tokens": [
    {
      "state": 0,
      "latent": 0.5,
      "pos_key": 2,
      "query": [
        3,
        1
      ],
      "router_logits": [
        0,
        0
      ]
    }
  ],
  "bias": [
    0,
    0
  ],
  "top_k": 1,
  "scale": 1.0,
  "experts": [
    [
      1,
      1,
      1
    ],
    [
      2,
      1,
      1
    ]
  ],
  "shared": [
    0,
    1,
    1
  ]
}
~~~

Output

~~~json
{
  "hidden": [
    1.7310585786300048
  ],
  "expert_ids": [
    [
      0
    ]
  ]
}
~~~

The only latent contributes value 1. Equal affinities choose expert 0. Its [1,1,1] transform adds SiLU(1) to the residual, and the shared expert’s gate is zero.

## Example 2

Input

~~~json
{
  "tokens": [],
  "bias": [
    -1,
    2
  ],
  "top_k": 1,
  "scale": 1.0,
  "experts": [
    [
      1,
      1,
      1
    ],
    [
      2,
      1,
      1
    ]
  ],
  "shared": [
    0,
    1,
    1
  ]
}
~~~

Output

~~~json
{
  "hidden": [],
  "expert_ids": []
}
~~~

An idle request emits no states and dispatches no experts.

## Part 1 · Read a compressed attention row

Combine the latent-derived content score with the separate position-key score, then read the value reconstructed from the same latent.

latent_read.py · context(query, entries) — For a two-component query and nonempty chronological [latent,pos_key] rows, return the attended scalar value. The model decodes content key c and value 2c from latent c.

## Part 2 · Route with a balancing correction

Use bias-corrected affinities for selecting expert IDs and raw affinities for weights.

expert_router.py · route(logits, bias, k, scale) — Return [ids,weights] for k of E experts. Rank by sigmoid(logit)+bias, resolving ties by ID. Mix by the original selected sigmoid affinities normalized to sum to scale.

## Part 3 · Compose the sparse decode path

Use one accumulated compact cache per request. Run the shared expert once per token and sum only selected routed outputs.

worker_step.py · decode(request) — Append each token’s compact KV record, read its context, update its residual, and dispatch shared plus weighted routed experts. Return hidden and expert_ids in arrival order.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [DeepSeek-AI · DeepSeek-V3 Technical Report](https://arxiv.org/abs/2412.19437)

- [DeepSeek-AI · Inference reference](https://github.com/deepseek-ai/DeepSeek-V3/blob/main/inference/model.py)
