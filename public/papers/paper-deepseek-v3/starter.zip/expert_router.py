import math


def route(logits, bias, k, scale):
    """Return [ids,weights] for k of E experts. Rank by sigmoid(logit)+bias, resolving ties by ID. Mix by the original selected sigmoid affinities normalized to sum to scale."""
    raise NotImplementedError('route')
