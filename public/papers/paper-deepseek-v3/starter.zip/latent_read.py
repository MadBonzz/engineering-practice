import math
from tiny_ops import softmax


def context(query, entries):
    """For a two-component query and nonempty chronological [latent,pos_key] rows, return the attended scalar value. The model decodes content key c and value 2c from latent c."""
    raise NotImplementedError('context')
