import math


def expert(h, weights):
    gate,up,down=weights
    g=gate*h
    sig=1/(1+math.exp(-g)) if g>=0 else math.exp(g)/(1+math.exp(g))
    return down*(g*sig)*(up*h)
