import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_uniform_latent_value_reconstruction(self):
        args = [[0, 0], [[1, -9], [3, 9]]]
        expected = 4.0
        actual = trial('latent_read.context', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_bias_changes_ids_but_not_affinity_weights(self):
        args = [[2, 0, -1], [-1, 0, 1], 2, 2]
        expected = [[2, 1], [0.6995108181084377, 1.3004891818915623]]
        actual = trial('expert_router.route', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_two_routed_experts(self):
        args = [{'bias': [0, 0],
  'experts': [[1, 1, 1], [2, 1, 1]],
  'scale': 1.0,
  'shared': [0, 1, 1],
  'tokens': [{'latent': 0.1,
              'pos_key': -1,
              'query': [1, 0],
              'router_logits': [0, 1],
              'state': 1}],
  'top_k': 2}]
        expected = {'expert_ids': [[1, 0]], 'hidden': [3.2175081409141626]}
        actual = trial('worker_step.decode', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

