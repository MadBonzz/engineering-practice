import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'bias': [0, 0],
 'experts': [[1, 1, 1], [2, 1, 1]],
 'scale': 1.0,
 'shared': [0, 1, 1],
 'tokens': [{'latent': 0.5,
             'pos_key': 2,
             'query': [3, 1],
             'router_logits': [0, 0],
             'state': 0}],
 'top_k': 1}
        expected = {'expert_ids': [[0]], 'hidden': [1.7310585786300048]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'bias': [-1, 2],
 'experts': [[1, 1, 1], [2, 1, 1]],
 'scale': 1.0,
 'shared': [0, 1, 1],
 'tokens': [],
 'top_k': 1}
        expected = {'expert_ids': [], 'hidden': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
