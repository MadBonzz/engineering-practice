from corruption import corrupt
from tiny_block import encode
from token_head import predict


def handle(request):
    table, tokens = request["table"], request["tokens"]
    selected = request["selections"]
    altered,targets = corrupt(tokens,selected,len(table)-1)
    zeros = [0.0]*len(table[0])
    pos = request.get("positions",[zeros]*len(tokens))
    types = request.get("types",[zeros]*len(tokens))
    rows = [[a+b+c for a,b,c in zip(table[t],p,s)] for t,p,s in zip(altered,pos,types)]
    hidden = encode(rows,request["valid"])
    guesses,loss = predict(hidden,table,[s[0] for s in selected],targets)
    return {"input_ids":altered,"predictions":guesses,"mlm_loss":loss}
