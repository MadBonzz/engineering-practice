def corrupt(tokens, selections, mask_id):
    """Return altered IDs and original target IDs following each supplied selection."""
    raise NotImplementedError('corrupt')
