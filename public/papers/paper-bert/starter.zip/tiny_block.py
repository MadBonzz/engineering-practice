import math
from attention_core import attend


def norm(v):
    mean = sum(v)/len(v)
    variance = sum((x-mean)**2 for x in v)/len(v)
    return [(x-mean)/math.sqrt(variance+1e-12) for x in v]


def gelu(x):
    return 0.5*x*(1+math.erf(x/math.sqrt(2)))


def encode(rows, valid):
    rows = [norm(v) for v in rows]
    context = attend(rows, valid)
    attention = [norm([x+c for x,c in zip(v,ctx)]) for v,ctx in zip(rows,context)]
    return [norm([x+gelu(x) for x in v]) for v in attention]
