import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_boundary_draws_and_selection_order(self):
        args = [[0, 1, 0], [[2, 0.8, 1], [0, 0.9, 1], [1, 0.799, 0]], 2]
        expected = [[0, 2, 1], [0, 0, 1]]
        actual = trial('corruption.corrupt', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_right_context_enters_and_padding_stays_out(self):
        args = [[[0, 0], [1, 3], [100, 100]], 2]
        expected = [[0.5, 1.5], [0.9991513950372889, 2.9974541851118666]]
        actual = trial('attention_core.attend', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_uniform_logits_and_tie_breaking(self):
        args = [[[0, 0]], [[1, -1], [-1, 1], [0, 0]], [0], [1]]
        expected = [[0], 1.0986122886681098]
        actual = trial('token_head.predict', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

