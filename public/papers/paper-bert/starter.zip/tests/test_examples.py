import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'selections': [[0, 0, 1]],
 'table': [[1, -1], [-1, 1], [0, 0]],
 'tokens': [0, 1],
 'valid': 2}
        expected = {'input_ids': [2, 1], 'mlm_loss': 4.142931628499899, 'predictions': [1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'selections': [],
 'table': [[1, -1], [-1, 1], [0, 0]],
 'tokens': [1, 0, 0],
 'valid': 2}
        expected = {'input_ids': [1, 0, 0], 'mlm_loss': 0, 'predictions': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
