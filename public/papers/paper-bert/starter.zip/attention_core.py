import math


def attend(rows, valid):
    """Return identity-QKV bidirectional scaled attention for the first valid rows."""
    raise NotImplementedError('attend')
