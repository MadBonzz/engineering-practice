import math
from tiny_block import gelu, norm


def predict(hidden, table, positions, targets):
    """Return tied-vocabulary ID predictions and mean selected-position NLL."""
    raise NotImplementedError('predict')
