# BERT · pretrain a tiny bidirectional masked encoder

A masked-language-model pretrainer is being debugged on one short sequence. Assemble its deterministic input corruption, one bidirectional encoder block and the masked vocabulary head. Reserve the original token labels before changing any input.

## Implementation scope

Run a complete forward masked-language objective through a single tiny BERT-style encoder. Position and segment embedding contributions are supplied. Projection matrices are identities, dropout is disabled, and next-sentence prediction and optimizer updates are outside the exercise.

## Input

tokens is a vector of IDs into table, whose final row is [MASK]. valid gives the active prefix length. Each distinct selection is [position, draw, random_id] at an active position. Optional positions and types supply per-position embedding vectors to add to the token embeddings. Their defaults are zero.

## Output

Return the corrupted input_ids including padding, predictions in selection order, and mlm_loss as mean natural-log cross-entropy on the original selected IDs. Empty selections have zero loss.

## Constraints

Replace a selected token with [MASK] for draw < 0.8, with random_id for 0.8 ≤ draw < 0.9, and otherwise keep it visible. Every active position attends to every active key using dot(q,k)/sqrt(width). Exclude padding. The supplied post-norm block uses one head, identity projections and GELU. The MLM head uses LayerNorm(GELU(hidden)), tied vocabulary weights and zero biases. Break argmax ties toward smaller IDs.

## Example 1

Input

~~~json
{
  "tokens": [
    0,
    1
  ],
  "selections": [
    [
      0,
      0,
      1
    ]
  ],
  "valid": 2,
  "table": [
    [
      1,
      -1
    ],
    [
      -1,
      1
    ],
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "input_ids": [
    2,
    1
  ],
  "predictions": [
    1
  ],
  "mlm_loss": 4.142931628499899
}
~~~

The masked query is zero and averages itself with the token on its right. After normalization its head is approximately [−1,1], giving logits near [−2,2,0]. The correct label is token 0, so its loss is about 4.143 nats.

## Example 2

Input

~~~json
{
  "tokens": [
    1,
    0,
    0
  ],
  "selections": [],
  "valid": 2,
  "table": [
    [
      1,
      -1
    ],
    [
      -1,
      1
    ],
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "input_ids": [
    1,
    0,
    0
  ],
  "predictions": [],
  "mlm_loss": 0
}
~~~

The prefix still passes through the encoder. With no reconstruction targets the head emits no predictions.

## Part 1 · Construct masked-token inputs and targets

Apply the prescribed 80/10/10 branch to each selected position and preserve the original labels in selection order. Return a new token list.

corruption.py · corrupt(tokens, selections, mask_id) — Return altered IDs and original target IDs following each supplied selection.

## Part 2 · Run a bidirectional attention head

Use all valid keys and values for each valid query. Here Q, K and V each equal the input rows. Stabilize softmax independently per query.

attention_core.py · attend(rows, valid) — Return identity-QKV bidirectional scaled attention for the first valid rows.

## Part 3 · Score the original selected tokens

Apply the supplied GELU and population layer normalization to each selected hidden vector. Project against every original token embedding, including [MASK]. Return greedy IDs and mean stable negative log likelihood.

token_head.py · predict(hidden, table, positions, targets) — Return tied-vocabulary ID predictions and mean selected-position NLL.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Devlin et al. · BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding](https://arxiv.org/abs/1810.04805)
