import math


def evaluate(logits, ids):
    """From T×V logits return greedy next_ids and mean_nll in nats. Row t predicts ids[t+1]. Use all rows for greedy decoding, with smaller ID winning ties."""
    raise NotImplementedError('evaluate')
