from tied_head import embed, project
from block import decoder_step
from scoring import evaluate


def handle(request):
    ids = request["ids"]
    table = request["embedding"]
    rows = embed(ids,table,request["position"])
    return evaluate(project(decoder_step(rows),table),ids)
