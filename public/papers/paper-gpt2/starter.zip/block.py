import math
from tiny_ops import dot, mix, softmax, layer_norm, plus


def decoder_step(rows):
    """One supplied identity-projection, pre-LN causal attention and GELU feed-forward block."""
    normalized = [layer_norm(x) for x in rows]
    hidden = []
    for i,q in enumerate(normalized):
        keys = normalized[:i+1]
        probs = softmax([dot(q,k)/math.sqrt(len(q)) for k in keys])
        hidden.append(plus(rows[i],mix(probs,keys)))
    def gelu(x):
        return x*0.5*(1+math.tanh(math.sqrt(2/math.pi)*(x+0.044715*x**3)))
    return [plus(h,[gelu(x) for x in layer_norm(h)]) for h in hidden]
