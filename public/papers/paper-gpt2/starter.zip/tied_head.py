from tiny_ops import plus, dot, layer_norm


def embed(ids, table, positions):
    """For T ids return T width-D embeddings, adding positions[i] to table[ids[i]]."""
    raise NotImplementedError('embed')


def project(hidden, table):
    """Map T width-D states to T×V logits by final layer normalization then dot products against the original V token embeddings."""
    raise NotImplementedError('project')
