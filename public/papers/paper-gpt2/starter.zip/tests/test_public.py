import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_repeated_token_distinct_positions(self):
        args = [[1, 1], [[0, 3], [2, 1]], [[2, -1], [-1, 3]]]
        expected = [[4, 0], [1, 4]]
        actual = trial('tied_head.embed', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_shifted_labels_and_extreme_logits(self):
        args = [[[1000, 999], [0, 1], [2, -1]], [1, 0, 1]]
        expected = {'mean_nll': 0.31326168751822286, 'next_ids': [0, 1, 0]}
        actual = trial('scoring.evaluate', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

