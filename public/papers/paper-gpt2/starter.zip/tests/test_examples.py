import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'embedding': [[2, 0], [2, 0]],
 'ids': [0, 1],
 'position': [[0, 1], [1, 0]]}
        expected = {'mean_nll': 0.6931471805599453, 'next_ids': [0, 0]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'embedding': [[0, 1], [1, 0]], 'ids': [1], 'position': [[0, 0]]}
        expected = {'mean_nll': None, 'next_ids': [1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
