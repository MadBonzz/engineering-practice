# GPT-2 · score a text continuation

A language-model evaluator reports suspiciously good perplexity. Rebuild its miniature GPT-2 scoring path from token and learned position lookups through a supplied causal block to a tied output head. Score each next token against the preceding position.

## Implementation scope

One miniature decoder block with learned absolute positions, pre-LN causal self-attention, a GELU branch and tied vocabulary scoring. Matrices inside the supplied decoder use identity projections. BPE and pretraining are omitted.

## Input

ids is a nonempty list of vocabulary indices. embedding is a V×D learned-token table and position is a table of at least len(ids) width-D positional vectors. All weights are fixture values.

## Output

Return next_ids, the greedy next token for every input position including the final one, and mean_nll, the average next-token negative log likelihood in nats over len(ids)−1 predictions. A singleton has null mean_nll.

## Constraints

Positions begin at zero. The tied vocabulary head has no bias. Apply the supplied final layer_norm with epsilon 1e−5 before the output projection. Resolve equal logits to the smaller ID. Use a stable log-sum-exp.

## Example 1

Input

~~~json
{
  "ids": [
    0,
    1
  ],
  "embedding": [
    [
      2,
      0
    ],
    [
      2,
      0
    ]
  ],
  "position": [
    [
      0,
      1
    ],
    [
      1,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "next_ids": [
    0,
    0
  ],
  "mean_nll": 0.6931471805599453
}
~~~

Both rows of the tied vocabulary head are identical, so each token receives probability 1/2. One prediction contributes log(2) nats and the greedy tie goes to 0.

## Example 2

Input

~~~json
{
  "ids": [
    1
  ],
  "embedding": [
    [
      0,
      1
    ],
    [
      1,
      0
    ]
  ],
  "position": [
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "next_ids": [
    1
  ],
  "mean_nll": null
}
~~~

The final state favors the second vocabulary vector. There is no observed next token to score.

## Part 1 · Restore tied embeddings

Add learned token and position rows at input. Normalize the final state and reuse the token table for output.

tied_head.py · embed(ids, table, positions) — For T ids return T width-D embeddings, adding positions[i] to table[ids[i]].

tied_head.py · project(hidden, table) — Map T width-D states to T×V logits by final layer normalization then dot products against the original V token embeddings.

## Part 2 · Align targets and logits

Compute the next-token loss in nats, excluding the final score row from the loss and retaining it for greedy decoding.

scoring.py · evaluate(logits, ids) — From T×V logits return greedy next_ids and mean_nll in nats. Row t predicts ids[t+1]. Use all rows for greedy decoding, with smaller ID winning ties.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Radford et al. · Language Models are Unsupervised Multitask Learners](https://openai.com/index/better-language-models/)

- [OpenAI · GPT-2 model implementation](https://github.com/openai/gpt-2/blob/master/src/model.py)
