from sink_head import attend
from bounded_experts import dispatch


def handle(request):
    keys,values,hidden,mass=[],[],[],[]
    for item in request["tokens"]:
        keys.append(item["k"])
        values.append(item["v"])
        start=max(0,len(keys)-request["window"]) if request["layer"]%2==0 else 0
        context,sink=attend(item["q"],keys[start:],values[start:],request["sink"])
        h=item["state"]+context
        hidden.append(h+dispatch(h,item["router"],request["experts"],request["top_k"]))
        mass.append(sink)
    return {"hidden":hidden,"sink_mass":mass}
