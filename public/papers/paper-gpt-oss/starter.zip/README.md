# gpt-oss · decode with an attention sink and bounded experts

A reference decoder reserves some attention probability for a learned sink. The sink has no value vector. Reconstruct a small token path where this attention output enters a sparse feed-forward block with the gpt-oss gated activation.

## Implementation scope

One scalar-head attention and sparse expert pass using the auxiliary attention score, alternating windows and bounded gpt-oss SwiGLU rule. Projections are supplied, expert count and active count are configurable, and this reduced fixture omits RMSNorm, RoPE, quantization and biases.

## Input

Each token supplies a scalar state, projected q, k and v, plus router logits. layer is zero-based, window includes the current token, and sink is the learned head’s scalar sink logit. experts contains one [gate_gain,up_gain,down_gain] triple per expert. top_k is between one and the expert count.

## Output

Return hidden (one scalar post-expert residual per token) and sink_mass (the fraction of attention probability spent on the sink at each position).

## Constraints

Use one scalar head with q*k scores. Even layers attend to the most recent window entries, odd layers to the entire prefix. Softmax includes the sink score, whose value is zero. Form h = state + context. Choose top_k experts by router logit with smaller ID winning ties and softmax over just those logits. For each selected expert, gate = min(7, gate_gain*h), up = clip(up_gain*h,−7,7). Its output is down_gain × gate × sigmoid(1.702*gate) × (up+1). Add the weighted sum to h.

## Example 1

Input

~~~json
{
  "layer": 0,
  "window": 2,
  "sink": 0,
  "tokens": [
    {
      "state": 0,
      "q": 0,
      "k": 0,
      "v": 2,
      "router": [
        0
      ]
    }
  ],
  "experts": [
    [
      1,
      0,
      1
    ]
  ],
  "top_k": 1
}
~~~

Output

~~~json
{
  "hidden": [
    1.8457957659328212
  ],
  "sink_mass": [
    0.5
  ]
}
~~~

Two equal scores split the mass between the value 2 and the zero sink. The residual becomes 1. With up gain zero, the expert’s multiplicative up+1 factor is still one.

## Example 2

Input

~~~json
{
  "layer": 1,
  "window": 1,
  "sink": 0,
  "tokens": [
    {
      "state": 0,
      "q": 0,
      "k": 0,
      "v": 3,
      "router": [
        0
      ]
    },
    {
      "state": 0,
      "q": 0,
      "k": 0,
      "v": 6,
      "router": [
        0
      ]
    }
  ],
  "experts": [
    [
      0,
      0,
      1
    ]
  ],
  "top_k": 1
}
~~~

Output

~~~json
{
  "hidden": [
    1.5,
    3
  ],
  "sink_mass": [
    0.5,
    0.3333333333333333
  ]
}
~~~

On the global layer the second token shares mass equally between two real values and the sink. The zero gate suppresses the expert.

## Part 1 · Give the sink a place in the denominator

Append the learned sink logit during softmax and exclude it from the value sum. Return its normalized mass separately.

sink_head.py · attend(q, keys, values, sink) — Return [context,sink_mass] for one scalar query, equally long key/value arrays and one auxiliary sink logit. Its implicit value is zero.

## Part 2 · Mix bounded expert outputs

Implement the gate and top-k mixture. Scale gate, up and down independently and apply the offset after clipping the up branch.

bounded_experts.py · activate(gate, up) — Apply the scalar gpt-oss gated activation. Clamp gate from above at 7, clamp up to [-7,7], then return gate*sigmoid(1.702*gate)*(up+1).

bounded_experts.py · dispatch(h, logits, experts, k) — From scalar h and E router logits, mix the top-k scalar expert outputs by a softmax over selected logits only. Each expert stores gate, up and down gains. Ties favor lower ID.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [OpenAI · gpt-oss Architecture](https://deploymentsafety.openai.com/gpt-oss/architecture)

- [OpenAI · gpt-oss PyTorch reference](https://github.com/openai/gpt-oss/blob/main/gpt_oss/torch/model.py)
