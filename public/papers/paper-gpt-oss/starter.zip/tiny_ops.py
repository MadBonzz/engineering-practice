import math


def dot(a, b):
    return sum(x*y for x, y in zip(a,b))


def plus(a,b):
    return [x+y for x,y in zip(a,b)]


def softmax(scores):
    if not scores:
        return []
    pivot = max(scores)
    terms = [math.exp(value-pivot) for value in scores]
    total = sum(terms)
    return [value/total for value in terms]


def mix(weights, rows):
    return [sum(w * x for w,x in zip(weights,column)) for column in zip(*rows)]


def layer_norm(row, eps=1e-5):
    mean = sum(row)/len(row)
    var = sum((x-mean)**2 for x in row)/len(row)
    scale = math.sqrt(var + eps)
    return [(x-mean)/scale for x in row] if scale else [0.0]*len(row)


def linear(weights,x):
    return [dot(row,x) for row in weights]
