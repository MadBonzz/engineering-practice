import math
from tiny_ops import softmax


def activate(gate, up):
    """Apply the scalar gpt-oss gated activation. Clamp gate from above at 7, clamp up to [-7,7], then return gate*sigmoid(1.702*gate)*(up+1)."""
    raise NotImplementedError('activate')


def dispatch(h, logits, experts, k):
    """From scalar h and E router logits, mix the top-k scalar expert outputs by a softmax over selected logits only. Each expert stores gate, up and down gains. Ties favor lower ID."""
    raise NotImplementedError('dispatch')
