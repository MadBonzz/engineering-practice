import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_stable_softmax_includes_sink(self):
        args = [1, [1000, 999], [2, 4], 1000]
        expected = [1.4660872104908909, 0.4223187982515182]
        actual = trial('sink_head.attend', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_gate_only_clipped_above(self):
        args = [-19, 30]
        expected = -1.3728675256062008e-12
        actual = trial('bounded_experts.activate', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

