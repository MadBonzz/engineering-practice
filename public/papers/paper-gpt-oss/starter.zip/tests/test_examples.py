import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'experts': [[1, 0, 1]],
 'layer': 0,
 'sink': 0,
 'tokens': [{'k': 0, 'q': 0, 'router': [0], 'state': 0, 'v': 2}],
 'top_k': 1,
 'window': 2}
        expected = {'hidden': [1.8457957659328212], 'sink_mass': [0.5]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'experts': [[0, 0, 1]],
 'layer': 1,
 'sink': 0,
 'tokens': [{'k': 0, 'q': 0, 'router': [0], 'state': 0, 'v': 3},
            {'k': 0, 'q': 0, 'router': [0], 'state': 0, 'v': 6}],
 'top_k': 1,
 'window': 1}
        expected = {'hidden': [1.5, 3], 'sink_mass': [0.5, 0.3333333333333333]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
