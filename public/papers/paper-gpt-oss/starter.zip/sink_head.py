from tiny_ops import softmax


def attend(q, keys, values, sink):
    """Return [context,sink_mass] for one scalar query, equally long key/value arrays and one auxiliary sink logit. Its implicit value is zero."""
    raise NotImplementedError('attend')
