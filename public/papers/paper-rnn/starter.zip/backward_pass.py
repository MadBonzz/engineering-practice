def gradients(inputs, targets, scored, states, params, initial):
    """Return [loss, {input,recurrent,bias}, d_initial] using full reverse-time differentiation."""
    raise NotImplementedError('gradients')
