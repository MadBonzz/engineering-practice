from math import tanh


def rollout(inputs, params, initial):
    """Return T hidden values h[t]=tanh(input_weight*x[t]+recurrent_weight*h_prev+bias)."""
    raise NotImplementedError('rollout')
