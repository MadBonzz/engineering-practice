from recurrent_cell import rollout
from backward_pass import gradients


def handle(request):
    x, p, h0 = request["inputs"], request["params"], request["initial"]
    states = rollout(x, p, h0)
    loss, grad, d_initial = gradients(x, request["targets"], request["scored"], states, p, h0)
    updated = {k: v-request["lr"]*grad[k] for k,v in p.items()}
    return {"states": states, "loss": loss, "d_initial": d_initial, "params": updated}
