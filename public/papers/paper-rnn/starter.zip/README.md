# Vanilla RNN · backpropagate through a delayed label

A sensor sequence often receives a label only at its last timestep. Train a tiny recurrent predictor and expose the gradient that flowed all the way back to its initial state.

## Implementation scope

Reproduces the feedback link of an Elman recurrent network with one tanh unit, an identity readout and a full backward pass. This small regression task makes every gradient checkable.

## Input

inputs, targets and scored have the same length T. Each input and target is scalar. scored is a Boolean supervision mask. params has scalar input weight, recurrent weight and bias. initial is h₀ and lr is the learning rate.

## Output

Return the pre-update hidden sequence, summed pre-update loss, gradient d_initial, and params after one SGD step. With T=0 all gradients and the loss are zero.

## Constraints

Advance the recurrence at every timestep, including unscored ones. At scored steps add 0.5(h−target)² to the loss. Reuse the same weights at every step and accumulate the gradient of their full sequence loss before updating them.

## Example 1

Input

~~~json
{
  "inputs": [
    1,
    2
  ],
  "targets": [
    0,
    1
  ],
  "scored": [
    false,
    true
  ],
  "params": {
    "input": 0,
    "recurrent": 0.5,
    "bias": 0
  },
  "initial": 0,
  "lr": 0.1
}
~~~

Output

~~~json
{
  "states": [
    0,
    0
  ],
  "loss": 0.5,
  "d_initial": -0.25,
  "params": {
    "input": 0.25,
    "recurrent": 0.5,
    "bias": 0.15
  }
}
~~~

Only the last step has a direct error of −1. The first receives −0.5 through the recurrent weight. The shared input gradient is −2 − 0.5 = −2.5, and the gradient at the initial state is −0.25.

## Example 2

Input

~~~json
{
  "inputs": [],
  "targets": [],
  "scored": [],
  "params": {
    "input": 1.0,
    "recurrent": -0.75,
    "bias": 0.2
  },
  "initial": 0.3,
  "lr": 0.2
}
~~~

Output

~~~json
{
  "states": [],
  "loss": 0,
  "d_initial": 0,
  "params": {
    "input": 1.0,
    "recurrent": -0.75,
    "bias": 0.2
  }
}
~~~

Without observations the backward pass contributes no loss or parameter update.

## Part 1 · Roll out the shared recurrent cell

Return h₁ through h_T, applying tanh to each affine update. The caller supplies the state preceding the first input.

recurrent_cell.py · rollout(inputs, params, initial) — Return T hidden values h[t]=tanh(input_weight*x[t]+recurrent_weight*h_prev+bias).

## Part 2 · Send the loss backward through time

At each reverse step, add the local scored error to the hidden derivative coming from the future. Differentiate tanh using its stored output, accumulate shared parameter derivatives, and return the gradient arriving at h₀.

backward_pass.py · gradients(inputs, targets, scored, states, params, initial) — Return [loss, {input,recurrent,bias}, d_initial] using full reverse-time differentiation.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Elman · Finding Structure in Time](https://doi.org/10.1207/s15516709cog1402_1)
