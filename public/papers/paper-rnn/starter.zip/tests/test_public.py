import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_state_carry_under_nonzero_bias(self):
        args = [[0.5, 0, -1], {'bias': 0.2, 'input': 1.0, 'recurrent': -0.75}, 0.4]
        expected = [0.3799489622552249, -0.08475787835089857, -0.6269843712714013]
        actual = trial('recurrent_cell.rollout', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_early_unscored_step_carries_error(self):
        args = [[1, 2], [0, 1], [False, True], [0, 0], {'bias': 0, 'input': 0, 'recurrent': 0.5}, 0]
        expected = [0.5, {'bias': -1.5, 'input': -2.5, 'recurrent': 0.0}, -0.25]
        actual = trial('backward_pass.gradients', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

