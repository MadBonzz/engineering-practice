import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'initial': 0,
 'inputs': [1, 2],
 'lr': 0.1,
 'params': {'bias': 0, 'input': 0, 'recurrent': 0.5},
 'scored': [False, True],
 'targets': [0, 1]}
        expected = {'d_initial': -0.25,
 'loss': 0.5,
 'params': {'bias': 0.15, 'input': 0.25, 'recurrent': 0.5},
 'states': [0, 0]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'initial': 0.3,
 'inputs': [],
 'lr': 0.2,
 'params': {'bias': 0.2, 'input': 1.0, 'recurrent': -0.75},
 'scored': [],
 'targets': []}
        expected = {'d_initial': 0,
 'loss': 0,
 'params': {'bias': 0.2, 'input': 1.0, 'recurrent': -0.75},
 'states': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
