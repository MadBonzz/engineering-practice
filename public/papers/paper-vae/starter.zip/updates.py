import math


def update(x, epsilon, weights, posterior, lr):
    """Return all three encoder/decoder weights after one simultaneous SGD update."""
    raise NotImplementedError('update')
