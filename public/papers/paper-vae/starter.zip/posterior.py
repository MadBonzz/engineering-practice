import math


def sample_latent(x, mean_weight, variance_weight, epsilon):
    """Return [mean, log_variance, z] for one scalar x and supplied Gaussian draw."""
    raise NotImplementedError('sample_latent')
