import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_use_standard_deviation_to_scale_noise(self):
        args = [1, -2, 1.3862943611198906, 1.5]
        expected = [-2, 1.3862943611198906, 1.0]
        actual = trial('posterior.sample_latent', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_large_negative_decoder_logit(self):
        args = [1, 1000, 1, 0, -1]
        expected = [1000.0, 0.5]
        actual = trial('bound.loss_terms', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part3(unittest.TestCase):
    def test_1_use_a_shared_pre_update_posterior(self):
        args = [1, 1, [2, 0, 1], [2, 0, 3], 0.2]
        expected = [1.6094851746355134, 0.004742587317756664, 1.02845552390654]
        actual = trial('updates.update', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

