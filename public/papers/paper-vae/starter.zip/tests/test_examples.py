import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'epsilon': 0, 'lr': 1, 'weights': [0, 0, 1], 'x': 1}
        expected = {'kl': 0,
 'reconstruction': 0.6931471805599453,
 'weights': [0.5, 0, 1],
 'z': 0}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'epsilon': 2, 'lr': 0.25, 'weights': [0, 0, 0], 'x': 0}
        expected = {'kl': 0,
 'reconstruction': 0.6931471805599453,
 'weights': [0, 0, -0.25],
 'z': 2}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
