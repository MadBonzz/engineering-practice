# VAE · train with a reparameterized latent

A toy binary sensor autoencoder samples a latent before predicting the sensor reading. Wire its encoder, likelihood and optimizer together so a reconstruction error can update both the decoder and the approximate posterior.

## Implementation scope

Train a complete one-observation scalar VAE using a linear encoder, Bernoulli decoder, analytic Gaussian KL and pathwise gradients. The fixed noise input makes the stochastic update repeatable. Larger image networks and sampled multi-example training are outside this lab.

## Input

x is one binary observation (0 or 1). weights is [mean_weight, variance_weight, decoder_weight]. epsilon is a fixed standard-normal draw supplied by the caller and lr is a nonnegative learning rate.

## Output

Return the sampled scalar z, reconstruction NLL and analytic kl before the update, plus the three weights after one step. All logarithms are natural.

## Constraints

The encoder has no biases. Its two heads produce mean = mean_weight*x and log_variance = variance_weight*x. The prior is a standard normal. The decoder Bernoulli logit is decoder_weight*z. Use simultaneous unconstrained SGD with KL coefficient one. Log-variance is in [−10,10]. Logits may have magnitude 1000.

## Example 1

Input

~~~json
{
  "x": 1,
  "epsilon": 0,
  "weights": [
    0,
    0,
    1
  ],
  "lr": 1
}
~~~

Output

~~~json
{
  "z": 0,
  "reconstruction": 0.6931471805599453,
  "kl": 0,
  "weights": [
    0.5,
    0,
    1
  ]
}
~~~

A zero sample yields probability 0.5. The decoder weight sees zero input, while the mean head receives gradient −0.5.

## Example 2

Input

~~~json
{
  "x": 0,
  "epsilon": 2,
  "weights": [
    0,
    0,
    0
  ],
  "lr": 0.25
}
~~~

Output

~~~json
{
  "z": 2,
  "reconstruction": 0.6931471805599453,
  "kl": 0,
  "weights": [
    0,
    0,
    -0.25
  ]
}
~~~

With x equal to zero the encoder heads receive no weight gradient. The decoder gradient is 0.5 × 2 = 1.

## Part 1 · Sample a differentiable latent

Compute the two encoder heads and z = mean + exp(log_variance/2) × epsilon.

posterior.py · sample_latent(x, mean_weight, variance_weight, epsilon) — Return [mean, log_variance, z] for one scalar x and supplied Gaussian draw.

## Part 2 · Evaluate the variational bound

Compute softplus(logit) − x·logit and ½(mean² + exp(log_variance) − 1 − log_variance). Return each term separately.

bound.py · loss_terms(x, z, mean, log_variance, decoder_weight) — Return [Bernoulli reconstruction NLL, KL(q||N(0,1))] in nats.

## Part 3 · Send gradients through the sample

Differentiate reconstruction + KL at the supplied posterior. Return updated weights in their input order using only pre-update values.

updates.py · update(x, epsilon, weights, posterior, lr) — Return all three encoder/decoder weights after one simultaneous SGD update.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Kingma and Welling · Auto-Encoding Variational Bayes](https://arxiv.org/abs/1312.6114)
