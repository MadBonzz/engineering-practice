import math


def loss_terms(x, z, mean, log_variance, decoder_weight):
    """Return [Bernoulli reconstruction NLL, KL(q||N(0,1))] in nats."""
    raise NotImplementedError('loss_terms')
