from posterior import sample_latent
from bound import loss_terms
from updates import update


def handle(request):
    x, eps, weights = request["x"], request["epsilon"], request["weights"]
    posterior = sample_latent(x, weights[0], weights[1], eps)
    mean, lv, z = posterior
    recon, kl = loss_terms(x, z, mean, lv, weights[2])
    return {"z":z, "reconstruction":recon, "kl":kl,
            "weights":update(x, eps, weights, posterior, request["lr"])}
