from spatial_filter import filter_relu

def pool2(image):
    """Max over complete 2×2 windows at stride 2, returning floor(H/2)×floor(W/2)."""
    raise NotImplementedError('pool2')

def run_stack(image, specs):
    """Return (features, shapes) after all filters and one pool per stage, in listed order."""
    raise NotImplementedError('run_stack')
