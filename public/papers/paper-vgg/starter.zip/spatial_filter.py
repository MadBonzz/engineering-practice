def filter_relu(image, kernel):
    """Compute unit-stride zero-padded 3×3 cross-correlation plus ReLU, preserving H×W."""
    raise NotImplementedError('filter_relu')
