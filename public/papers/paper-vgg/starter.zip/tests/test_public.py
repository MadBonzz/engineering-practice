import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_asymmetric_filter_orientation(self):
        args = [[[1, 2, 3]], [[0, 0, 0], [1, 0, 0], [0, 0, 0]]]
        expected = [[0, 1, 2]]
        actual = trial('spatial_filter.filter_relu', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_rectangular_max_pool_geometry(self):
        args = [[[-1, -4, 3, 7], [-6, -2, 4, 2], [-9, 0, 0, 100]]]
        expected = [[-1, 7]]
        actual = trial('stages.pool2', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

