import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'image': [[1, 4, 2, 7], [0, 3, 6, 5]],
 'stages': [[[[0, 0, 0], [-1, 1, 0], [0, 0, 0]],
             [[0, 0, 0], [0, 1, 0], [0, 0, 0]]]]}
        expected = {'features': [[3, 5]], 'shapes': [[1, 2]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'image': [[-1, -2, 100], [-3, -4, 100]],
 'stages': [[[[0, 0, 0], [0, 1, 0], [0, 0, 0]]]]}
        expected = {'features': [[0]], 'shapes': [[1, 1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
