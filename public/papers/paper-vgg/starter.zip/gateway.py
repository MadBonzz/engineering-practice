from stages import run_stack

def handle(request):
    feature,shape=run_stack(request["image"],request["stages"])
    return {"shapes":shape,"features":feature}
