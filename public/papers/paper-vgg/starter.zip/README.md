# VGG · Execute a configurable 3×3 stage stack

An image classifier stores its feature extractor as a stack of stages. A mistaken placement of pooling silently changes the receptive field. Implement its feature extractor and track each stage's shape for the classifier head.

## Implementation scope

This mini VGG reproduces sequential same-resolution 3×3 filters, intermediate ReLUs and stage-boundary pooling. It uses one channel across stages and returns the feature extractor output rather than the original classification head.

## Input

image is a single feature plane H×W. stages is a list of nonempty lists of 3×3 filter matrices. Each filter is followed by ReLU, and each entire stage ends with one max pool.

## Output

Return shapes as a list of [height,width] pairs after each stage's pool and features as the final feature plane.

## Constraints

Use 3×3 cross-correlation at unit stride, with one zero of padding on each edge and no bias. The 2×2 max pool has stride 2 and drops incomplete windows. Each spatial dimension is at least 2 before every pool.

## Example 1

Input

~~~json
{
  "image": [
    [
      1,
      4,
      2,
      7
    ],
    [
      0,
      3,
      6,
      5
    ]
  ],
  "stages": [
    [
      [
        [
          0,
          0,
          0
        ],
        [
          -1,
          1,
          0
        ],
        [
          0,
          0,
          0
        ]
      ],
      [
        [
          0,
          0,
          0
        ],
        [
          0,
          1,
          0
        ],
        [
          0,
          0,
          0
        ]
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "shapes": [
    [
      1,
      2
    ]
  ],
  "features": [
    [
      3,
      5
    ]
  ]
}
~~~

The first filter returns [1,3,0,5] and [0,3,3,0]. The identity filter preserves these activations. Max pooling the left and right tiles produces [3,5].

## Example 2

Input

~~~json
{
  "image": [
    [
      -1,
      -2,
      100
    ],
    [
      -3,
      -4,
      100
    ]
  ],
  "stages": [
    [
      [
        [
          0,
          0,
          0
        ],
        [
          0,
          1,
          0
        ],
        [
          0,
          0,
          0
        ]
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "shapes": [
    [
      1,
      1
    ]
  ],
  "features": [
    [
      0
    ]
  ]
}
~~~

ReLU clears the four negative values in the complete tile. The large values lie in the incomplete right column.

## Part 1 · Implement the padded filter

Return one activation at each input coordinate. Kernel entry [0][0] multiplies the upper-left neighbor.

spatial_filter.py · filter_relu(image, kernel) — Compute unit-stride zero-padded 3×3 cross-correlation plus ReLU, preserving H×W.

## Part 2 · Execute the stage specification

Apply each stage's filters in sequence, pool once, and record the post-pool dimensions. run_stack returns [final_plane, shapes].

stages.py · pool2(image) — Max over complete 2×2 windows at stride 2, returning floor(H/2)×floor(W/2).

stages.py · run_stack(image, specs) — Return (features, shapes) after all filters and one pool per stage, in listed order.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Simonyan and Zisserman · Very Deep Convolutional Networks for Large-Scale Image Recognition](https://arxiv.org/abs/1409.1556)
