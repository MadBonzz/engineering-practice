# Word2Vec · train skip-gram embeddings

A text ingestion worker learns two embedding tables from token IDs. Implement the windowing and optimization code so a client can reproduce exactly which examples moved each word vector.

## Implementation scope

Implements one deterministic skip-gram negative-sampling training pass. The caller supplies noise samples. Vocabulary construction, phrase detection and a large-corpus training run are outside the exercise.

## Input

tokens is a list of vocabulary IDs. window is a nonnegative radius. centers and contexts are separate V × D tables. negatives supplies one list of sampled context IDs per ordered positive pair. lr is the learning rate.

## Output

Return the ordered center/context pairs, the pre-update loss for each pair, and the final centers and contexts tables. Each loss is a sum over one positive and its negative samples.

## Constraints

Visit center positions left to right, then neighboring positions left to right. Exclude the center position. Equal IDs at distinct positions are valid. Negative IDs can repeat and can coincide with the positive ID. Accumulate all gradient contributions for one pair against its starting tables, then apply one SGD update. Inputs remain unchanged.

## Example 1

Input

~~~json
{
  "tokens": [
    0,
    1
  ],
  "window": 1,
  "centers": [
    [
      1
    ],
    [
      0
    ]
  ],
  "contexts": [
    [
      0
    ],
    [
      0
    ]
  ],
  "negatives": [
    [],
    []
  ],
  "lr": 0.2
}
~~~

Output

~~~json
{
  "pairs": [
    [
      0,
      1
    ],
    [
      1,
      0
    ]
  ],
  "losses": [
    0.6931471805599453,
    0.6931471805599453
  ],
  "centers": [
    [
      1
    ],
    [
      0
    ]
  ],
  "contexts": [
    [
      0
    ],
    [
      0.1
    ]
  ]
}
~~~

Each initial dot product is zero and costs log(2). The first pair moves context 1 by 0.2 × 0.5 × 1 = 0.1. The second pair has both a zero center and a zero context.

## Example 2

Input

~~~json
{
  "tokens": [
    1
  ],
  "window": 2,
  "centers": [
    [
      0
    ],
    [
      1
    ]
  ],
  "contexts": [
    [
      3
    ],
    [
      4
    ]
  ],
  "negatives": [],
  "lr": 0.1
}
~~~

Output

~~~json
{
  "pairs": [],
  "losses": [],
  "centers": [
    [
      0
    ],
    [
      1
    ]
  ],
  "contexts": [
    [
      3
    ],
    [
      4
    ]
  ]
}
~~~

The only token has no neighboring position. Both embedding tables pass through unchanged.

## Part 1 · Construct the ordered training stream

Enumerate all positions within the radius, skipping the current position. Return IDs so repeated occurrences contribute repeated examples.

context_windows.py · positive_pairs(tokens, radius) — Return [center_id, context_id] pairs ordered by center index then context index within radius.

## Part 2 · Differentiate one sampled objective

For each signed target s (+1 positive, −1 negative), accumulate softplus(−s u·v). Its derivative with respect to u·v is −s sigmoid(−s u·v). Apply SGD once to the input row and each touched output row. The supplied gateway feeds each update into the next pair.

negative_sampling.py · update_pair(centers, contexts, pair, negatives, lr) — Return loss and copied updated V × D tables as [loss, new_centers, new_contexts].

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Mikolov et al. · Distributed Representations of Words and Phrases and their Compositionality, §2.2](https://arxiv.org/abs/1310.4546)
