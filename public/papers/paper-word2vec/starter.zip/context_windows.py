def positive_pairs(tokens, radius):
    """Return [center_id, context_id] pairs ordered by center index then context index within radius."""
    raise NotImplementedError('positive_pairs')
