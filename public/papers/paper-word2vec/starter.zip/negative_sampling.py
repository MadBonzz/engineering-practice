from numerics import dot, sigmoid, softplus


def update_pair(centers, contexts, pair, negatives, lr):
    """Return loss and copied updated V × D tables as [loss, new_centers, new_contexts]."""
    raise NotImplementedError('update_pair')
