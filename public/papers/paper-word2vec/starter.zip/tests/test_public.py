import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_repeated_words_at_distinct_positions(self):
        args = [[4, 4, 9], 1]
        expected = [[4, 4], [4, 4], [4, 9], [9, 4]]
        actual = trial('context_windows.positive_pairs', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_repeated_negative_table_row(self):
        args = [[[1, 2], [-1, 1]], [[2, -1], [1, 2]], [0, 0], [1, 1], 0.1]
        expected = [10.706577877538182,
 [[0.901338570184857, 1.552677140369714], [-1, 1]],
 [[2.05, -0.9], [0.801338570184857, 1.602677140369714]]]
        actual = trial('negative_sampling.update_pair', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

