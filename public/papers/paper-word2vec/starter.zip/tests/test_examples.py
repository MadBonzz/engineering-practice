import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'centers': [[1], [0]],
 'contexts': [[0], [0]],
 'lr': 0.2,
 'negatives': [[], []],
 'tokens': [0, 1],
 'window': 1}
        expected = {'centers': [[1], [0]],
 'contexts': [[0], [0.1]],
 'losses': [0.6931471805599453, 0.6931471805599453],
 'pairs': [[0, 1], [1, 0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'centers': [[0], [1]],
 'contexts': [[3], [4]],
 'lr': 0.1,
 'negatives': [],
 'tokens': [1],
 'window': 2}
        expected = {'centers': [[0], [1]], 'contexts': [[3], [4]], 'losses': [], 'pairs': []}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
