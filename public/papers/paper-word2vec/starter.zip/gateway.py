from context_windows import positive_pairs
from negative_sampling import update_pair


def handle(request):
    pairs = positive_pairs(request["tokens"], request["window"])
    centers, contexts = request["centers"], request["contexts"]
    losses = []
    for pair, negatives in zip(pairs, request["negatives"]):
        loss, centers, contexts = update_pair(centers, contexts, pair, negatives, request["lr"])
        losses.append(loss)
    return {"pairs": pairs, "losses": losses, "centers": centers, "contexts": contexts}
