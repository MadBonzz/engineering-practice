import math


def scores(tokens, bias, context):
    """Fixture denoiser. Each visible token contributes its row to every position."""
    vocab = len(context)
    signal = [sum(context[t][k] for t in tokens if t != -1) for k in range(vocab)]
    return [[b+s for b,s in zip(row,signal)] for row in bias]


def logsumexp(logits):
    peak = max(logits)
    return peak + math.log(sum(math.exp(x-peak) for x in logits))
