from token_oracle import scores, logsumexp


def corruption_loss(clean, draws, t, bias, context):
    """Return masked IDs and inverse-t weighted NLL per original token."""
    raise NotImplementedError('corruption_loss')
