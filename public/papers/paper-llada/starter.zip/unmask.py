import math
from token_oracle import scores, logsumexp


def commit(tokens, logits, quota):
    """Return a copy with up to quota masked positions frozen by predicted probability."""
    raise NotImplementedError('commit')


def generate(tokens, steps, bias, context):
    """Return tokens and the post-commit trace for exactly steps parallel rounds."""
    raise NotImplementedError('generate')
