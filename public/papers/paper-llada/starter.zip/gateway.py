from masked_objective import corruption_loss
from unmask import generate


def handle(request):
    if request["mode"] == "loss":
        return corruption_loss(request["tokens"],request["draws"],request["t"],request["bias"],request["context"])
    return generate(request["tokens"],request["steps"],request["bias"],request["context"])
