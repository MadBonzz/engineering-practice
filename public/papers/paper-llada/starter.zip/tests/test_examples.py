import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'bias': [[0, 0], [1, 0], [0, 3]],
 'context': [[0, 0], [0, 1]],
 'mode': 'generate',
 'steps': 2,
 'tokens': [1, -1, -1]}
        expected = {'tokens': [1, 1, 1], 'trace': [[1, -1, 1], [1, 1, 1]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'bias': [[0, 0], [0, 0]],
 'context': [[0, 0], [0, 0]],
 'draws': [0.45, 0.72],
 'mode': 'loss',
 't': 0.5,
 'tokens': [0, 1]}
        expected = {'loss': 0.6931471805599453, 'masked': [-1, 1]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
