import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_strict_masking_boundary_and_zero_selected(self):
        args = [[1, 0], [0.5, 0.9], 0.5, [[0, 1], [2, 0]], [[0, 0], [0, 0]]]
        expected = {'loss': 0.0, 'masked': [1, 0]}
        actual = trial('masked_objective.corruption_loss', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_compare_normalized_confidences_across_positions(self):
        args = [[-1, -1, 1], [[99, 99], [0, 2], [1, 0]], 1]
        expected = [-1, 1, 1]
        actual = trial('unmask.commit', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

