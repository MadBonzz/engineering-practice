# LLaDA · learn and decode by unmasking

An editor asks a discrete diffusion model to fill several holes in one sentence. Implement a training loss for randomly masked tokens, then let the decoder commit its most confident predictions and reconsider the rest.

## Implementation scope

Implement the masking objective and deterministic, confidence-based reverse sampler for one whole-sequence block. The provided bidirectional logit fixture replaces LLaDA’s learned Transformer. Temperature sampling, classifier-free guidance and large-scale training are omitted.

## Input

tokens contains vocabulary IDs and, for generation, −1 holes. bias is one row of logits per position. context is a vocabulary-by-vocabulary contribution table used by the supplied denoiser. Loss mode also receives t and one uniform draw per token. Generate mode receives a positive steps count.

## Output

Loss mode returns masked tokens and inverse-t-weighted loss. Generate mode returns the completed tokens and a trace of the entire sequence after every update, including rounds with quota zero.

## Constraints

Clean sequences are nonempty. Mask when draw < t with 0 < t ≤ 1. Divide the sum of masked cross-entropies by t times the original length. Predict greedily, breaking token ties toward smaller IDs. Rank only masked positions by their best-token softmax probability, breaking ties toward the earlier position. Split the initial mask count evenly across rounds, assigning remainder slots to earlier rounds.

## Example 1

Input

~~~json
{
  "mode": "generate",
  "tokens": [
    1,
    -1,
    -1
  ],
  "steps": 2,
  "bias": [
    [
      0,
      0
    ],
    [
      1,
      0
    ],
    [
      0,
      3
    ]
  ],
  "context": [
    [
      0,
      0
    ],
    [
      0,
      1
    ]
  ]
}
~~~

Output

~~~json
{
  "tokens": [
    1,
    1,
    1
  ],
  "trace": [
    [
      1,
      -1,
      1
    ],
    [
      1,
      1,
      1
    ]
  ]
}
~~~

The prompt adds one to the logit for token 1. The last position is most confident and commits first. Its visible 1 then changes the middle logits to [1,2].

## Example 2

Input

~~~json
{
  "mode": "loss",
  "tokens": [
    0,
    1
  ],
  "draws": [
    0.45,
    0.72
  ],
  "t": 0.5,
  "bias": [
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ],
  "context": [
    [
      0,
      0
    ],
    [
      0,
      0
    ]
  ]
}
~~~

Output

~~~json
{
  "masked": [
    -1,
    1
  ],
  "loss": 0.6931471805599453
}
~~~

Only position 0 is hidden. Both vocabulary logits are equal and t times the length equals 1, giving log(2) nats.

## Part 1 · Score only corrupted positions

Build a corrupted copy, run the supplied scores on that copy and compute cross-entropy against the original IDs at masked positions. Apply the specified normalization.

masked_objective.py · corruption_loss(clean, draws, t, bias, context) — Return masked IDs and inverse-t weighted NLL per original token.

## Part 2 · Resolve high-confidence holes in parallel

Compute all proposals from the current sequence before committing any position. Use normalized log probability or probability to rank proposals across positions. Recompute scores after every round.

unmask.py · commit(tokens, logits, quota) — Return a copy with up to quota masked positions frozen by predicted probability.

unmask.py · generate(tokens, steps, bias, context) — Return tokens and the post-commit trace for exactly steps parallel rounds.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Nie et al. · Large Language Diffusion Models](https://arxiv.org/abs/2502.09992)

- [LLaDA authors · generation code](https://github.com/ML-GSAI/LLaDA/blob/main/generate.py)
