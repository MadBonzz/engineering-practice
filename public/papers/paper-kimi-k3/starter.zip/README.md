# Kimi K3 · Attention across residual blocks

A single-token execution engine needs to retain information across network depth. Implement Block AttnRes for a stack of small branches. A depth query chooses how much each completed block and the unfinished block contribute to the next branch.

## Implementation scope

Implements the token-wise Block AttnRes depth recurrence from equations 8–10 with diagonal branch operators. KDA, experts and multimodal tokenization are outside this exercise.

## Input

embedding is a width-D vector. layers is an ordered list of objects with width-D q and gain vectors. block_size counts branches per block. readout is the final width-D query.

## Output

Return blocks with the sum of branch outputs for each block, excluding the initial embedding, and state with the final readout over the embedding and completed blocks.

## Constraints

D and block_size are positive. All vectors share D. A final partial block is committed. Empty layers return the embedding as state and no blocks. RMS uses epsilon 1e-6 with unit gain. Softmax must tolerate scores with absolute value above 700.

## Example 1

Input

~~~json
{
  "embedding": [
    2,
    -2
  ],
  "layers": [
    {
      "q": [
        0,
        0
      ],
      "gain": [
        1,
        0
      ]
    },
    {
      "q": [
        0,
        0
      ],
      "gain": [
        0,
        1
      ]
    }
  ],
  "block_size": 2,
  "readout": [
    0,
    0
  ]
}
~~~

Output

~~~json
{
  "blocks": [
    [
      2,
      -1
    ]
  ],
  "state": [
    2,
    -1.5
  ]
}
~~~

The second branch sees the mean of [2,-2] and [2,0], giving [2,-1]. Its gain keeps just the second coordinate. The completed block is [2,-1].

## Example 2

Input

~~~json
{
  "embedding": [
    3
  ],
  "layers": [],
  "block_size": 2,
  "readout": [
    800
  ]
}
~~~

Output

~~~json
{
  "blocks": [],
  "state": [
    3
  ]
}
~~~

The embedding is the only available source, so the readout gives it weight one.

## Part 1 · Read from a depth bank

Compute one stable attention read across depth. RMS-normalize keys and retain original vectors as values.

depth_read.py · mix(query, sources) — Map a query [D] and nonempty source matrix [N,D] to one depth read [D]. Score with dot(query, row/RMS(row)), epsilon 1e-6. Apply stable softmax over sources and weight the original rows.

## Part 2 · Commit and reuse block summaries

Build the depth stack and its final readout. The first branch of each block has no unfinished source.

block_stack.py · execute(embedding, layers, block_size, readout) — Return {blocks, state}. Start the bank with embedding. A branch reads committed sources plus the current sum, if any. Its output is gain times that read elementwise. Accumulate, commit after each block, then perform the final read.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Moonshot AI · Kimi K3 technical report, §2.2](https://arxiv.org/abs/2607.24653)
