from depth_read import mix

def execute(embedding, layers, block_size, readout):
    """Return {blocks, state}. Start the bank with embedding. A branch reads committed sources plus the current sum, if any. Its output is gain times that read elementwise. Accumulate, commit after each block, then perform the final read."""
    raise NotImplementedError('execute')
