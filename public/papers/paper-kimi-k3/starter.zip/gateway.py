from block_stack import execute
def handle(request):
    return execute(request["embedding"], request["layers"], request["block_size"], request["readout"])
