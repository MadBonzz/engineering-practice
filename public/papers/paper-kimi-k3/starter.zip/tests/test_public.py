import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_original_source_magnitudes_survive(self):
        args = [[0, 0], [[0, 4], [10, 0]]]
        expected = [5.0, 2.0]
        actual = trial('depth_read.mix', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_empty_stack(self):
        args = [[2], [], 3, [0]]
        expected = {'blocks': [], 'state': [2.0]}
        actual = trial('block_stack.execute', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

