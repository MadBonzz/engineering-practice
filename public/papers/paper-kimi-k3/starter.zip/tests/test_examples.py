import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'block_size': 2,
 'embedding': [2, -2],
 'layers': [{'gain': [1, 0], 'q': [0, 0]}, {'gain': [0, 1], 'q': [0, 0]}],
 'readout': [0, 0]}
        expected = {'blocks': [[2, -1]], 'state': [2, -1.5]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'block_size': 2, 'embedding': [3], 'layers': [], 'readout': [800]}
        expected = {'blocks': [], 'state': [3]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
