import math

def mix(query, sources):
    """Map a query [D] and nonempty source matrix [N,D] to one depth read [D]. Score with dot(query, row/RMS(row)), epsilon 1e-6. Apply stable softmax over sources and weight the original rows."""
    raise NotImplementedError('mix')
