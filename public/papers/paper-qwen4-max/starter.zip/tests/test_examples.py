import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'block': 2,
 'budget': 1,
 'index_keys': [0, 2, 6, 4, -1, 100],
 'keys': [[1], [1], [1], [1], [1], [1]],
 'queries': [{'index': 1, 'q': [0], 't': 4}],
 'values': [[0], [6], [9], [3], [6], [999]]}
        expected = {'contexts': [[6]], 'positions': [[2, 3, 4]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'block': 2,
 'budget': 0,
 'index_keys': [3, 9, 4],
 'keys': [[0], [0], [0]],
 'queries': [{'index': -1, 'q': [1], 't': 2}],
 'values': [[1], [2], [7]]}
        expected = {'contexts': [[7]], 'positions': [[2]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
