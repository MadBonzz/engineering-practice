import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_tie_between_block_means(self):
        args = [[1, 3, 2, 2, 9], 4, 1, 2, 1]
        expected = [0, 1, 4]
        actual = trial('block_index.retained', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_stable_softmax_on_sparse_subset(self):
        args = [[1000], [[1], [2], [-1]], [[1, 8], [2, -1], [8, 3]], [0, 2]]
        expected = [1.0, 8.0]
        actual = trial('sparse_read.read', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

