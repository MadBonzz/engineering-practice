# Qwen4-Max companion · micro-block sparse attention

Long-context decoding spends time scoring old tokens. Build a two-stage causal reader from Qwen’s publicly documented architecture preview. A lightweight index selects entire historical micro-blocks. A separate attention head then reads individual tokens within the retained blocks.

## Implementation scope

Qwen describes micro-block selection in its open Qwen4 architecture preview. This exercise uses a scalar mean index, one exact attention head and an explicit block budget. Those are teaching choices. Max checkpoint parameters and exact private serving kernels are outside scope.

## Input

index_keys contains one scalar per position. keys and values are token-major matrices with key width D and value width V. Each entry in queries gives a zero-based time t, a scalar index query, and a D-vector q for exact attention. block is a positive block length and budget is a count of historical blocks.

## Output

Return positions and contexts, with one ascending token-index list and one V-vector per query. Process queries in request order even when t decreases.

## Constraints

Block boundaries start at token 0. Among blocks strictly before the query's block select up to budget using index × mean(index_keys in block). Earlier block wins a tie. Always add the current block's prefix through t. Exact attention uses stable softmax of dot(q,key)/sqrt(D) over retained positions. Budget may be zero.

## Example 1

Input

~~~json
{
  "index_keys": [
    0,
    2,
    6,
    4,
    -1,
    100
  ],
  "keys": [
    [
      1
    ],
    [
      1
    ],
    [
      1
    ],
    [
      1
    ],
    [
      1
    ],
    [
      1
    ]
  ],
  "values": [
    [
      0
    ],
    [
      6
    ],
    [
      9
    ],
    [
      3
    ],
    [
      6
    ],
    [
      999
    ]
  ],
  "queries": [
    {
      "t": 4,
      "index": 1,
      "q": [
        0
      ]
    }
  ],
  "block": 2,
  "budget": 1
}
~~~

Output

~~~json
{
  "positions": [
    [
      2,
      3,
      4
    ]
  ],
  "contexts": [
    [
      6
    ]
  ]
}
~~~

Historical block means are 1 and 5. The larger selects positions 2 and 3. Position 4 is local. Equal exact logits average 9, 3 and 6.

## Example 2

Input

~~~json
{
  "index_keys": [
    3,
    9,
    4
  ],
  "keys": [
    [
      0
    ],
    [
      0
    ],
    [
      0
    ]
  ],
  "values": [
    [
      1
    ],
    [
      2
    ],
    [
      7
    ]
  ],
  "queries": [
    {
      "t": 2,
      "index": -1,
      "q": [
        1
      ]
    }
  ],
  "block": 2,
  "budget": 0
}
~~~

Output

~~~json
{
  "positions": [
    [
      2
    ]
  ],
  "contexts": [
    [
      7
    ]
  ]
}
~~~

No historical budget remains at the start of block 1. Only token 2 is visible.

## Part 1 · Choose causal micro-blocks

Score each eligible historical block and combine its tokens with the live prefix. Sort blocks in chronological order after ranking.

block_index.py · retained(index_keys, t, query, block, budget) — Return ascending visible token positions. Score each complete block before t's own block by query times its mean scalar index key. Select top budget with earlier block winning ties. Include the visible prefix of the current block.

## Part 2 · Read the retained KV rows

Use full-resolution attention on selected individual keys. Key and value widths can differ.

sparse_read.py · read(q, keys, values, positions) — Given q[D], keys[T,D], values[T,V] and a nonempty selection, return a V-vector. Use softmax(dot(q,key)/sqrt(D)) over selected individual tokens, then combine the original values.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Alibaba · Qwen4-Max launch](https://www.alibabacloud.com/en/press-room/alibaba-unveils-qwen4-max)

- [Qwen · Open Qwen4 architecture preview and QSA](https://huggingface.co/Qwen/Qwen3.8-Flash-Next)
