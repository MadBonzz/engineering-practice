from block_index import retained
from sparse_read import read

def handle(request):
    positions,contexts = [],[]
    for query in request["queries"]:
        ids = retained(request["index_keys"],query["t"],query["index"],request["block"],request["budget"])
        positions.append(ids)
        contexts.append(read(query["q"],request["keys"],request["values"],ids))
    return {"positions":positions,"contexts":contexts}
