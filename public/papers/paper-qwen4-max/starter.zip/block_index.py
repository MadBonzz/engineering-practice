def retained(index_keys, t, query, block, budget):
    """Return ascending visible token positions. Score each complete block before t's own block by query times its mean scalar index key. Select top budget with earlier block winning ties. Include the visible prefix of the current block."""
    raise NotImplementedError('retained')
