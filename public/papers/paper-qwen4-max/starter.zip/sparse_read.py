import math

def read(q, keys, values, positions):
    """Given q[D], keys[T,D], values[T,V] and a nonempty selection, return a V-vector. Use softmax(dot(q,key)/sqrt(D)) over selected individual tokens, then combine the original values."""
    raise NotImplementedError('read')
