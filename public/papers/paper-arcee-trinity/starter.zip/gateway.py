from expert_router import dispatch
from load_control import update

def handle(request):
    bias, momentum = request["biases"], request["momentum"]
    routes, outputs = [], []
    for batch in request["batches"]:
        ids_in_batch, mixed = [], []
        counts = [0]*len(bias)
        for logits, values in zip(batch["logits"],batch["values"]):
            ids, out = dispatch(logits,values,bias,request["k"])
            for expert in ids:
                counts[expert] += 1
            ids_in_batch.append(ids)
            mixed.append(out)
        routes.append(ids_in_batch)
        outputs.append(mixed)
        bias,momentum = update(counts,bias,momentum,request["rate"],request["beta"],request["sharpness"])
    return {"routes":routes,"outputs":outputs,"biases":bias,"momentum":momentum}
