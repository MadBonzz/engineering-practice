import importlib
import math

ALLOWED = ['expert_router.dispatch', 'gateway.handle', 'load_control.update']

def trial(name, args):
    if name not in ALLOWED:
        raise ValueError('Unknown interface')
    module, function = name.rsplit('.', 1)
    return getattr(importlib.import_module(module), function)(*args)

def equivalent(actual, expected):
    if isinstance(expected, bool):
        return actual is expected
    if isinstance(expected, (int, float)):
        return type(actual) in (int, float) and math.isclose(actual, expected, rel_tol=1e-7, abs_tol=1e-8)
    if isinstance(expected, list):
        return isinstance(actual, (list, tuple)) and len(actual)==len(expected) and all(equivalent(a,e) for a,e in zip(actual,expected))
    if isinstance(expected, dict):
        return isinstance(actual, dict) and actual.keys()==expected.keys() and all(equivalent(actual[k],v) for k,v in expected.items())
    return actual == expected
