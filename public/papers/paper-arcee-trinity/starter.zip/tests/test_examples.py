import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'batches': [{'logits': [[0, 0]], 'values': [[5, 9]]},
             {'logits': [[0, 0]], 'values': [[5, 9]]}],
 'beta': 0,
 'biases': [0, 0],
 'k': 1,
 'momentum': [0, 0],
 'rate': 1,
 'sharpness': 1}
        expected = {'biases': [0, 0],
 'momentum': [0.7615941559557649, -0.7615941559557649],
 'outputs': [[5], [9]],
 'routes': [[[0]], [[1]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'batches': [{'logits': [[0, 0]], 'values': [[2, 10]]}],
 'beta': 0,
 'biases': [0, 0],
 'k': 2,
 'momentum': [0, 0],
 'rate': 1,
 'sharpness': 1}
        expected = {'biases': [0, 0],
 'momentum': [0, 0],
 'outputs': [[6]],
 'routes': [[[0, 1]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
