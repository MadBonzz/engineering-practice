import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_biased_membership_and_unbiased_weights(self):
        args = [[0, 1, -1], [1, 20, 5], [2, 0, 1], 2]
        expected = [[0, 2], 2.3990216362168755]
        actual = trial('expert_router.dispatch', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_center_unequal_load_corrections(self):
        args = [[3, 0, 0], [0, 0, 0], [0, 0, 0], 0.2, 0.5, 1.5]
        expected = [[-0.12668020048877313, 0.06334010024438656, 0.06334010024438656],
 [-0.12668020048877313, 0.06334010024438656, 0.06334010024438656]]
        actual = trial('load_control.update', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

