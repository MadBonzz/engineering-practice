import math

def update(counts, bias, momentum, rate, beta, sharpness):
    """Update E expert biases from counts with positive mean n. Compute d_i=rate*tanh(sharpness*(n-count_i)/n), subtract mean(d), set m'=beta*m+(1-beta)*centered_d and b'=b+m'. Return [b',m']."""
    raise NotImplementedError('update')
