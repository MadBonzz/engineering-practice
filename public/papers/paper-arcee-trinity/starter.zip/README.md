# Arcee Trinity · Train an expert load balancer

A Trinity-style expert router repeatedly sends tokens to the same few experts. Implement its bias-adjusted top-k routing and SMEBU load controller. Run consecutive batches and inspect how the next batch responds to the previous load.

## Implementation scope

Runs the Trinity Large routing and SMEBU equations on small batches with supplied expert outputs. The shared expert, expert MLPs, optimizer and transformer backbone are omitted.

## Input

Each batch has logits and values of shape [tokens, experts]. values contains one supplied scalar expert output per token and expert. biases and momentum describe the initial controller, k sets fan-out, and rate, beta and sharpness set its update.

## Output

Return routes and outputs grouped by batch then token, plus the biases and momentum after the last update. Each route lists k expert indices in selection order.

## Constraints

Batches and expert sets are nonempty. k lies between 1 and the expert count. Logits have magnitude at most 50. Rank by descending sigmoid(logit) + bias, resolving ties by smaller expert index. Reweight selected experts using unbiased sigmoid scores normalized to sum to one.

## Example 1

Input

~~~json
{
  "batches": [
    {
      "logits": [
        [
          0,
          0
        ]
      ],
      "values": [
        [
          5,
          9
        ]
      ]
    },
    {
      "logits": [
        [
          0,
          0
        ]
      ],
      "values": [
        [
          5,
          9
        ]
      ]
    }
  ],
  "k": 1,
  "biases": [
    0,
    0
  ],
  "momentum": [
    0,
    0
  ],
  "rate": 1,
  "beta": 0,
  "sharpness": 1
}
~~~

Output

~~~json
{
  "routes": [
    [
      [
        0
      ]
    ],
    [
      [
        1
      ]
    ]
  ],
  "outputs": [
    [
      5
    ],
    [
      9
    ]
  ],
  "biases": [
    0,
    0
  ],
  "momentum": [
    0.7615941559557649,
    -0.7615941559557649
  ]
}
~~~

The tie selects expert 0. A bias shift of ±tanh(1) makes expert 1 win the next tie. Equal and opposite updates cancel in the final biases.

## Example 2

Input

~~~json
{
  "batches": [
    {
      "logits": [
        [
          0,
          0
        ]
      ],
      "values": [
        [
          2,
          10
        ]
      ]
    }
  ],
  "k": 2,
  "biases": [
    0,
    0
  ],
  "momentum": [
    0,
    0
  ],
  "rate": 1,
  "beta": 0,
  "sharpness": 1
}
~~~

Output

~~~json
{
  "routes": [
    [
      [
        0,
        1
      ]
    ]
  ],
  "outputs": [
    [
      6
    ]
  ],
  "biases": [
    0,
    0
  ],
  "momentum": [
    0,
    0
  ]
}
~~~

Both experts receive one token. Equal unbiased scores average 2 and 10, and balanced usage produces zero controller change.

## Part 1 · Dispatch without biasing the mixture

Select experts with corrected scores, then mix their supplied values using the original sigmoid scores.

expert_router.py · dispatch(logits, values, bias, k) — For a single token with E logits, scalar expert values and biases, return [selected_ids, mixture]. Use bias only to select top k and use normalized unbiased sigmoid scores to mix.

## Part 2 · Carry the controller between batches

Implement normalized usage error, tanh clamping, centering and the EMA in that order.

load_control.py · update(counts, bias, momentum, rate, beta, sharpness) — Update E expert biases from counts with positive mean n. Compute d_i=rate*tanh(sharpness*(n-count_i)/n), subtract mean(d), set m'=beta*m+(1-beta)*centered_d and b'=b+m'. Return [b',m'].

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Arcee AI · Trinity Large technical report, equations 23–28](https://arxiv.org/abs/2602.17004)
