import math

def dispatch(logits, values, bias, k):
    """For a single token with E logits, scalar expert values and biases, return [selected_ids, mixture]. Use bias only to select top k and use normalized unbiased sigmoid scores to mix."""
    raise NotImplementedError('dispatch')
