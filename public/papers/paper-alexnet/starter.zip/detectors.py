def activations(image, filters):
    """Produce C rectified feature planes using the exported scale and bias per detector."""
    return [[[max(0,weight*pixel+bias) for pixel in row] for row in image]
            for weight,bias in filters]
