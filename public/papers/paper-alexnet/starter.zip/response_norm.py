def normalize(planes, radius, k, alpha, beta):
    """Apply local response normalization to C×H×W at fixed row and column, inclusive channel window."""
    raise NotImplementedError('normalize')
