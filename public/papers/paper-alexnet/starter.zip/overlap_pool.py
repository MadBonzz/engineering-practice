def pool3(plane):
    """Return maxima over complete 3×3 windows with top-left corners spaced two pixels apart."""
    raise NotImplementedError('pool3')
