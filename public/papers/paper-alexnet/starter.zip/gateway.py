from detectors import activations
from response_norm import normalize
from overlap_pool import pool3

def handle(request):
    z=activations(request["image"],request["filters"])
    normalized=normalize(z,request["radius"],request["k"],request["alpha"],request["beta"])
    return {"pooled":[pool3(plane) for plane in normalized]}
