import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_use_clipped_channel_neighborhoods(self):
        args = [[[[1]], [[3]], [[2]]], 1, 1, 1, 1]
        expected = [[[0.09090909090909091]], [[0.2]], [[0.14285714285714285]]]
        actual = trial('response_norm.normalize', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_overlapping_horizontal_windows(self):
        args = [[[0, 0, 2, 0, 1], [3, 0, 0, 0, 0], [0, 0, 0, 0, 4]]]
        expected = [[3, 4]]
        actual = trial('overlap_pool.pool3', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

