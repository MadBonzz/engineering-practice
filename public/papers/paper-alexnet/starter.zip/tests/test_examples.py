import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'alpha': 1,
 'beta': 1,
 'filters': [[1, 0], [-1, 1]],
 'image': [[0, 1, 0], [0, 0, 0], [0, 0, 0]],
 'k': 1,
 'radius': 1}
        expected = {'pooled': [[[0.5]], [[0.5]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'alpha': 0,
 'beta': 1,
 'filters': [[1, 0]],
 'image': [[0, 0, 3, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]],
 'k': 1,
 'radius': 0}
        expected = {'pooled': [[[3, 3]]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
