# AlexNet · Normalize competing feature channels

An inference team is porting an AlexNet feature stage whose strongest detector sometimes changes after response normalization. Compute normalization across neighboring channels and feed each normalized plane into an overlapping max pool.

## Implementation scope

This reproduces local response normalization and overlapping pooling from the 2012 model. A supplied bank of small pointwise detectors replaces the large first convolution so every activation can be inspected. The exercise ends at the pooled feature maps.

## Input

image is H×W. Each [weight,bias] in filters defines a supplied pointwise feature detector followed by ReLU. radius is the number of neighboring channels on each side. k, alpha and beta are normalization constants.

## Output

Return pooled, a channels-first C×out_h×out_w tensor of normalized and max-pooled activations.

## Constraints

H and W are at least 3. For channel c at a fixed pixel, output a_c / (k + alpha × sum_j a_j²)^beta over j from c−radius through c+radius, clipped to existing channels. There is no window-size divisor. Use valid 3×3 max pooling, stride 2. k is positive and alpha and beta are nonnegative.

## Example 1

Input

~~~json
{
  "image": [
    [
      0,
      1,
      0
    ],
    [
      0,
      0,
      0
    ],
    [
      0,
      0,
      0
    ]
  ],
  "filters": [
    [
      1,
      0
    ],
    [
      -1,
      1
    ]
  ],
  "radius": 1,
  "k": 1,
  "alpha": 1,
  "beta": 1
}
~~~

Output

~~~json
{
  "pooled": [
    [
      [
        0.5
      ]
    ],
    [
      [
        0.5
      ]
    ]
  ]
}
~~~

Exactly one of the two detectors fires with value 1 at each pixel. With radius 1, every denominator is 1 + 1² = 2. Both channels have a positive response somewhere in the pool.

## Example 2

Input

~~~json
{
  "image": [
    [
      0,
      0,
      3,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0
    ]
  ],
  "filters": [
    [
      1,
      0
    ]
  ],
  "radius": 0,
  "k": 1,
  "alpha": 0,
  "beta": 1
}
~~~

Output

~~~json
{
  "pooled": [
    [
      [
        3,
        3
      ]
    ]
  ]
}
~~~

Alpha zero disables competition. The central value 3 belongs to both windows because their starting columns differ by two.

## Part 1 · Implement cross-channel competition

At each location compute the denominator from the original rectified channels, including the center channel. Preserve tensor shape.

response_norm.py · normalize(planes, radius, k, alpha, beta) — Apply local response normalization to C×H×W at fixed row and column, inclusive channel window.

## Part 2 · Pool overlapping neighborhoods

Pool each normalized channel independently. A 3×5 plane has two overlapping windows across its width.

overlap_pool.py · pool3(plane) — Return maxima over complete 3×3 windows with top-left corners spaced two pixels apart.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Krizhevsky, Sutskever and Hinton · ImageNet Classification with Deep Convolutional Neural Networks](https://papers.nips.cc/paper_files/paper/2012/hash/c399862d3b9d6b76c8436e924a68c45b-Abstract.html)
