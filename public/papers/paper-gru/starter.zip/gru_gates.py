from numerics import dot, sigmoid


def retention(drive, recurrent, h):
    """Return [reset, retention] vectors of width H from the first 2H drive entries and matrix rows."""
    raise NotImplementedError('retention')
