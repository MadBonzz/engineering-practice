from math import tanh
from numerics import dot
from gru_gates import retention


def step(drive, recurrent, h):
    """Return a length-H hidden vector with reset applied before the candidate recurrent projection."""
    raise NotImplementedError('step')


def encode(initial, recurrent, chunks):
    """Run every projected token through step and return {final, checkpoints} across chunk boundaries."""
    raise NotImplementedError('encode')
