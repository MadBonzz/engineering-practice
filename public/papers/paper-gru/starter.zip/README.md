# GRU · encode a chunked phrase with reset-before gating

A phrase encoder gets tokens in network-sized chunks. Build the recurrent unit that compresses the phrase into a fixed vector and return a checkpoint after each incoming chunk. Splitting a phrase differently must preserve its final embedding.

## Implementation scope

Implements the paper's GRU encoder recurrence and phrase-level state carry. Input projections are supplied. The translation decoder and language-pair training corpus are omitted.

## Input

initial is a length-H hidden vector. Each token in chunks is a packed input projection of length 3H, ordered reset, retention, candidate. recurrent is a 3H × H matrix stored in the same row-block order. Input-side biases are already included in the token drives.

## Output

Return final as the encoding after all tokens and checkpoints as one encoding per chunk. Empty chunks repeat the current encoding.

## Constraints

Use the reset-before formulation of Cho et al. Activate r = sigmoid(xr + Ur h) and z = sigmoid(xz + Uz h). Compute g = tanh(xg + Ug (r ⊙ h)) and update h' = z ⊙ h + (1−z) ⊙ g. Matrix rows are output features. Use the same parameters across chunks and preserve the starting vector.

## Example 1

Input

~~~json
{
  "initial": [
    1
  ],
  "recurrent": [
    [
      0
    ],
    [
      0
    ],
    [
      0
    ]
  ],
  "chunks": [
    [
      [
        0,
        0,
        0
      ]
    ],
    [],
    [
      [
        0,
        0,
        0
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "checkpoints": [
    [
      0.5
    ],
    [
      0.5
    ],
    [
      0.25
    ]
  ],
  "final": [
    0.25
  ]
}
~~~

The candidate is zero, and retention is 0.5 for each token. Only actual tokens halve the state.

## Example 2

Input

~~~json
{
  "initial": [
    0
  ],
  "recurrent": [
    [
      0
    ],
    [
      0
    ],
    [
      0
    ]
  ],
  "chunks": [
    [
      [
        0,
        0,
        0.5493061443340549
      ]
    ]
  ]
}
~~~

Output

~~~json
{
  "checkpoints": [
    [
      0.25
    ]
  ],
  "final": [
    0.25
  ]
}
~~~

The candidate is tanh(atanh(0.5)) = 0.5, so interpolation halfway from zero gives 0.25.

## Part 1 · Produce reset and retention factors

Combine the first two input blocks with their rows of the recurrent matrix and the complete old hidden state. Return activated r then z.

gru_gates.py · retention(drive, recurrent, h) — Return [reset, retention] vectors of width H from the first 2H drive entries and matrix rows.

## Part 2 · Encode the phrase across transport boundaries

Implement the candidate and interpolation from the equations, then carry the result through every chunk. Return a checkpoint even for an empty chunk.

phrase_encoder.py · step(drive, recurrent, h) — Return a length-H hidden vector with reset applied before the candidate recurrent projection.

phrase_encoder.py · encode(initial, recurrent, chunks) — Run every projected token through step and return {final, checkpoints} across chunk boundaries.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Cho et al. · Learning Phrase Representations using RNN Encoder–Decoder, equations 5–8](https://arxiv.org/abs/1406.1078)
