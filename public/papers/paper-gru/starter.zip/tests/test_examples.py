import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'chunks': [[[0, 0, 0]], [], [[0, 0, 0]]],
 'initial': [1],
 'recurrent': [[0], [0], [0]]}
        expected = {'checkpoints': [[0.5], [0.5], [0.25]], 'final': [0.25]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'chunks': [[[0, 0, 0.5493061443340549]]],
 'initial': [0],
 'recurrent': [[0], [0], [0]]}
        expected = {'checkpoints': [[0.25]], 'final': [0.25]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
