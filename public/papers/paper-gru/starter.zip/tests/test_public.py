import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_independent_gates_mix_multiple_old_coordinates(self):
        args = [[0, 0, 0, 0, 0, 0],
 [[0.5, -1], [1, -0.3], [-0.5, 0.2], [0.7, 1], [0, 2], [-1, 0.5]],
 [1, -0.25]]
        expected = [[0.679178699175393, 0.7455466141264027], [0.3658644089891993, 0.610639233949222]]
        actual = trial('gru_gates.retention', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_reset_before_with_a_nondiagonal_candidate_matrix(self):
        args = [[2, -2, 0, 0, 0, 0],
 [[0.5, -1], [1, -0.3], [-0.5, 0.2], [0.7, 1], [0, 2], [-1, 0.5]],
 [0.5, -1]]
        expected = [-0.06941243971766115, -0.6944667038693226]
        actual = trial('phrase_encoder.step', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

