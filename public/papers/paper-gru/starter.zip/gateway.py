from phrase_encoder import encode


def handle(request):
    return encode(request["initial"],request["recurrent"],request["chunks"])
