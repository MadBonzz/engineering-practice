def last_logits(rows, vocab):
    """A fixed decoder probe with zero query/key projections and identity values."""
    state = [sum(row[j] for row in rows)/len(rows) for j in range(len(rows[0]))]
    return [sum(w*x for w,x in zip(head,state)) for head in vocab]
