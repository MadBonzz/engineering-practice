import unittest
from workload import trial, equivalent


class Part1(unittest.TestCase):
    def test_1_neighbor_tiles_respect_row_boundaries(self):
        args = [[[[1], [2], [3], [4]], [[5], [6], [7], [8]]], [[1, -1, 2, 0]]]
        expected = [[9], [13]]
        actual = trial('image_bridge.visual_tokens', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))


class Part2(unittest.TestCase):
    def test_1_repeated_text_ids(self):
        args = [[{'text': [1, 0, 1]}], [], [[3], [5]], [[1, 0, 0, 0]]]
        expected = [[[5], [3], [5]], [['text', 1], ['text', 0], ['text', 1]]]
        actual = trial('prompt_packer.pack', args)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

