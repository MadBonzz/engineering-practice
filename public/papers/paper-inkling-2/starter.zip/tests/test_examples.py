import unittest
from gateway import handle
from workload import equivalent


class Examples(unittest.TestCase):
    def test_example_1(self):
        request = {'images': [[[[1], [2]], [[3], [4]]]],
 'projection': [[1, 0, 0, 1], [0, 1, 1, 0]],
 'segments': [{'text': [1]}, {'image': 0}, {'text': [0]}],
 'text_table': [[0, 2], [1, 0]],
 'vocab': [[1, 0], [0, 1]]}
        expected = {'logits': [2, 2.3333333333333335],
 'origins': [['text', 1], ['image', 0, 0, 0], ['text', 0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))

    def test_example_2(self):
        request = {'images': [],
 'projection': [[1, 0, 0, 0], [0, 1, 0, 0]],
 'segments': [{'text': []}, {'text': [0]}],
 'text_table': [[4, -1]],
 'vocab': [[1, -2]]}
        expected = {'logits': [6], 'origins': [['text', 0]]}
        actual = handle(request)
        self.assertTrue(equivalent(actual, expected), (actual, expected))
