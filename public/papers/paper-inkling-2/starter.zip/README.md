# Inkling 2 · Pack visual patches into a text sequence

A multimodal serving worker receives images between fragments of text. Complete the interface from patch features to the decoder stream. Merge each 2×2 tile, project it to text width, preserve its position among text tokens, and run a supplied tiny decoder readout.

## Implementation scope

Implements the visual/text interface of Inkling 2 Small using precomputed patch features, a teaching merge projection and a deterministic decoder probe. Production vision encoding, attention residuals and sparse decoder layers are outside scope.

## Input

segments contains objects with either text (a list of token IDs) or image (a zero-based image index). images holds even-height, even-width grids of width-C patch features. projection is [D,4C], text_table is [vocabulary,D], and vocab is an output matrix [labels,D]. At least one token survives packing.

## Output

Return origins in decoder order as [text,token_id] or [image,image_id,tile_row,tile_col], with the first entries represented as JSON strings. Return logits for the final position, one per row of vocab.

## Constraints

Traverse 2×2 tiles in row-major order. Flatten the four feature vectors within each tile in TL, TR, BL, BR order, then multiply by projection. Text embeddings and projected image tokens share D. Images may repeat. The supplied diagnostic head reads the mean of the visible prefix using uniform attention and projects to logits.

## Example 1

Input

~~~json
{
  "segments": [
    {
      "text": [
        1
      ]
    },
    {
      "image": 0
    },
    {
      "text": [
        0
      ]
    }
  ],
  "images": [
    [
      [
        [
          1
        ],
        [
          2
        ]
      ],
      [
        [
          3
        ],
        [
          4
        ]
      ]
    ]
  ],
  "text_table": [
    [
      0,
      2
    ],
    [
      1,
      0
    ]
  ],
  "projection": [
    [
      1,
      0,
      0,
      1
    ],
    [
      0,
      1,
      1,
      0
    ]
  ],
  "vocab": [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ]
}
~~~

Output

~~~json
{
  "origins": [
    [
      "text",
      1
    ],
    [
      "image",
      0,
      0,
      0
    ],
    [
      "text",
      0
    ]
  ],
  "logits": [
    2,
    2.3333333333333335
  ]
}
~~~

The 2×2 tile maps to [5,5]. The other two embeddings contribute [1,0] and [0,2]. Uniform attention gives their mean [2,7/3].

## Example 2

Input

~~~json
{
  "segments": [
    {
      "text": []
    },
    {
      "text": [
        0
      ]
    }
  ],
  "images": [],
  "text_table": [
    [
      4,
      -1
    ]
  ],
  "projection": [
    [
      1,
      0,
      0,
      0
    ],
    [
      0,
      1,
      0,
      0
    ]
  ],
  "vocab": [
    [
      1,
      -2
    ]
  ]
}
~~~

Output

~~~json
{
  "origins": [
    [
      "text",
      0
    ]
  ],
  "logits": [
    6
  ]
}
~~~

An empty fragment contributes zero positions. The sole text embedding yields 4 + 2 = 6.

## Part 1 · Merge spatially adjacent features

Map each 2×2 neighborhood through the projection. Keep relative position within the tile intact while flattening.

image_bridge.py · visual_tokens(grid, projection) — Map an [H,W,C] grid to projected rows [H*W/4,D]. Scan 2x2 tiles in row-major order, concatenate TL,TR,BL,BR patch features within each tile and apply the [D,4C] matrix without a bias.

## Part 2 · Interleave image and text tokens

Build one decoder sequence and origin manifest, allowing repeated images, empty text segments and multiple token IDs per segment.

prompt_packer.py · pack(segments, images, text_table, projection) — Return [rows,origins]. Expand text ID lists in order. Expand each image to projected 2x2 tile tokens in place. Origins are ['text',id] or ['image',image_id,tile_row,tile_col] with zero-based tile coordinates.

## Run locally

Standard-library Python 3.10 or newer. Start at gateway.py to trace the model's entry point.

~~~sh
python run_lab.py fixtures/example_1.json
python -m unittest discover -s tests
~~~

## Reading

- [Thinking Machines Lab · Introducing Inkling 2 Small, vision interpretation](https://thinkingmachines.ai/news/inkling-2-small/)

- [Thinking Machines Lab · Inkling 2 Small model card](https://thinkingmachines.ai/model-card/inkling-2-small/)
