from image_bridge import visual_tokens

def pack(segments, images, text_table, projection):
    """Return [rows,origins]. Expand text ID lists in order. Expand each image to projected 2x2 tile tokens in place. Origins are ['text',id] or ['image',image_id,tile_row,tile_col] with zero-based tile coordinates."""
    raise NotImplementedError('pack')
