def visual_tokens(grid, projection):
    """Map an [H,W,C] grid to projected rows [H*W/4,D]. Scan 2x2 tiles in row-major order, concatenate TL,TR,BL,BR patch features within each tile and apply the [D,4C] matrix without a bias."""
    raise NotImplementedError('visual_tokens')
