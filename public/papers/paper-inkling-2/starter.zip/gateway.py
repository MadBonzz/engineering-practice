from prompt_packer import pack
from probe_head import last_logits
def handle(request):
    rows,origins=pack(request["segments"],request["images"],request["text_table"],request["projection"])
    return {"origins":origins,"logits":last_logits(rows,request["vocab"])}
